#include "sysdep.h"
#include "bfd.h"
#include "bfdlink.h"
#include "libbfd.h"
#include "elf-bfd.h"
#include "bfd_stdint.h"

#include "elf/tms9900.h"


#if 0
// EMW - This is just here to make it easier to refer to the howto format

struct reloc_howto_struct
{
  /*  The type field has mainly a documentary use - the back end can
      do what it wants with it, though normally the back end's
      external idea of what a reloc number is stored
      in this field.  For example, a PC relative word relocation
      in a coff environment has the type 023 - because that's
      what the outside world calls a R_PCRWORD reloc.  */
  unsigned int type;

  /*  The value the final relocation is shifted right by.  This drops
      unwanted data from the relocation.  */
  unsigned int rightshift;

  /*  The size of the item to be relocated.  This is *not* a
      power-of-two measure.  To get the number of bytes operated
      on by a type of relocation, use bfd_get_reloc_size.  */
  int size;

  /*  The number of bits in the item to be relocated.  This is used
      when doing overflow checking.  */
  unsigned int bitsize;

  /*  Notes that the relocation is relative to the location in the
      data section of the addend.  The relocation function will
      subtract from the relocation value the address of the location
      being relocated.  */
  bfd_boolean pc_relative;

  /*  The bit position of the reloc value in the destination.
      The relocated value is left shifted by this amount.  */
  unsigned int bitpos;

  /* What type of overflow error should be checked for when
     relocating.  */
  enum complain_overflow complain_on_overflow;

  /* If this field is non null, then the supplied function is
     called rather than the normal function.  This allows really
     strange relocation methods to be accommodated (e.g., i960 callj
     instructions).  */
  bfd_reloc_status_type (*special_function)
    (bfd *, arelent *, struct bfd_symbol *, void *, asection *,
     bfd *, char **);

  /* The textual name of the relocation type.  */
  char *name;

  /* Some formats record a relocation addend in the section contents
     rather than with the relocation.  For ELF formats this is the
     distinction between USE_REL and USE_RELA (though the code checks
     for USE_REL == 1/0).  The value of this field is TRUE if the
     addend is recorded with the section contents; when performing a
     partial link (ld -r) the section contents (the data) will be
     modified.  The value of this field is FALSE if addends are
     recorded with the relocation (in arelent.addend); when performing
     a partial link the relocation will be modified.
     All relocations for all ELF USE_RELA targets should set this field
     to FALSE (values of TRUE should be looked on with suspicion).
     However, the converse is not true: not all relocations of all ELF
     USE_REL targets set this field to TRUE.  Why this is so is peculiar
     to each particular target.  For relocs that aren't used in partial
     links (e.g. GOT stuff) it doesn't matter what this is set to.  */
  bfd_boolean partial_inplace;

  /* src_mask selects the part of the instruction (or data) to be used
     in the relocation sum.  If the target relocations don't have an
     addend in the reloc, eg. ELF USE_REL, src_mask will normally equal
     dst_mask to extract the addend from the section contents.  If
     relocations do have an addend in the reloc, eg. ELF USE_RELA, this
     field should be zero.  Non-zero values for ELF USE_RELA targets are
     bogus as in those cases the value in the dst_mask part of the
     section contents should be treated as garbage.  */
  bfd_vma src_mask;

  /* dst_mask selects which parts of the instruction (or data) are
     replaced with a relocated value.  */
  bfd_vma dst_mask;

  /* When some formats create PC relative instructions, they leave
     the value of the pc of the place being relocated in the offset
     slot of the instruction, so that a PC relative relocation can
     be made just by adding in an ordinary offset (e.g., sun3 a.out).
     Some formats leave the displacement part of an instruction
     empty (e.g., m88k bcs); this flag signals the fact.  */
  bfd_boolean pcrel_offset;
};


#define HOWTO(C, R, S, B, P, BI, O, SF, NAME, INPLACE, MASKSRC, MASKDST, PC) \
  { (unsigned) C, R, S, B, P, BI, O, SF, NAME, INPLACE, MASKSRC, MASKDST, PC }


#endif


#ifdef DEBUG_GEN_RELOC
#define TRACE(str) \
  fprintf (stderr, "i386 bfd reloc lookup %d (%s)\n", code, str)
#else
#define TRACE(str)
#endif

extern const bfd_target bfd_elf32_tms9900_vec;

static reloc_howto_type elf_howto_table[]=
{
  /* Invalid record, do nothing */
  HOWTO(R_TMS9900_NONE,             /* type */
        0,                          /* rightshift */
        0,                          /* size (0 = byte, 1 = short, 2 = long) */
        0,                          /* bitsize */
        FALSE,                      /* pc_relative */
        0,                          /* bitpos */
        complain_overflow_bitfield, /* complain on overflow */
	bfd_elf_generic_reloc,      /* special_function */
        "R_TMS9900_NONE",           /* name */
	FALSE,                      /* partial_inplace */
        0x00000000,                 /* src_mask */
        0x00000000,                 /* dst_mask */
        FALSE),                     /* pcrel_offset */

  /* 8-bit offset from current PC, used in jump commands */
  HOWTO(R_TMS9900_PC8,              /* type */
        1,                          /* rightshift */
        0,                          /* size (0 = byte, 1 = short, 2 = long) */
        8,                          /* bitsize */
        TRUE,                       /* pc_relative */
        0,                          /* bitpos */
        complain_overflow_signed,   /* complain on overflow */
        bfd_elf_generic_reloc,      /* special_function */
        "R_TMS9900_PC8",            /* name */
        FALSE,                      /* partial_inplace */
        0x00000000,                 /* src_mask */
        0x000000FF,                 /* dst_mask */
        TRUE),                      /* pcrel_offset */

  /* Generic 16-bit constant */
  HOWTO(R_TMS9900_16,               /* type */
        0,                          /* rightshift */
        1,                          /* size (0 = byte, 1 = short, 2 = long) */
        16,                         /* bitsize */
        FALSE,                      /* pc_relative */
        0,                          /* bitpos */
        complain_overflow_bitfield, /* complain on overflow */
        bfd_elf_generic_reloc,      /* special_function */
        "R_TMS9900_16",             /* name */
        FALSE,                      /* partial_inplace */
        0x00000000,                 /* src_mask */
        0x0000FFFF,                 /* dst_mask */
        FALSE),                     /* pcrel_offset */
};  


static reloc_howto_type *
elf_tms9900_reloc_type_lookup (bfd *abfd ATTRIBUTE_UNUSED,
				bfd_reloc_code_real_type code)
{
  switch (code)
    {
    case BFD_RELOC_NONE:
      TRACE ("BFD_RELOC_NONE");
      return &elf_howto_table[R_TMS9900_NONE];

    case BFD_RELOC_16:
      TRACE ("BFD_RELOC_16");
      return &elf_howto_table[R_TMS9900_16];

    case BFD_RELOC_8_PCREL:
      TRACE ("BFD_RELOC_8_PCREL");
      return &elf_howto_table[R_TMS9900_PC8];

    default:
      break;
    }

  TRACE ("Unknown");
  return 0;
}

static reloc_howto_type *
elf_tms9900_reloc_name_lookup (bfd *abfd ATTRIBUTE_UNUSED,
				const char *r_name)
{
  unsigned int i;

  for (i = 0; i < sizeof (elf_howto_table) / sizeof (elf_howto_table[0]); i++)
    if (elf_howto_table[i].name != NULL
	&& strcasecmp (elf_howto_table[i].name, r_name) == 0)
      return &elf_howto_table[i];

  return NULL;
}

static void
tms9900_elf_info_to_howto (bfd *abfd ATTRIBUTE_UNUSED,
		           arelent *cache_ptr,
		           Elf_Internal_Rela *dst)
{
  cache_ptr->howto = &elf_howto_table[ELF32_R_TYPE (dst->r_info)];
}

#define TARGET_BIG_SYM			bfd_elf32_tms9900_vec
#define TARGET_BIG_NAME			"elf32-tms9900"
#define ELF_ARCH			bfd_arch_tms9900
#define ELF_MACHINE_CODE		EM_TMS9900
#define ELF_MAXPAGESIZE			0x200

#define bfd_elf32_bfd_reloc_type_lookup	      elf_tms9900_reloc_type_lookup
#define bfd_elf32_bfd_reloc_name_lookup	      elf_tms9900_reloc_name_lookup
#define elf_info_to_howto                     tms9900_elf_info_to_howto
#define elf_info_to_howto_rel                 _bfd_elf_no_info_to_howto

#include "elf32-target.h"
