#define LOCALEDIR "/home/eric/dev/tios/toolchain/install/share/locale"
