/* Generated automatically. */
static const char configuration_arguments[] = "../configure --prefix /home/eric/dev/tios/toolchain/install --target=tms9900 --enable-languages=c : (reconfigured) ../configure --prefix /home/eric/dev/tios/toolchain/install --target=tms9900 --enable-languages=c";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
