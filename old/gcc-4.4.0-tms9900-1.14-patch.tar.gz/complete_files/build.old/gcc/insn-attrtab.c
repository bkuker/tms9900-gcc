/* Generated automatically by the program `genattrtab'
from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "rtl.h"
#include "insn-attr.h"
#include "tm_p.h"
#include "insn-config.h"
#include "recog.h"
#include "regs.h"
#include "real.h"
#include "output.h"
#include "toplev.h"
#include "flags.h"
#include "function.h"

#define operands recog_data.operand

int
insn_current_length (rtx insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 27:  /* jump */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 4;
        }
      else
        {
	  return 2;
        }

    case 26:  /* *bge_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 8;
        }
      else
        {
	  return 2;
        }

    case 25:  /* bge */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 4;
        }

    case 24:  /* *bgt_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 4;
        }

    case 23:  /* bgt */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 8;
        }
      else
        {
	  return 2;
        }

    case 22:  /* *ble_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 8;
        }
      else
        {
	  return 2;
        }

    case 21:  /* ble */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 4;
        }

    case 20:  /* *blt_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 4;
        }

    case 19:  /* blt */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 8;
        }
      else
        {
	  return 2;
        }

    case 18:  /* *bgeu_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 17:  /* bgeu */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 16:  /* *bgtu_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 15:  /* bgtu */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 14:  /* *bleu_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 13:  /* bleu */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 12:  /* *bltu_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 11:  /* bltu */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 10:  /* *bne_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 9:  /* bne */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 8:  /* *beq_reversed */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 7:  /* beq */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (-252)) || (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (256)))
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

int
insn_variable_length_p (rtx insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 27:  /* jump */
    case 26:  /* *bge_reversed */
    case 25:  /* bge */
    case 24:  /* *bgt_reversed */
    case 23:  /* bgt */
    case 22:  /* *ble_reversed */
    case 21:  /* ble */
    case 20:  /* *blt_reversed */
    case 19:  /* blt */
    case 18:  /* *bgeu_reversed */
    case 17:  /* bgeu */
    case 16:  /* *bgtu_reversed */
    case 15:  /* bgtu */
    case 14:  /* *bleu_reversed */
    case 13:  /* bleu */
    case 12:  /* *bltu_reversed */
    case 11:  /* bltu */
    case 10:  /* *bne_reversed */
    case 9:  /* bne */
    case 8:  /* *beq_reversed */
    case 7:  /* beq */
      return 1;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

int
insn_min_length (rtx insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 68:  /* movqi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else if (which_alternative == 4)
        {
	  return 2;
        }
      else if (which_alternative == 5)
        {
	  return 4;
        }
      else
        {
	  return 2;
        }

    case 58:  /* subqi3 */
    case 56:  /* subhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else if (which_alternative == 4)
        {
	  return 4;
        }
      else if (which_alternative == 5)
        {
	  return 6;
        }
      else if (which_alternative == 6)
        {
	  return 8;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 53:  /* addhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0xe))
        {
	  return 4;
        }
      else
        {
	  return 6;
        }

    case 55:  /* subsi3 */
    case 52:  /* addsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else if (which_alternative == 1)
        {
	  return 10 /* 0xa */;
        }
      else if (which_alternative == 2)
        {
	  return 12 /* 0xc */;
        }
      else if (which_alternative == 3)
        {
	  return 4;
        }
      else if (which_alternative == 4)
        {
	  return 8;
        }
      else if (((1 << which_alternative) & 0x60))
        {
	  return 12 /* 0xc */;
        }
      else if (which_alternative == 7)
        {
	  return 14 /* 0xe */;
        }
      else if (which_alternative == 8)
        {
	  return 16 /* 0x10 */;
        }
      else if (which_alternative == 9)
        {
	  return 4;
        }
      else if (which_alternative == 10)
        {
	  return 12 /* 0xc */;
        }
      else if (((1 << which_alternative) & 0x1800))
        {
	  return 16 /* 0x10 */;
        }
      else if (((1 << which_alternative) & 0x6000))
        {
	  return 18 /* 0x12 */;
        }
      else if (which_alternative == 15)
        {
	  return 6;
        }
      else if (which_alternative == 16)
        {
	  return 12 /* 0xc */;
        }
      else
        {
	  return 18 /* 0x12 */;
        }

    case 69:  /* movhi */
    case 46:  /* iorhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else if (which_alternative == 4)
        {
	  return 4;
        }
      else
        {
	  return 2;
        }

    case 43:  /* andqi3 */
    case 40:  /* andhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 6;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 8;
        }
      else if (which_alternative == 3)
        {
	  return 10 /* 0xa */;
        }
      else if (which_alternative == 4)
        {
	  return 4;
        }
      else if (which_alternative == 5)
        {
	  return 6;
        }
      else
        {
	  return 8;
        }

    case 45:  /* *not_andqi */
    case 44:  /* *andnotqi */
    case 42:  /* *not_andhi */
    case 41:  /* *andnothi */
    case 6:  /* cmpqi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else
        {
	  return 6;
        }

    case 54:  /* addqi3 */
    case 47:  /* iorqi3 */
    case 5:  /* cmphi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else
        {
	  return 4;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      return 256 /* 0x100 */;

    case 86:  /* *movqi_for_initializer */
    case 75:  /* *sub_const_hi */
    case 66:  /* neghi2 */
    case 63:  /* abshi2 */
    case 61:  /* divmodsihi3 */
    case 51:  /* one_cmplqi2 */
    case 50:  /* one_cmplhi2 */
    case 49:  /* xorqi3 */
    case 48:  /* xorhi3 */
    case 28:  /* indirect_jump */
    case 1:  /* call_value */
    case 0:  /* call */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else
        {
	  return 4;
        }

    case 83:  /* *unsigned_qi_hi_shift */
    case 82:  /* *qi_hi_shift */
    case 67:  /* negqi2 */
    case 62:  /* divfixuphi2 */
    case 57:  /* *rsubihi */
      return 6;

    case 73:  /* extendhisi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else if (which_alternative == 1)
        {
	  return 12 /* 0xc */;
        }
      else
        {
	  return 14 /* 0xe */;
        }

    case 71:  /* zero_extendhisi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 4;
        }
      else if (which_alternative == 1)
        {
	  return 8;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 65:  /* negsi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else
        {
	  return 14 /* 0xe */;
        }

    case 60:  /* umulhisi3 */
    case 29:  /* tablejump */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 4;
        }
      else
        {
	  return 6;
        }

    case 59:  /* mulsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 18 /* 0x12 */;
        }
      else if (which_alternative == 1)
        {
	  return 22 /* 0x16 */;
        }
      else
        {
	  return 26 /* 0x1a */;
        }

    case 38:  /* lshrqi3 */
    case 37:  /* lshrhi3 */
    case 35:  /* ashrqi3 */
    case 34:  /* ashrhi3 */
    case 31:  /* ashlhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 36:  /* lshrsi3 */
    case 30:  /* ashlsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 34 /* 0x22 */;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 33:  /* ashrsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 38 /* 0x26 */;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 32:  /* ashlqi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 10 /* 0xa */;
        }
      else
        {
	  return 6;
        }

    case 87:  /* *andi_const */
    case 85:  /* *movhi_combine_consts */
    case 84:  /* *set_consthi2 */
    case 76:  /* *cmpqi_as_hi */
    case 25:  /* bge */
    case 24:  /* *bgt_reversed */
    case 21:  /* ble */
    case 20:  /* *blt_reversed */
      return 4;

    case 4:  /* tstqi */
    case 3:  /* tsthi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else
        {
	  return 6;
        }

    default:
      return 2;

    }
}

int
insn_default_length (rtx insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 68:  /* movqi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else if (which_alternative == 4)
        {
	  return 2;
        }
      else if (which_alternative == 5)
        {
	  return 4;
        }
      else
        {
	  return 2;
        }

    case 58:  /* subqi3 */
    case 56:  /* subhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else if (which_alternative == 4)
        {
	  return 4;
        }
      else if (which_alternative == 5)
        {
	  return 6;
        }
      else if (which_alternative == 6)
        {
	  return 8;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 53:  /* addhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0xe))
        {
	  return 4;
        }
      else
        {
	  return 6;
        }

    case 55:  /* subsi3 */
    case 52:  /* addsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else if (which_alternative == 1)
        {
	  return 10 /* 0xa */;
        }
      else if (which_alternative == 2)
        {
	  return 12 /* 0xc */;
        }
      else if (which_alternative == 3)
        {
	  return 4;
        }
      else if (which_alternative == 4)
        {
	  return 8;
        }
      else if (((1 << which_alternative) & 0x60))
        {
	  return 12 /* 0xc */;
        }
      else if (which_alternative == 7)
        {
	  return 14 /* 0xe */;
        }
      else if (which_alternative == 8)
        {
	  return 16 /* 0x10 */;
        }
      else if (which_alternative == 9)
        {
	  return 4;
        }
      else if (which_alternative == 10)
        {
	  return 12 /* 0xc */;
        }
      else if (((1 << which_alternative) & 0x1800))
        {
	  return 16 /* 0x10 */;
        }
      else if (((1 << which_alternative) & 0x6000))
        {
	  return 18 /* 0x12 */;
        }
      else if (which_alternative == 15)
        {
	  return 6;
        }
      else if (which_alternative == 16)
        {
	  return 12 /* 0xc */;
        }
      else
        {
	  return 18 /* 0x12 */;
        }

    case 69:  /* movhi */
    case 46:  /* iorhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else if (which_alternative == 4)
        {
	  return 4;
        }
      else
        {
	  return 2;
        }

    case 43:  /* andqi3 */
    case 40:  /* andhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 6;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 8;
        }
      else if (which_alternative == 3)
        {
	  return 10 /* 0xa */;
        }
      else if (which_alternative == 4)
        {
	  return 4;
        }
      else if (which_alternative == 5)
        {
	  return 6;
        }
      else
        {
	  return 8;
        }

    case 45:  /* *not_andqi */
    case 44:  /* *andnotqi */
    case 42:  /* *not_andhi */
    case 41:  /* *andnothi */
    case 6:  /* cmpqi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else
        {
	  return 6;
        }

    case 54:  /* addqi3 */
    case 47:  /* iorqi3 */
    case 5:  /* cmphi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else if (((1 << which_alternative) & 0x6))
        {
	  return 4;
        }
      else if (which_alternative == 3)
        {
	  return 6;
        }
      else
        {
	  return 4;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      return 256 /* 0x100 */;

    case 86:  /* *movqi_for_initializer */
    case 75:  /* *sub_const_hi */
    case 66:  /* neghi2 */
    case 63:  /* abshi2 */
    case 61:  /* divmodsihi3 */
    case 51:  /* one_cmplqi2 */
    case 50:  /* one_cmplhi2 */
    case 49:  /* xorqi3 */
    case 48:  /* xorhi3 */
    case 28:  /* indirect_jump */
    case 1:  /* call_value */
    case 0:  /* call */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else
        {
	  return 4;
        }

    case 81:  /* *lshiftrt_qi_to_hi */
    case 80:  /* *ashiftrt_qi_to_hi */
    case 79:  /* *ashift_hi_to_qi */
    case 78:  /* *lshiftrt_hi_to_qi */
    case 77:  /* *ashiftrt_hi_to_qi */
    case 74:  /* nop */
    case 72:  /* extendqihi2 */
    case 70:  /* zero_extendqihi2 */
    case 64:  /* absqi2 */
    case 39:  /* rotrhi3 */
    case 2:  /* *rt */
      return 2;

    case 73:  /* extendhisi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else if (which_alternative == 1)
        {
	  return 12 /* 0xc */;
        }
      else
        {
	  return 14 /* 0xe */;
        }

    case 71:  /* zero_extendhisi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 4;
        }
      else if (which_alternative == 1)
        {
	  return 8;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 65:  /* negsi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else
        {
	  return 14 /* 0xe */;
        }

    case 60:  /* umulhisi3 */
    case 29:  /* tablejump */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 4;
        }
      else
        {
	  return 6;
        }

    case 59:  /* mulsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 18 /* 0x12 */;
        }
      else if (which_alternative == 1)
        {
	  return 22 /* 0x16 */;
        }
      else
        {
	  return 26 /* 0x1a */;
        }

    case 38:  /* lshrqi3 */
    case 37:  /* lshrhi3 */
    case 35:  /* ashrqi3 */
    case 34:  /* ashrhi3 */
    case 31:  /* ashlhi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 6;
        }
      else
        {
	  return 2;
        }

    case 36:  /* lshrsi3 */
    case 30:  /* ashlsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 34 /* 0x22 */;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 33:  /* ashrsi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 38 /* 0x26 */;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 32:  /* ashlqi3 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 10 /* 0xa */;
        }
      else
        {
	  return 6;
        }

    case 87:  /* *andi_const */
    case 85:  /* *movhi_combine_consts */
    case 84:  /* *set_consthi2 */
    case 76:  /* *cmpqi_as_hi */
    case 27:  /* jump */
      return 4;

    case 26:  /* *bge_reversed */
    case 23:  /* bgt */
    case 22:  /* *ble_reversed */
    case 19:  /* blt */
      return 8;

    case 4:  /* tstqi */
    case 3:  /* tsthi */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 2;
        }
      else
        {
	  return 6;
        }

    default:
      return 6;

    }
}

enum attr_type
get_attr_type (rtx insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      return TYPE_UNKNOWN;

    default:
      return TYPE_ARITH;

    }
}

const int length_unit_log = 0;
