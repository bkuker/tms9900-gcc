(define_conditions [
  (-1 "((REGNO(operands[0]) == REGNO(operands[5])) &&
    (REGNO(operands[2]) == (REGNO(operands[0])+1)) &&
    (INTVAL(operands[7]) == 16)
   )")
  (-1 "peep2_reg_dead_p(3, operands[0])")
  (-1 "peep2_reg_dead_p(4, operands[0]) && peep2_reg_dead_p(4, operands[3])")
  (-1 "INTVAL(operands[3]) == 256 && (INTVAL(operands[1]) == 0 || INTVAL(operands[1]) == 255)")
  (-1 "REGNO(operands[0]) == REGNO(operands[2])")
  (-1 "peep2_reg_dead_p(2, operands[0])")
  (-1 "(REGNO(operands[0]) == REGNO(operands[3])) && (INTVAL(operands[5]) == (1<<(8-INTVAL(operands[2])))-1)")
  (-1 "(REGNO(operands[0]) == REGNO(operands[3]))")
])
