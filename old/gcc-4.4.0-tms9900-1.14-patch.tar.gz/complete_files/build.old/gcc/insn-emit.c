/* Generated automatically by the program `genemit'
from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "rtl.h"
#include "tm_p.h"
#include "function.h"
#include "expr.h"
#include "optabs.h"
#include "real.h"
#include "dfp.h"
#include "flags.h"
#include "output.h"
#include "insn-config.h"
#include "hard-reg-set.h"
#include "recog.h"
#include "resource.h"
#include "reload.h"
#include "toplev.h"
#include "regs.h"
#include "tm-constrs.h"
#include "ggc.h"
#include "basic-block.h"
#include "integrate.h"

#define FAIL return (end_sequence (), _val)
#define DONE return (_val = get_insns (), end_sequence (), _val)

/* ../../gcc/config/tms9900/tms9900.md:88 */
rtx
gen_call (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_CALL (VOIDmode,
	operand0,
	operand1);
}

/* ../../gcc/config/tms9900/tms9900.md:106 */
rtx
gen_call_value (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_CALL (VOIDmode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:168 */
rtx
gen_tsthi (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	cc0_rtx,
	operand0);
}

/* ../../gcc/config/tms9900/tms9900.md:183 */
rtx
gen_tstqi (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	cc0_rtx,
	operand0);
}

/* ../../gcc/config/tms9900/tms9900.md:192 */
rtx
gen_cmphi (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand0,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:208 */
rtx
gen_cmpqi (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand0,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:224 */
rtx
gen_beq (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_EQ (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:268 */
rtx
gen_bne (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_NE (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:308 */
rtx
gen_bltu (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LTU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:348 */
rtx
gen_bleu (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LEU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:388 */
rtx
gen_bgtu (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GTU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:428 */
rtx
gen_bgeu (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GEU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:468 */
rtx
gen_blt (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LT (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:509 */
rtx
gen_ble (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LE (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:549 */
rtx
gen_bgt (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GT (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:591 */
rtx
gen_bge (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GE (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand0),
	pc_rtx));
}

/* ../../gcc/config/tms9900/tms9900.md:636 */
rtx
gen_jump (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_LABEL_REF (VOIDmode,
	operand0));
}

/* ../../gcc/config/tms9900/tms9900.md:654 */
rtx
gen_indirect_jump (rtx operand0 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	pc_rtx,
	operand0);
}

/* ../../gcc/config/tms9900/tms9900.md:663 */
rtx
gen_tablejump (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (3,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_SET (VOIDmode,
	pc_rtx,
	operand0),
		gen_rtx_USE (VOIDmode,
	gen_rtx_LABEL_REF (VOIDmode,
	operand1))));
}

/* ../../gcc/config/tms9900/tms9900.md:686 */
rtx
gen_ashlsi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (2,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFT (SImode,
	operand1,
	operand2))));
}

/* ../../gcc/config/tms9900/tms9900.md:758 */
rtx
gen_ashlhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFT (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:780 */
rtx
gen_ashlqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFT (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:825 */
rtx
gen_ashrsi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (2,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFTRT (SImode,
	operand1,
	operand2))));
}

/* ../../gcc/config/tms9900/tms9900.md:901 */
rtx
gen_ashrhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFTRT (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:923 */
rtx
gen_ashrqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFTRT (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:967 */
rtx
gen_lshrsi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (2,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_LSHIFTRT (SImode,
	operand1,
	operand2))));
}

/* ../../gcc/config/tms9900/tms9900.md:1039 */
rtx
gen_lshrhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_LSHIFTRT (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1061 */
rtx
gen_lshrqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_LSHIFTRT (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1123 */
rtx
gen_rotrhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ROTATERT (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1144 */
rtx
gen_andhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (2,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_AND (HImode,
	operand1,
	operand2))));
}

/* ../../gcc/config/tms9900/tms9900.md:1212 */
rtx
gen_andqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (2,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (QImode)),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_AND (QImode,
	operand1,
	operand2))));
}

/* ../../gcc/config/tms9900/tms9900.md:1289 */
rtx
gen_iorhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_IOR (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1311 */
rtx
gen_iorqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_IOR (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1338 */
rtx
gen_xorhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_XOR (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1348 */
rtx
gen_xorqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_XOR (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1362 */
rtx
gen_one_cmplhi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_NOT (HImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1371 */
rtx
gen_one_cmplqi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_NOT (QImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1389 */
rtx
gen_addsi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_PLUS (SImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1468 */
rtx
gen_addhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_PLUS (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1507 */
rtx
gen_addqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_PLUS (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1528 */
rtx
gen_subsi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_MINUS (SImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1585 */
rtx
gen_subhi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_MINUS (HImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1633 */
rtx
gen_subqi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_MINUS (QImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1658 */
rtx
gen_mulsi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (3,
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_MULT (SImode,
	operand1,
	operand2)),
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode))));
}

/* ../../gcc/config/tms9900/tms9900.md:1707 */
rtx
gen_umulhisi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_MULT (SImode,
	operand1,
	operand2));
}

/* ../../gcc/config/tms9900/tms9900.md:1757 */
rtx
gen_divmodsihi3 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED,
	rtx operand2 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_IOR (SImode,
	gen_rtx_ASHIFT (SImode,
	gen_rtx_ZERO_EXTEND (SImode,
	gen_rtx_DIV (HImode,
	operand1,
	operand2)),
	const_int_rtx[MAX_SAVED_CONST_INT + (16)]),
	gen_rtx_ZERO_EXTEND (SImode,
	gen_rtx_MOD (HImode,
	operand1,
	operand2))));
}

/* ../../gcc/config/tms9900/tms9900.md:1856 */
rtx
gen_divfixuphi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_PARALLEL (VOIDmode, gen_rtvec (2,
		gen_rtx_SET (VOIDmode,
	operand1,
	gen_rtx_NOT (HImode,
	copy_rtx (operand1))),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_IF_THEN_ELSE (HImode,
	gen_rtx_LT (HImode,
	copy_rtx (operand1),
	const0_rtx),
	gen_rtx_NEG (HImode,
	copy_rtx (operand0)),
	copy_rtx (operand0)))));
}

/* ../../gcc/config/tms9900/tms9900.md:1877 */
rtx
gen_abshi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ABS (HImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1886 */
rtx
gen_absqi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ABS (QImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1899 */
rtx
gen_negsi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_NEG (SImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1929 */
rtx
gen_neghi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_NEG (HImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1938 */
rtx
gen_negqi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_NEG (QImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:1957 */
rtx
gen_movqi (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	operand1);
}

/* ../../gcc/config/tms9900/tms9900.md:2023 */
rtx
gen_movhi (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	operand1);
}

/* ../../gcc/config/tms9900/tms9900.md:2059 */
rtx
gen_zero_extendqihi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ZERO_EXTEND (HImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:2068 */
rtx
gen_zero_extendhisi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ZERO_EXTEND (SImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:2090 */
rtx
gen_extendqihi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_SIGN_EXTEND (HImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:2099 */
rtx
gen_extendhisi2 (rtx operand0 ATTRIBUTE_UNUSED,
	rtx operand1 ATTRIBUTE_UNUSED)
{
  return gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_SIGN_EXTEND (SImode,
	operand1));
}

/* ../../gcc/config/tms9900/tms9900.md:2134 */
rtx
gen_nop (void)
{
  return const0_rtx;
}

/* ../../gcc/config/tms9900/tms9900.md:125 */
rtx
gen_prologue (void)
{
  rtx _val = 0;
  start_sequence ();
  {
#line 128 "../../gcc/config/tms9900/tms9900.md"
{
  tms9900_expand_prologue();
  DONE;
}
  }
  emit_insn (const0_rtx);
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:136 */
rtx
gen_epilogue (void)
{
  rtx _val = 0;
  start_sequence ();
  {
#line 139 "../../gcc/config/tms9900/tms9900.md"
{
  tms9900_expand_epilogue(false);
  DONE;
}
  }
  emit_jump_insn (gen_rtx_RETURN (VOIDmode));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:144 */
rtx
gen_sibcall_epilogue (void)
{
  rtx _val = 0;
  start_sequence ();
  {
#line 147 "../../gcc/config/tms9900/tms9900.md"
{
  tms9900_expand_epilogue(true);
  DONE;
}
  }
  emit_jump_insn (gen_rtx_RETURN (VOIDmode));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:806 */
extern rtx gen_peephole2_91 (rtx, rtx *);
rtx
gen_peephole2_91 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
#line 819 "../../gcc/config/tms9900/tms9900.md"

  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	operand1));
  emit_insn (gen_rtx_SET (VOIDmode,
	copy_rtx (operand2),
	gen_rtx_ASHIFT (QImode,
	copy_rtx (operand2),
	operand3)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:945 */
extern rtx gen_peephole2_92 (rtx, rtx *);
rtx
gen_peephole2_92 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx operand5;
  rtx operand6;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
#line 959 "../../gcc/config/tms9900/tms9900.md"

  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  operand4 = operands[4];
  operand5 = operands[5];
  operand6 = operands[6];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand6,
	operand1));
  emit_insn (gen_rtx_SET (VOIDmode,
	copy_rtx (operand6),
	gen_rtx_ASHIFTRT (QImode,
	copy_rtx (operand6),
	operand5)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:1082 */
extern rtx gen_peephole2_93 (rtx, rtx *);
rtx
gen_peephole2_93 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx operand5;
  rtx operand6;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
#line 1096 "../../gcc/config/tms9900/tms9900.md"

  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  operand4 = operands[4];
  operand5 = operands[5];
  operand6 = operands[6];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand6,
	operand1));
  emit_insn (gen_rtx_SET (VOIDmode,
	copy_rtx (operand6),
	gen_rtx_LSHIFTRT (QImode,
	copy_rtx (operand6),
	operand5)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:1105 */
rtx
gen_rotlhi3 (rtx operand0,
	rtx operand1,
	rtx operand2)
{
  rtx _val = 0;
  start_sequence ();
  {
    rtx operands[3];
    operands[0] = operand0;
    operands[1] = operand1;
    operands[2] = operand2;
#line 1110 "../../gcc/config/tms9900/tms9900.md"
{
    if (GET_CODE (operands[2]) == CONST_INT)
      operands[2] = GEN_INT ((16 - INTVAL (operands[2])) % 16);
    else
      {
        rtx reg = gen_reg_rtx (HImode);
        emit_insn (gen_subhi3 (reg, GEN_INT (16), operands[2]));
        operands[2] = reg;
      }
  }
    operand0 = operands[0];
    operand1 = operands[1];
    operand2 = operands[2];
  }
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ROTATERT (HImode,
	operand1,
	operand2)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:1742 */
rtx
gen_mulhi3 (rtx operand0,
	rtx operand1,
	rtx operand2)
{
  rtx operand3;
  rtx _val = 0;
  start_sequence ();
  {
    rtx operands[4];
    operands[0] = operand0;
    operands[1] = operand1;
    operands[2] = operand2;
#line 1749 "../../gcc/config/tms9900/tms9900.md"
operands[3] = force_reg(SImode, GEN_INT(0));
    operand0 = operands[0];
    operand1 = operands[1];
    operand2 = operands[2];
    operand3 = operands[3];
  }
  emit_insn (gen_rtx_SET (VOIDmode,
	operand3,
	gen_rtx_MULT (SImode,
	operand1,
	operand2)));
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_SUBREG (HImode,
	copy_rtx (operand3),
	2)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:1773 */
rtx
gen_udivmodhi4 (rtx operand0,
	rtx operand1,
	rtx operand2,
	rtx operand3)
{
  rtx _val = 0;
  start_sequence ();
  {
    rtx operands[4];
    operands[0] = operand0;
    operands[1] = operand1;
    operands[2] = operand2;
    operands[3] = operand3;
#line 1782 "../../gcc/config/tms9900/tms9900.md"
{
    rtx insn, div_equal, mod_equal, equal;
    div_equal = gen_rtx_DIV (HImode, operands[1], operands[2]);
    mod_equal = gen_rtx_MOD (HImode, operands[1], operands[2]);
    equal = gen_rtx_IOR (SImode,
                         gen_rtx_ASHIFT (SImode,
                                         gen_rtx_ZERO_EXTEND (SImode, div_equal),
                                         GEN_INT (16)),
                         gen_rtx_ZERO_EXTEND (SImode, mod_equal));

    insn = emit_insn (gen_divmodsihi3 (operands[1], operands[1], operands[2]));
    set_unique_reg_note (insn, REG_EQUAL, equal);

    insn = emit_move_insn (operands[0], gen_highpart (HImode, operands[1]));
    set_unique_reg_note (insn, REG_EQUAL, mod_equal);

    insn = emit_move_insn (operands[3], gen_lowpart (HImode, operands[1]));
    set_unique_reg_note (insn, REG_EQUAL, div_equal);

    DONE;
  }
    operand0 = operands[0];
    operand1 = operands[1];
    operand2 = operands[2];
    operand3 = operands[3];
  }
  emit (gen_rtx_PARALLEL (VOIDmode,
	gen_rtvec (2,
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_DIV (HImode,
	operand1,
	operand2)),
		gen_rtx_SET (VOIDmode,
	operand3,
	gen_rtx_MOD (HImode,
	copy_rtx (operand1),
	copy_rtx (operand2))))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:1806 */
rtx
gen_divmodhi4 (rtx operand0,
	rtx operand1,
	rtx operand2,
	rtx operand3)
{
  rtx operand4 ATTRIBUTE_UNUSED;
  rtx operand5 ATTRIBUTE_UNUSED;
  rtx operand6 ATTRIBUTE_UNUSED;
  rtx operand7 ATTRIBUTE_UNUSED;
  rtx operand8 ATTRIBUTE_UNUSED;
  rtx _val = 0;
  start_sequence ();
  {
    rtx operands[9];
    operands[0] = operand0;
    operands[1] = operand1;
    operands[2] = operand2;
    operands[3] = operand3;
#line 1821 "../../gcc/config/tms9900/tms9900.md"
{
    operands[4] = gen_reg_rtx(HImode);
    operands[5] = gen_reg_rtx(HImode);
    operands[6] = gen_reg_rtx(SImode);
    operands[7] = gen_reg_rtx(HImode);
    operands[8] = gen_reg_rtx(HImode);

    /* Use temp for operands */
    emit_move_insn(operands[7], operands[1]);
    emit_move_insn(operands[8], operands[2]);

    /* Find quotient sign */
    emit_move_insn(operands[4], operands[1]);
    emit_insn(gen_xorhi3(operands[4], operands[4], operands[8]));
  
    /* Find modulus sign */
    emit_move_insn(operands[5], operands[1]);

    /* Convert operands to absolute value */
    emit_insn(gen_abshi2(operands[7], operands[7]));
    emit_insn(gen_abshi2(operands[8], operands[8]));

    /* Perform division and modulus */
    emit_move_insn(operands[6],gen_rtx_ZERO_EXTEND(SImode, operands[7]));
    emit_insn(gen_udivmodhi4(operands[0], operands[6], operands[8], operands[3]));

    /* Correct sign of results */
    emit_insn(gen_divfixuphi2(operands[0], operands[4]));  /* Correct quotient sign */
    emit_insn(gen_divfixuphi2(operands[3], operands[5]));  /* Correct modulus sign */

    DONE;
  }
    operand0 = operands[0];
    operand1 = operands[1];
    operand2 = operands[2];
    operand3 = operands[3];
    operand4 = operands[4];
    operand5 = operands[5];
    operand6 = operands[6];
    operand7 = operands[7];
    operand8 = operands[8];
  }
  emit (gen_rtx_PARALLEL (VOIDmode,
	gen_rtvec (7,
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (SImode)),
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode)),
		gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_DIV (HImode,
	operand1,
	operand2)),
		gen_rtx_SET (VOIDmode,
	operand3,
	gen_rtx_MOD (HImode,
	copy_rtx (operand1),
	copy_rtx (operand2))))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2148 */
extern rtx gen_peephole2_98 (rtx, rtx *);
rtx
gen_peephole2_98 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_PLUS (HImode,
	copy_rtx (operand0),
	gen_rtx_NEG (HImode,
	operand1))));
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	copy_rtx (operand0)));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_EQ (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand2),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2187 */
extern rtx gen_peephole2_99 (rtx, rtx *);
rtx
gen_peephole2_99 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_PLUS (HImode,
	copy_rtx (operand0),
	gen_rtx_NEG (HImode,
	operand1))));
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	copy_rtx (operand0)));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_NE (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand2),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2211 */
extern rtx gen_peephole2_100 (rtx, rtx *);
rtx
gen_peephole2_100 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	GEN_INT (255L),
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GTU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2248 */
extern rtx gen_peephole2_101 (rtx, rtx *);
rtx
gen_peephole2_101 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	const0_rtx,
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LTU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2271 */
extern rtx gen_peephole2_102 (rtx, rtx *);
rtx
gen_peephole2_102 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	const0_rtx,
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GEU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2294 */
extern rtx gen_peephole2_103 (rtx, rtx *);
rtx
gen_peephole2_103 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	GEN_INT (255L),
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LEU (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2317 */
extern rtx gen_peephole2_104 (rtx, rtx *);
rtx
gen_peephole2_104 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	GEN_INT (255L),
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GT (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2340 */
extern rtx gen_peephole2_105 (rtx, rtx *);
rtx
gen_peephole2_105 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	const0_rtx,
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LT (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2363 */
extern rtx gen_peephole2_106 (rtx, rtx *);
rtx
gen_peephole2_106 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	const0_rtx,
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_GE (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2386 */
extern rtx gen_peephole2_107 (rtx, rtx *);
rtx
gen_peephole2_107 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	cc0_rtx,
	gen_rtx_COMPARE (VOIDmode,
	operand2,
	gen_rtx_PLUS (HImode,
	GEN_INT (255L),
	gen_rtx_MULT (HImode,
	operand1,
	GEN_INT (256L))))));
  emit_jump_insn (gen_rtx_SET (VOIDmode,
	pc_rtx,
	gen_rtx_IF_THEN_ELSE (VOIDmode,
	gen_rtx_LE (VOIDmode,
	cc0_rtx,
	const0_rtx),
	gen_rtx_LABEL_REF (VOIDmode,
	operand3),
	pc_rtx)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2414 */
extern rtx gen_peephole2_108 (rtx, rtx *);
rtx
gen_peephole2_108 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFTRT (HImode,
	copy_rtx (operand0),
	gen_rtx_MINUS (HImode,
	operand1,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2452 */
extern rtx gen_peephole2_109 (rtx, rtx *);
rtx
gen_peephole2_109 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_LSHIFTRT (HImode,
	copy_rtx (operand0),
	gen_rtx_MINUS (HImode,
	operand1,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2491 */
extern rtx gen_peephole2_110 (rtx, rtx *);
rtx
gen_peephole2_110 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFT (HImode,
	copy_rtx (operand0),
	gen_rtx_PLUS (HImode,
	operand1,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2521 */
extern rtx gen_peephole2_111 (rtx, rtx *);
rtx
gen_peephole2_111 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	gen_rtx_ASHIFTRT (HImode,
	copy_rtx (operand2),
	gen_rtx_PLUS (HImode,
	operand1,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2535 */
extern rtx gen_peephole2_112 (rtx, rtx *);
rtx
gen_peephole2_112 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	gen_rtx_ASHIFTRT (HImode,
	copy_rtx (operand2),
	gen_rtx_PLUS (HImode,
	operand3,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2567 */
extern rtx gen_peephole2_113 (rtx, rtx *);
rtx
gen_peephole2_113 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_LSHIFTRT (HImode,
	copy_rtx (operand0),
	gen_rtx_PLUS (HImode,
	operand2,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2600 */
extern rtx gen_peephole2_114 (rtx, rtx *);
rtx
gen_peephole2_114 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx operand5;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  operand4 = operands[4];
  operand5 = operands[5];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_ASHIFTRT (HImode,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)],
	gen_rtx_ASHIFT (HImode,
	copy_rtx (operand0),
	operand5))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2643 */
extern rtx gen_peephole2_115 (rtx, rtx *);
rtx
gen_peephole2_115 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx operand5;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  operand4 = operands[4];
  operand5 = operands[5];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	gen_rtx_LSHIFTRT (HImode,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)],
	gen_rtx_ASHIFT (HImode,
	copy_rtx (operand0),
	operand5))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2693 */
extern rtx gen_peephole2_116 (rtx, rtx *);
rtx
gen_peephole2_116 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	operand1));
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	const0_rtx));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2741 */
extern rtx gen_peephole2_117 (rtx, rtx *);
rtx
gen_peephole2_117 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand0,
	operand3));
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	const0_rtx));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2776 */
extern rtx gen_peephole2_118 (rtx, rtx *);
rtx
gen_peephole2_118 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx operand5;
  rtx operand6;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  if ((operands[6] = peep2_find_free_register (0, 0, "r,r", HImode, &_regs_allocated)) == NULL_RTX)
    return NULL;
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  operand3 = operands[3];
  operand4 = operands[4];
  operand5 = operands[5];
  operand6 = operands[6];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand6,
	gen_rtx_IOR (HImode,
	gen_rtx_ASHIFT (HImode,
	operand1,
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]),
	operand4)));
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	gen_rtx_SUBREG (QImode,
	gen_rtx_ASHIFTRT (HImode,
	copy_rtx (operand6),
	const_int_rtx[MAX_SAVED_CONST_INT + (8)]),
	1)));
  emit_insn (gen_rtx_SET (VOIDmode,
	operand5,
	gen_rtx_SUBREG (QImode,
	gen_rtx_ASHIFTRT (HImode,
	copy_rtx (operand6),
	const0_rtx),
	1)));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2835 */
extern rtx gen_peephole2_119 (rtx, rtx *);
rtx
gen_peephole2_119 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	operand1));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2846 */
extern rtx gen_peephole2_120 (rtx, rtx *);
rtx
gen_peephole2_120 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	operand1));
  _val = get_insns ();
  end_sequence ();
  return _val;
}

/* ../../gcc/config/tms9900/tms9900.md:2859 */
extern rtx gen_peephole2_121 (rtx, rtx *);
rtx
gen_peephole2_121 (rtx curr_insn ATTRIBUTE_UNUSED, rtx *operands)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  HARD_REG_SET _regs_allocated;
  CLEAR_HARD_REG_SET (_regs_allocated);
  start_sequence ();
  operand0 = operands[0];
  operand1 = operands[1];
  operand2 = operands[2];
  emit_insn (gen_rtx_SET (VOIDmode,
	operand2,
	operand1));
  emit_insn (gen_rtx_SET (VOIDmode,
	copy_rtx (operand2),
	gen_rtx_AND (HImode,
	copy_rtx (operand2),
	GEN_INT (255L))));
  _val = get_insns ();
  end_sequence ();
  return _val;
}



void
add_clobbers (rtx pattern ATTRIBUTE_UNUSED, int insn_code_number)
{
  switch (insn_code_number)
    {
    case 59:
      XVECEXP (pattern, 0, 1) = gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode));
      XVECEXP (pattern, 0, 2) = gen_rtx_CLOBBER (VOIDmode,
	gen_rtx_SCRATCH (HImode));
      break;

    default:
      gcc_unreachable ();
    }
}


int
added_clobbers_hard_reg_p (int insn_code_number)
{
  switch (insn_code_number)
    {
    case 59:
      return 0;

    default:
      gcc_unreachable ();
    }
}
