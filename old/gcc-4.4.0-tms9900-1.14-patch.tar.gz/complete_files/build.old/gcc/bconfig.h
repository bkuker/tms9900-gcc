#ifndef GCC_BCONFIG_H
#define GCC_BCONFIG_H
#include "auto-host.h"
#ifdef IN_GCC
# include "ansidecl.h"
#endif
#endif /* GCC_BCONFIG_H */
