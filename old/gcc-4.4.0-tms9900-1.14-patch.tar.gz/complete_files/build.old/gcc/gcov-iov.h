/* Generated automatically by the program `build/gcov-iov'
   from `4.4.0 (4 4) and TMS9900 patch @@TMS9900_PATCH_VERSION@@ (T)'.  */

#define GCOV_VERSION ((gcov_unsigned_t)0x34303454)  /* 404T */
