/* Generated automatically by the program 'build/genpreds'
   from the machine description file '../../gcc/config/tms9900/tms9900.md'.  */

#ifndef GCC_TM_CONSTRS_H
#define GCC_TM_CONSTRS_H

#endif /* tm-constrs.h */
