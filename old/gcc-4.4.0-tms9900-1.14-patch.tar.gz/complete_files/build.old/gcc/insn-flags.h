/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_tsthi 1
#define HAVE_tstqi 1
#define HAVE_cmphi 1
#define HAVE_cmpqi 1
#define HAVE_beq 1
#define HAVE_bne 1
#define HAVE_bltu 1
#define HAVE_bleu 1
#define HAVE_bgtu 1
#define HAVE_bgeu 1
#define HAVE_blt 1
#define HAVE_ble 1
#define HAVE_bgt 1
#define HAVE_bge 1
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_tablejump 1
#define HAVE_ashlsi3 1
#define HAVE_ashlhi3 1
#define HAVE_ashlqi3 1
#define HAVE_ashrsi3 1
#define HAVE_ashrhi3 1
#define HAVE_ashrqi3 1
#define HAVE_lshrsi3 1
#define HAVE_lshrhi3 1
#define HAVE_lshrqi3 1
#define HAVE_rotrhi3 1
#define HAVE_andhi3 1
#define HAVE_andqi3 1
#define HAVE_iorhi3 1
#define HAVE_iorqi3 1
#define HAVE_xorhi3 1
#define HAVE_xorqi3 1
#define HAVE_one_cmplhi2 1
#define HAVE_one_cmplqi2 1
#define HAVE_addsi3 1
#define HAVE_addhi3 1
#define HAVE_addqi3 1
#define HAVE_subsi3 1
#define HAVE_subhi3 1
#define HAVE_subqi3 1
#define HAVE_mulsi3 1
#define HAVE_umulhisi3 1
#define HAVE_divmodsihi3 1
#define HAVE_divfixuphi2 1
#define HAVE_abshi2 1
#define HAVE_absqi2 1
#define HAVE_negsi2 1
#define HAVE_neghi2 1
#define HAVE_negqi2 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_zero_extendqihi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_extendqihi2 1
#define HAVE_extendhisi2 1
#define HAVE_nop 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_rotlhi3 1
#define HAVE_mulhi3 1
#define HAVE_udivmodhi4 1
#define HAVE_divmodhi4 1
#define GEN_CALL(A, B, C, D) gen_call ((A), (B))
extern rtx        gen_call             (rtx, rtx);
#define GEN_CALL_VALUE(A, B, C, D, E) gen_call_value ((A), (B), (C))
extern rtx        gen_call_value       (rtx, rtx, rtx);
extern rtx        gen_tsthi            (rtx);
extern rtx        gen_tstqi            (rtx);
extern rtx        gen_cmphi            (rtx, rtx);
extern rtx        gen_cmpqi            (rtx, rtx);
extern rtx        gen_beq              (rtx);
extern rtx        gen_bne              (rtx);
extern rtx        gen_bltu             (rtx);
extern rtx        gen_bleu             (rtx);
extern rtx        gen_bgtu             (rtx);
extern rtx        gen_bgeu             (rtx);
extern rtx        gen_blt              (rtx);
extern rtx        gen_ble              (rtx);
extern rtx        gen_bgt              (rtx);
extern rtx        gen_bge              (rtx);
extern rtx        gen_jump             (rtx);
extern rtx        gen_indirect_jump    (rtx);
extern rtx        gen_tablejump        (rtx, rtx);
extern rtx        gen_ashlsi3          (rtx, rtx, rtx);
extern rtx        gen_ashlhi3          (rtx, rtx, rtx);
extern rtx        gen_ashlqi3          (rtx, rtx, rtx);
extern rtx        gen_ashrsi3          (rtx, rtx, rtx);
extern rtx        gen_ashrhi3          (rtx, rtx, rtx);
extern rtx        gen_ashrqi3          (rtx, rtx, rtx);
extern rtx        gen_lshrsi3          (rtx, rtx, rtx);
extern rtx        gen_lshrhi3          (rtx, rtx, rtx);
extern rtx        gen_lshrqi3          (rtx, rtx, rtx);
extern rtx        gen_rotrhi3          (rtx, rtx, rtx);
extern rtx        gen_andhi3           (rtx, rtx, rtx);
extern rtx        gen_andqi3           (rtx, rtx, rtx);
extern rtx        gen_iorhi3           (rtx, rtx, rtx);
extern rtx        gen_iorqi3           (rtx, rtx, rtx);
extern rtx        gen_xorhi3           (rtx, rtx, rtx);
extern rtx        gen_xorqi3           (rtx, rtx, rtx);
extern rtx        gen_one_cmplhi2      (rtx, rtx);
extern rtx        gen_one_cmplqi2      (rtx, rtx);
extern rtx        gen_addsi3           (rtx, rtx, rtx);
extern rtx        gen_addhi3           (rtx, rtx, rtx);
extern rtx        gen_addqi3           (rtx, rtx, rtx);
extern rtx        gen_subsi3           (rtx, rtx, rtx);
extern rtx        gen_subhi3           (rtx, rtx, rtx);
extern rtx        gen_subqi3           (rtx, rtx, rtx);
extern rtx        gen_mulsi3           (rtx, rtx, rtx);
extern rtx        gen_umulhisi3        (rtx, rtx, rtx);
extern rtx        gen_divmodsihi3      (rtx, rtx, rtx);
extern rtx        gen_divfixuphi2      (rtx, rtx);
extern rtx        gen_abshi2           (rtx, rtx);
extern rtx        gen_absqi2           (rtx, rtx);
extern rtx        gen_negsi2           (rtx, rtx);
extern rtx        gen_neghi2           (rtx, rtx);
extern rtx        gen_negqi2           (rtx, rtx);
extern rtx        gen_movqi            (rtx, rtx);
extern rtx        gen_movhi            (rtx, rtx);
extern rtx        gen_zero_extendqihi2 (rtx, rtx);
extern rtx        gen_zero_extendhisi2 (rtx, rtx);
extern rtx        gen_extendqihi2      (rtx, rtx);
extern rtx        gen_extendhisi2      (rtx, rtx);
extern rtx        gen_nop              (void);
extern rtx        gen_prologue         (void);
extern rtx        gen_epilogue         (void);
extern rtx        gen_sibcall_epilogue (void);
extern rtx        gen_rotlhi3          (rtx, rtx, rtx);
extern rtx        gen_mulhi3           (rtx, rtx, rtx);
extern rtx        gen_udivmodhi4       (rtx, rtx, rtx, rtx);
extern rtx        gen_divmodhi4        (rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
