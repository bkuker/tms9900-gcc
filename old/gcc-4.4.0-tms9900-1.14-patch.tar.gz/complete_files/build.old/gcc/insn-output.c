/* Generated automatically by the program `genoutput'
   from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "flags.h"
#include "ggc.h"
#include "rtl.h"
#include "expr.h"
#include "insn-codes.h"
#include "tm_p.h"
#include "function.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "real.h"
#include "insn-config.h"

#include "conditions.h"
#include "insn-attr.h"

#include "recog.h"

#include "toplev.h"
#include "output.h"
#include "target.h"
#include "tm-constrs.h"

static const char *
output_0 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 93 "../../gcc/config/tms9900/tms9900.md"
{
    if(SIBLING_CALL_P(insn))
      output_asm_insn("b    %0", operands);
    else
      output_asm_insn("bl   %0", operands);
    return("");
  }
}

static const char *
output_1 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 112 "../../gcc/config/tms9900/tms9900.md"
{
    if(SIBLING_CALL_P(insn))
      output_asm_insn("b    %1", operands);
    else
      output_asm_insn("bl   %1", operands);
    return("");
  }
}

static const char *
output_3 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 172 "../../gcc/config/tms9900/tms9900.md"
{
    if(GET_CODE(operands[0]) == REG && find_regno_note(insn, REG_DEAD, REGNO(operands[0])))
    {
       return("abs  %0");
    }
    return("mov  %0, %0");
  }
}

static const char *
output_5 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 197 "../../gcc/config/tms9900/tms9900.md"
{
    if (which_alternative == 4)
    {
       return("ci   %0, %1");
    }
    return("c    %0, %1");
  }
}

static const char *
output_7 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 231 "../../gcc/config/tms9900/tms9900.md"
{
    return(output_branch("jeq", "jne", get_attr_length(insn)));
  }
}

static const char *
output_8 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 253 "../../gcc/config/tms9900/tms9900.md"
{
    return(output_branch("jne", "jeq", get_attr_length(insn)));
  }
}

static const char *
output_9 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 275 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jne", "jeq", get_attr_length(insn));
}

static const char *
output_10 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 295 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jeq", "jne", get_attr_length(insn));
}

static const char *
output_11 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 315 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jl", "jhe", get_attr_length(insn));
}

static const char *
output_12 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 335 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jhe", "jl", get_attr_length(insn));
}

static const char *
output_13 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 355 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jle", "jh", get_attr_length(insn));
}

static const char *
output_14 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 375 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jh", "jle", get_attr_length(insn));
}

static const char *
output_15 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 395 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jh", "jle", get_attr_length(insn));
}

static const char *
output_16 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 415 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jle", "jh", get_attr_length(insn));
}

static const char *
output_17 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 435 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jhe", "jl", get_attr_length(insn));
}

static const char *
output_18 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 455 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jl", "jhe", get_attr_length(insn));
}

static const char *
output_19 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 475 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jlt", "GE", get_attr_length(insn));
}

static const char *
output_20 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 496 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("GE", "jlt", get_attr_length(insn));
}

static const char *
output_21 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 516 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("LE", "jgt", get_attr_length(insn));
}

static const char *
output_22 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 536 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jgt", "LE", get_attr_length(insn));
}

static const char *
output_23 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 556 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jgt", "LE", get_attr_length(insn));
}

static const char *
output_24 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 577 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("LE", "jgt", get_attr_length(insn));
}

static const char *
output_25 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 598 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("GE", "jlt", get_attr_length(insn));
}

static const char *
output_26 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 618 "../../gcc/config/tms9900/tms9900.md"
 return output_branch("jlt", "GE", get_attr_length(insn));
}

static const char *
output_27 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 640 "../../gcc/config/tms9900/tms9900.md"

  return output_jump(get_attr_length(insn));
}

static const char *
output_29 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 668 "../../gcc/config/tms9900/tms9900.md"
{
    output_asm_insn("mov  %0, %2", operands);
    output_asm_insn("b    *%2",    operands);
    return(""); 
  }
}

static const char *
output_30 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 692 "../../gcc/config/tms9900/tms9900.md"
{
    rtx ops[7];
    ops[0] = operands[0];  /* Destination */
    ops[1] = operands[1];  /* Source */
    ops[2] = operands[2];  /* Shift count */
    ops[3] = operands[3];  /* Scratch reg */
    ops[4] = gen_rtx_REG (HImode, REGNO (operands[0]) + REGS_PER_WORD);  /* Low word of source */
    if(which_alternative == 0)
    {
      /* Variable shift */
      output_asm_insn("ci   %2, 16",  ops);  /* +0: Compare shift to 16 */
      output_asm_insn("jlt  $+12",    ops);  /* +4: If shift was < 16, goto lt_16 */
      output_asm_insn("jeq  $+4",     ops);  /* +6: If shift was 16, goto eq_16 */
     
      /* Shift count greater than 16 */
      output_asm_insn("sla  %4, %2",  ops);  /* +8: Shift low word */

      /* eq_16: Shift count equals 16 */
      output_asm_insn("mov  %4, %1",  ops);  /* +10: Copy low word to high word */ 
      output_asm_insn("clr  %4",      ops);  /* +12: Clear low word */
      output_asm_insn("jmp  $+20",    ops);  /* +14: Goto end */

      /* lt_16: Shift count less than 16 */
      output_asm_insn("abs  %2",      ops);  /* +16: Test shift count */
      output_asm_insn("jeq  $+16",    ops);  /* +18: If shift==0, goto end */
      output_asm_insn("mov  %4, %3",  ops);  /* +20: Save low word to temp */
      output_asm_insn("sla  %1, %2",  ops);  /* +22: Shift high word */
      output_asm_insn("sla  %4, %2",  ops);  /* +24: Shift low word */
      output_asm_insn("neg  %2",      ops);  /* +26: Get complement of shift count */
      output_asm_insn("srl  %3, %2",  ops);  /* +28: Shift low word bits into high word position */
      output_asm_insn("soc  %3, %1",  ops);  /* +30: Merge shifted low word bits into high word */
      output_asm_insn("neg  %2",      ops);  /* +32: Restore shift count */
      /* +34: End */
    }
    else
    {
      /* Constant shift */
      int offset = INTVAL(operands[2]);
      ops[5] = GEN_INT(16-offset);  /* Complement of shift count */
      ops[6] = GEN_INT(offset%16);  /* Modulo of shift count */
  
      if(offset < 16)
      {
        output_asm_insn("mov  %4, %3", ops);  /* Save low word to temp */
        output_asm_insn("sla  %1, %2", ops);  /* Shift high word */
        output_asm_insn("sla  %4, %2", ops);  /* Shift low word */
        output_asm_insn("srl  %3, %5", ops);  /* Shift low word bits into high word position */
        output_asm_insn("soc  %3, %1", ops);  /* Merge low word bits into high word */
      } 
      else
      {
        if(offset > 16)
        {
          output_asm_insn("sla  %4, %6", ops);  /* Shift low word */
        }
        output_asm_insn("mov  %4, %1", ops);  /* Move low word into high word */
        output_asm_insn("clr  %4",     ops);  /* Clear low word */
      }
    }
    return "";
  }
}

static const char *
output_31 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 763 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative == 0)
    {
      output_asm_insn("abs  r0",     operands);
      output_asm_insn("jeq  $+4",    operands);
      output_asm_insn("sla  %0, 0",  operands);
    }
    else if(INTVAL(operands[2]) > 0)
    {
      output_asm_insn("sla  %0, %2", operands);
    }
    return(""); 
  }
}

static const char *
output_32 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 785 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative == 0)
    {
      output_asm_insn("abs  r0",        operands);
      output_asm_insn("jeq  $+8",       operands);  /* If shift count is zero, do nothing */
      output_asm_insn("andi %0, >FF00", operands);
      output_asm_insn("sla  %0, 0",     operands);
    }
    else if(INTVAL(operands[2]) > 0)
    {
      output_asm_insn("andi %0, >FF00", operands);
      output_asm_insn("sla  %0, %2",    operands);
    }
    return(""); 
  }
}

static const char *
output_33 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 831 "../../gcc/config/tms9900/tms9900.md"
{
    rtx ops[7];
    ops[0] = operands[0];  /* Destination */
    ops[1] = operands[1];  /* Source */
    ops[2] = operands[2];  /* Shift count */
    ops[3] = operands[3];  /* Scratch reg */
    ops[4] = gen_rtx_REG (HImode, REGNO (operands[0]) + REGS_PER_WORD);  /* Low word of source */
    if(which_alternative == 0)
    {
      /* Variable shift */
      output_asm_insn("ci   %2, 16",  ops);  /* +0: Compare shift to 16 */
      output_asm_insn("jlt  $+16",    ops);  /* +4: If shift was < 16, goto lt_16 */
      output_asm_insn("jeq  $+4",     ops);  /* +6: If shift was 16, goto eq_16 */

      /* Shift count greater than 16 */
      output_asm_insn("sra  %1, %2",  ops);  /* +8: Shift high word */

      /* eq_16: Shift count equals 16 */
      output_asm_insn("mov  %1, %4",  ops);  /* +10: Copy high word to low word */ 
      output_asm_insn("seto %1",      ops);  /* +12: Assume negative value, set high word */
      output_asm_insn("jlt  $+4",     ops);  /* +14: If value was negative, skip next instruction */
      output_asm_insn("clr  %1",      ops);  /* +16: Clear high word */
      output_asm_insn("jmp  $+20",    ops);  /* +18: Goto end */

      /* lt_16: Shift count less than 16 */
      output_asm_insn("abs  %2",      ops);  /* +20: Test shift count */
      output_asm_insn("jeq  $+16",    ops);  /* +22: If shift==0, goto end */
      output_asm_insn("mov  %4, %3",  ops);  /* +24: Save high word to temp */
      output_asm_insn("sra  %1, %2",  ops);  /* +26: Shift high word */
      output_asm_insn("srl  %4, %2",  ops);  /* +28: Shift low word */
      output_asm_insn("neg  %2",      ops);  /* +30: Get complement of shift count */
      output_asm_insn("sla  %3, %2",  ops);  /* +32: Shift high word bits into low word position */
      output_asm_insn("soc  %3, %4",  ops);  /* +34: Merge shifted high word bits into low word */
      output_asm_insn("neg  %2",      ops);  /* +36: Restore shift count */
      /* +38: End */
    }
    else
    {
      /* Constant shift */
      int offset = INTVAL(operands[2]);
      ops[5] = GEN_INT(16-offset);  /* Complement of shift count */
      ops[6] = GEN_INT(offset%16);  /* Modulo of shift count */
  
      if(offset < 16)
      {
        output_asm_insn("mov  %4, %3",  ops);  /* Save high word to temp */
        output_asm_insn("sra  %1, %6",  ops);  /* Shift high word */
        output_asm_insn("srl  %4, %6",  ops);  /* Shift low word */
        output_asm_insn("sla  %3, %5",  ops);  /* Shift high word bits into low word position */
        output_asm_insn("soc  %3, %4",  ops);  /* Merge shifted high word bits into low word */
      } 
      else
      {
        if(offset > 16)
        {
          output_asm_insn("sra  %1, %6", ops);  /* Shift high word */
        }
        output_asm_insn("mov  %1, %4",  ops);  /* Copy high word to low word */ 
        output_asm_insn("seto %1",      ops);  /* Assume negative value, set high word */
        output_asm_insn("jlt  $+4",     ops);  /* If value was negative, skip next instruction */
        output_asm_insn("clr  %1",      ops);  /* Clear high word */
      }
    }
    return "";
  }
}

static const char *
output_34 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 906 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative == 0)
    {
      output_asm_insn("abs  r0",     operands);
      output_asm_insn("jeq  $+4",    operands);
      output_asm_insn("sra  %0, 0",  operands);
    }
    else if(INTVAL(operands[2]) > 0)
    {
      output_asm_insn("sla  %0, %2", operands);
    }
    return(""); 
  }
}

static const char *
output_35 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 928 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative == 0)
    {
      output_asm_insn("abs  r0",        operands);
      output_asm_insn("jeq  $+4",       operands);
      output_asm_insn("sra  %0, 0",     operands);
    }
    else if(INTVAL(operands[2]) > 0)
    {
      output_asm_insn("sra  %0, %2",    operands);
    }
    return(""); 
  }
}

static const char *
output_36 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 973 "../../gcc/config/tms9900/tms9900.md"
{
    rtx ops[7];
    ops[0] = operands[0];  /* Destination */
    ops[1] = operands[1];  /* Source */
    ops[2] = operands[2];  /* Shift count */
    ops[3] = operands[3];  /* Scratch reg */
    ops[4] = gen_rtx_REG (HImode, REGNO (operands[0]) + REGS_PER_WORD);  /* Low word of source */
    if(which_alternative == 0)
    {
      /* Variable shift */
      output_asm_insn("ci   %2, 16",  ops);  /* +0: Compare shift to 16 */
      output_asm_insn("jlt  $+12",    ops);  /* +4: If shift was < 16, goto lt_16 */
      output_asm_insn("jeq  $+4",     ops);  /* +6: If shift was 16, goto eq_16 */

      /* Shift count greater than 16 */
      output_asm_insn("srl  %1, %2",  ops);  /* +8: Shift high word */

      /* eq_16: Shift count equals 16 */
      output_asm_insn("mov  %1, %4",  ops);  /* +10: Copy high word to low word */ 
      output_asm_insn("clr  %1",      ops);  /* +12: Clear high word */
      output_asm_insn("jmp  $+20",    ops);  /* +14: Goto end */

      /* lt_16: Shift count less than 16 */
      output_asm_insn("abs  %2",      ops);  /* +16: Test shift count */
      output_asm_insn("jeq  $+16",    ops);  /* +18: If shift==0, goto end */
      output_asm_insn("mov  %1, %3",  ops);  /* +20: Save high word to temp */
      output_asm_insn("srl  %1, %2",  ops);  /* +22: Shift high word */
      output_asm_insn("srl  %4, %2",  ops);  /* +24: Shift low word */
      output_asm_insn("neg  %2",      ops);  /* +26: Get complement of shift count */
      output_asm_insn("sla  %3, %2",  ops);  /* +28: Shift high word bits into low word position */
      output_asm_insn("soc  %3, %4",  ops);  /* +30: Merge shifted high word bits into low word */
      output_asm_insn("neg  %2",      ops);  /* +32: Restore shift count */
      /* +34: End */
    }
    else
    {
      /* Constant shift */
      int offset = INTVAL(operands[2]);
      ops[5] = GEN_INT(16-offset);  /* Complement of shift count */
      ops[6] = GEN_INT(offset%16);  /* Modulo of shift count */
  
      if(offset < 16)
      {
        output_asm_insn("mov  %4, %3",  ops);  /* Save high word to temp */
        output_asm_insn("sra  %1, %6",  ops);  /* Shift high word */
        output_asm_insn("srl  %4, %6",  ops);  /* Shift low word */
        output_asm_insn("sla  %3, %5",  ops);  /* Shift high word bits into low word position */
        output_asm_insn("soc  %3, %4",  ops);  /* Merge shifted high word bits into low word */
      } 
      else
      {
        if(offset > 16)
        {
          output_asm_insn("sra  %1, %6", ops);  /* Shift high word */
        }
        output_asm_insn("mov  %1, %4",  ops);  /* Copy high word to low word */ 
        output_asm_insn("clr  %1",      ops);  /* Clear high word */
      }
    }
    return "";
  }
}

static const char *
output_37 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1044 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative == 0)
    {
      output_asm_insn("abs  r0",     operands);
      output_asm_insn("jeq  $+4",    operands);
      output_asm_insn("srl  %0, 0",  operands);
    }
    else if(INTVAL(operands[2]) > 0)
    {
      output_asm_insn("srl  %0, %2", operands);
    }
    return(""); 
  }
}

static const char *
output_38 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1066 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative == 0)
    {
      output_asm_insn("abs  r0",        operands);
      output_asm_insn("jeq  $+4",       operands);
      output_asm_insn("srl  %0, 0",     operands);
    }
    else if(INTVAL(operands[2]) > 0)
    {
      output_asm_insn("srl  %0, %2",    operands);
    }
    return(""); 
  }
}

static const char * const output_39[] = {
  "src  %0, 0",
  "src  %0, %2",
};

static const char *
output_40 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1150 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative >= 4)
    {
      int val = INTVAL(operands[2]) & 0xFFFF;
      if(val == 0)
      {
        /* Result will be zero */
        output_asm_insn("clr  %0", operands);
      }
      else if(val == 0xFFFF)
      {
        /* No operation required */
        return("");
      }
      else if(which_alternative == 4)
      {
        /* AND const value and register */
        output_asm_insn("andi %0, %2", operands);
      }
      else if(which_alternative >= 5)
      {
        /* AND const value and memory */
        operands[2] = GEN_INT(~val);
        output_asm_insn("li   %3, %2", operands);
        output_asm_insn("szc  %3, %0", operands);
      }
    }
    else
    {
      /* AND against non-const value */
      if(!rtx_equal_p(operands[2], operands[3]))
      {
        output_asm_insn("mov  %2, %3", operands);
      }
      output_asm_insn("inv  %3",     operands);
      output_asm_insn("szc  %3, %0", operands);
    }
    return(""); 
  }
}

static const char *
output_43 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1218 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative >= 4)
    {
      int val = INTVAL(operands[2]) & 0xFF;
      if(which_alternative == 4)
      {
        /* AND const value and register */
        if(val == 0)
          output_asm_insn("clr  %0", operands);
        else if(val == 0xff)
          return("");
        else
        {
          operands[2] = GEN_INT(val*256);
          output_asm_insn("andi %0, %2", operands);
        }
      }
      else if(which_alternative >= 5)
      {
        /* AND const value and memory */
        if(val == 0)
          output_asm_insn("sb %0 %0", operands);
        else if(val == 0xff)
          return("");
        else
        {
          operands[2] = GEN_INT((~val)*256);
          output_asm_insn("li   %3, %2", operands);
          output_asm_insn("szc  %3, %0", operands);
        }
      }
    }
    else
    {
      /* AND against non-const value */
      if(!rtx_equal_p(operands[2], operands[3]))
      {
        output_asm_insn("movb %2, %3", operands);
      }
      output_asm_insn("inv  %3",     operands);
      output_asm_insn("szcb %3, %0", operands);
    }
    return(""); 
  }
}

static const char *
output_46 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1294 "../../gcc/config/tms9900/tms9900.md"
{
    if (GET_CODE (operands[2]) == CONST_INT)
      {
        int val = INTVAL(operands[2]) & 0xFFFF;
        if(val == 0xFFFF)
          return "seto %0";
        else if(val == 0)
          return "";
        else
          return "ori  %0, %2";
      }
    return "soc  %2, %0";
  }
}

static const char *
output_47 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1316 "../../gcc/config/tms9900/tms9900.md"
{
    if (GET_CODE (operands[2]) == CONST_INT)
    {
      int val = INTVAL(operands[2]) & 0xFF;
      operands[2] = GEN_INT(val * 256);
      if(val == 0xFF)
        return "seto %0";
      else if(val == 0)
        return "";
      else
        return("ori  %0, %2");
    }
    return("socb %2, %0");
  }
}

static const char *
output_52 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1394 "../../gcc/config/tms9900/tms9900.md"
{ 
    rtx low_words[3];
    rtx offset[3];

    if(REG_P (operands[0]))
      low_words[0] = gen_rtx_REG (HImode, REGNO (operands[0]) + REGS_PER_WORD);
    else
      low_words[0] = adjust_address (operands[0], HImode, 2);

    if(which_alternative >= 12)
      offset[0] = GEN_INT(6);
    else
      offset[0] = GEN_INT(4);
  
    if(! CONSTANT_P(operands[2]))
    {
      /* Adding two variables */
      if(REG_P (operands[2]))
        low_words[2] = gen_rtx_REG (HImode, REGNO (operands[2]) + REGS_PER_WORD);
      else
        low_words[2] = adjust_address (operands[2], HImode, 2);

      output_asm_insn("a    %2, %0", operands);
      output_asm_insn("a    %2, %0", low_words);
      output_asm_insn("jnc  $+%0",   offset);
      output_asm_insn("inc  %0",     operands);
      return("");
    }
    else
    {
      /* Adding a constant */
      int low_const  =  INTVAL(operands[2])        & 0xffff;
      int high_const = (INTVAL(operands[2]) >> 16) & 0xffff;
      low_words[2] = GEN_INT(low_const);
      operands[2]  = GEN_INT(high_const);

      if(low_const != 0)
      {
        switch(low_const)
        {
          case 0xFFFE: output_asm_insn("dect %0",     low_words); break;
          case 0xFFFF: output_asm_insn("dec  %0",     low_words); break;
          case      1: output_asm_insn("inc  %0",     low_words); break;
          case      2: output_asm_insn("inct %0",     low_words); break;
          default:     output_asm_insn("ai   %0, %2", low_words); break;
        }
        /* DEC and DECT use inverted carry flags */
        if(low_const == 0xFFFF || low_const == 0xFFFE)
          output_asm_insn("joc  $+%0",   offset);
        else
          output_asm_insn("jnc  $+%0",   offset);

        /* Handle carry to high word */
        output_asm_insn("inc  %0",     operands);
      }
      if(high_const != 0)
      {
        switch(high_const)
        {
          case 0xFFFE: output_asm_insn("dect %0",     operands); break;
          case 0xFFFF: output_asm_insn("dec  %0",     operands); break;
          case      1: output_asm_insn("inc  %0",     operands); break;
          case      2: output_asm_insn("inct %0",     operands); break;
          default:     output_asm_insn("ai   %0, %2", operands); break;
        }
      }
    }

    return("");
  }
}

static const char *
output_53 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1473 "../../gcc/config/tms9900/tms9900.md"
{
    switch(GET_CODE(operands[2]))
    {
      case CONST_INT:
      {
        if (INTVAL(operands[2]) == 1)
	  return("inc  %0");
        else if (INTVAL(operands[2]) == -1)
          return("dec  %0");
        else if (INTVAL(operands[2]) == 2)
          return("inct %0");
        else if (INTVAL(operands[2]) == -2)
          return("dect %0");
        /*
        else if (INTVAL(operands[2]) == 4 &&
                 GET_CODE(operands[0]) == REG)
          return("c    *%0+, *%0+");
        */
        else
          return("ai   %0, %2");
      }

      case MEM:
      case REG:
        return ("a    %2, %0");

      default:
          return("ai   %0, %2");
    }
  }
}

static const char *
output_54 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1512 "../../gcc/config/tms9900/tms9900.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    {
      operands[2] = GEN_INT(INTVAL(operands[2]) * 256);
      return("ai   %0, %2");
    }
  return("ab   %2, %0");
  }
}

static const char *
output_55 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1533 "../../gcc/config/tms9900/tms9900.md"
{
    rtx lateoperands[3];
    rtx offset[3];

    lateoperands[0] = operands[0];
    if(REG_P(operands[0]))
    {
      operands[0] = gen_rtx_REG(HImode, REGNO (operands[0]) + REGS_PER_WORD);
      offset[0] = GEN_INT(4);
    }
    else
    {
      operands[0] = adjust_address(operands[0], HImode, 2);
      offset[0] = GEN_INT(6);
    }
  
    if(! CONSTANT_P(operands[2]))
    {
      lateoperands[2] = operands[2];

      if(REG_P(operands[2]))
        operands[2] = gen_rtx_REG(HImode, REGNO (operands[2]) + REGS_PER_WORD);
      else
        operands[2] = adjust_address(operands[2], HImode, 2);

      output_asm_insn("s    %2, %0", lateoperands);
      output_asm_insn("s    %2, %0", operands);
      output_asm_insn("joc  $+%0", offset);
      output_asm_insn("dec  %0", lateoperands);
      return("");
    }
    /* EMW - This never seems to be called... */
    lateoperands[2] = GEN_INT((INTVAL(operands[2]) >> 16) & 0xffff);
    operands[2] = GEN_INT(INTVAL(operands[2]) & 0xffff);
  
    if(INTVAL(operands[2]))
    { 
      output_asm_insn("ai   %0, %2", operands);
      output_asm_insn("jnc  $+%0", offset);
      output_asm_insn("dec  %0", lateoperands);
    }
    if(INTVAL(lateoperands[2]))
    {
      operands[2] = GEN_INT(-INTVAL(operands[2]));
      output_asm_insn("ai   %0, %2", lateoperands);
    }
    return("");
  }
}

static const char *
output_56 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1590 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative < 4)
    {
      output_asm_insn("s    %2, %0",operands);
    }
    else
    {
      output_asm_insn("s    %1, %0",operands);
      output_asm_insn("neg  %0",operands);
    }
    return("");
  }
}

static const char *
output_57 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1611 "../../gcc/config/tms9900/tms9900.md"
{
    if (INTVAL(operands[1]) == -1)
      output_asm_insn("inc  %0",operands);
    else if (INTVAL(operands[1]) == 1)
      output_asm_insn("dec  %0",operands);
    else if (INTVAL(operands[1]) == -2)
      output_asm_insn("inct %0",operands);
    else if (INTVAL(operands[1]) == 2)
      output_asm_insn("dect %0",operands);
    else
    {
      operands[1] = GEN_INT(-INTVAL(operands[1]));
      output_asm_insn("ai   %0, %1",operands);
    }
    output_asm_insn("neg  %0",operands);
    return "";
  }
}

static const char *
output_58 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1638 "../../gcc/config/tms9900/tms9900.md"
{
    if(which_alternative < 4)
    {
      output_asm_insn("sb   %2, %0",operands);
    }
    else
    {
      output_asm_insn("sb   %1, %0",operands);
      output_asm_insn("neg  %0",operands);
    }
    return("");
  }
}

static const char *
output_59 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1665 "../../gcc/config/tms9900/tms9900.md"
{
    rtx args[6];

    args[0] = operands[0];  // Destination R
    args[1] = gen_lowpart_SUBREG(HImode, operands[0]);

    args[2] = operands[2];  // Source G
    if(REG_P(operands[2]))
    {
      args[3] = gen_lowpart_SUBREG(HImode, operands[2]);
    }
    else
    {
      args[3] = adjust_address(operands[2], HImode, 2);
    }

    args[4] = operands[3];  // Temp
    args[5] = operands[4];  // Hold

    /*
    Since we only have a 16-bit multiply, we need to expand
    this math.

    (R0*N+R1)*(G0*N+G1) = R0*G0*N*N + R0*G1*N + R1*G0*N + R1*G1

    We can omit the R0*G0 term since it won't fit into 32 bits
    */

    output_asm_insn("mov  %1, %5",args);  // H = R1
    output_asm_insn("mpy  %3, %0",args);  // [R0,R1] = R0*G1
    output_asm_insn("mov  %1, %4",args);  // T = LSW(R0*G1)
    output_asm_insn("mov  %5, %0",args);  // R0 = H
    output_asm_insn("mpy  %2, %0",args);  // [R0,R1] = R1*G0
    output_asm_insn("a    %1, %4",args);  // T += LSW(R1*G0)
    output_asm_insn("mov  %5, %0",args);  // R0 = H
    output_asm_insn("mpy  %3, %0",args);  // [R0,R1] = R1*G1
    output_asm_insn("a    %4, %0",args);  // R0 += T
    return("");
  }
}

static const char *
output_60 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1712 "../../gcc/config/tms9900/tms9900.md"
{
    /* When both input operands are registers, we may need to swap them. */
    if(REG_P(operands[1]) && REG_P(operands[2]))
    {
      /* Check for forms like: r0 = r1 * r0 */ 
      if(REGNO(operands[0]) == REGNO(operands[2]))
      {
        /* Swap operands, otherwise we will emit code like:
             mov r1, r0
             mpy r0, r0

           instead of:
             mpy r1, r0
        */
        rtx temp = operands[1];
        operands[1] = operands[2];
        operands[2] = temp;
      }
    }

    if(REGNO(operands[0]) != REGNO(operands[1]))
    {
      output_asm_insn("mov  %1, %0", operands);
    }
    output_asm_insn("mpy  %2, %0", operands);
    return("");
  }
}

static const char *
output_62 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1863 "../../gcc/config/tms9900/tms9900.md"
{
    output_asm_insn("inv  %1", operands);
    output_asm_insn("jlt  $+4", operands);
    output_asm_insn("neg  %0", operands);
    return("");
  }
}

static const char *
output_65 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1903 "../../gcc/config/tms9900/tms9900.md"
{
    rtx word[2];
    rtx offset[1];

    /* word 0 is most significant */
    word[0] = operands[0];
    if (REG_P (operands[0]))
    {
      word[1] = gen_rtx_REG(HImode, REGNO(operands[0]) + REGS_PER_WORD);
      offset[0] = GEN_INT(4);
    }
    else
    {
      word[1] = adjust_address(operands[0], HImode, 2);
      offset[0] = GEN_INT(6);
    }
    output_asm_insn("inv  %0", word);
    output_asm_insn("neg  %1", word);
    output_asm_insn("jnc  $+%0", offset);
    output_asm_insn("inc  %0", word);
    return("");
  }
}

static const char *
output_67 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1942 "../../gcc/config/tms9900/tms9900.md"
{
    output_asm_insn("andi %0, 0xFF00", operands);
    output_asm_insn("neg  %0", operands);
    return("");
  }
}

static const char *
output_68 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 1961 "../../gcc/config/tms9900/tms9900.md"
{
    if (GET_CODE (operands[1]) == CONST_INT)
    {
      if(GET_CODE (operands[0]) == REG)
      {
        if (INTVAL(operands[1]) == 0)
          return("clr  %0");
        else if (INTVAL(operands[1]) == -1)
          return("seto %0");
        else
        {
          operands[1] = GEN_INT(INTVAL(operands[1]) * 256);
          return("li   %0, %1");
        }
      }
    }
    else if(GET_CODE (operands[1]) == SUBREG ||
            GET_CODE (operands[1]) == TRUNCATE)
    {
      /* Mode change required, HI to QI */
      rtx suboperands[2];
      suboperands[0] = operands[0];
      suboperands[1] = SUBREG_REG(operands[1]);
      if(GET_CODE(operands[0]) == REG)
      {
        /* Reg-to-reg copy */ 
        if(REGNO(suboperands[0]) == REGNO(suboperands[1]))
        {
          /* Convert within the register */
          output_asm_insn ("swpb %0", suboperands);
        }
        else
        {
          /* Copy to other register, then convert */
          output_asm_insn ("mov  %1, %0", suboperands);
          output_asm_insn ("swpb %0", suboperands);            
        }
      }
      else
      {
        /* Reg-to-mem copy */
        if(find_regno_note(insn, REG_DEAD, REGNO(suboperands[1])))
        {
          output_asm_insn ("swpb %1", suboperands);                       
          output_asm_insn ("movb %1, %0", suboperands);
          /* Operand 1 dies here, no need to restore it */
        }
        else
        {
          output_asm_insn ("swpb %1", suboperands);                       
          output_asm_insn ("movb %1, %0", suboperands);
          output_asm_insn ("swpb %1", suboperands);                       
        }
      }
      return("");
    }
    return("movb %1, %0");
  }
}

static const char *
output_69 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2027 "../../gcc/config/tms9900/tms9900.md"
{
    switch(GET_CODE(operands[1]))
    {
      case CONST_INT:
        if (INTVAL(operands[1]) == 0)
          return("clr  %0");
        else if (INTVAL(operands[1]) == -1)
          return("seto %0");
        else
          return("li   %0, %1");

      case REG:
      case MEM:
        return("mov  %1, %0");

      default:
        return("li   %0, %1");
    }
  }
}

static const char *
output_71 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2072 "../../gcc/config/tms9900/tms9900.md"
{
    rtx lateoperands[2];

    lateoperands[0] = operands[0];
    if (REG_P (operands[0]))
      operands[0] = gen_rtx_REG(HImode, REGNO(operands[0]) + REGS_PER_WORD);
    else
      operands[0] = adjust_address(operands[0], HImode, 2);

    output_asm_insn("mov  %1, %0", operands);
    output_asm_insn("clr  %0", lateoperands);
    return("");
  }
}

static const char *
output_73 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2103 "../../gcc/config/tms9900/tms9900.md"
{
    rtx latehalf[2];
    rtx offset[2];

    latehalf[0] = operands[0];
    if (REG_P (operands[0]))
      operands[0] = gen_rtx_REG(HImode, REGNO(operands[0]) + REGS_PER_WORD);
    else
      operands[0] = adjust_address(operands[0], HImode, 2);

    if(which_alternative == 2)
      offset[0] = GEN_INT(6);
    else
      offset[0] = GEN_INT(4);

    output_asm_insn("mov  %1, %0", operands);
    output_asm_insn("seto %0", latehalf);
    output_asm_insn("jlt  $+%0", offset);
    output_asm_insn("clr  %0", latehalf);
    return("");
  }
}

static const char *
output_75 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2170 "../../gcc/config/tms9900/tms9900.md"
{
    operands[2] = GEN_INT(-INTVAL(operands[2]));
    switch(INTVAL(operands[2]))
    {
      case -2: output_asm_insn("dect %0",     operands); break;
      case -1: output_asm_insn("dec  %0",     operands); break;
      case  1: output_asm_insn("inc  %0",     operands); break;
      case  2: output_asm_insn("inct %0",     operands); break;
      default: output_asm_insn("ai   %0, %2", operands); break;
    }
    return("");
  }
}

static const char *
output_76 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2239 "../../gcc/config/tms9900/tms9900.md"
{
    operands[1] = GEN_INT(INTVAL(operands[2]) * 256 + INTVAL(operands[1]));
    return("ci   %0, %1");
  }
}

static const char *
output_77 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2433 "../../gcc/config/tms9900/tms9900.md"
{
    int shift = INTVAL (operands[1]);
    if(shift < 8)
    {
      operands[1] = GEN_INT(8 - shift);
      output_asm_insn("sla  %0, %1", operands);
    }
    else if(shift > 8)
    {
      operands[1] = GEN_INT(shift - 8);
      output_asm_insn("sra  %0, %1", operands);
    }
    return "";
  }
}

static const char *
output_78 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2472 "../../gcc/config/tms9900/tms9900.md"
{
    int shift = INTVAL (operands[1]);
    if(shift < 8)
    {
      operands[1] = GEN_INT(8 - shift);
      output_asm_insn("sla  %0, %1", operands);
    }
    else if(shift > 8)
    {
      operands[1] = GEN_INT(shift - 8);
      output_asm_insn("srl  %0, %1", operands);
    }
    return "";
  }
}

static const char *
output_79 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2511 "../../gcc/config/tms9900/tms9900.md"
{
    operands[1] = GEN_INT(8 + INTVAL (operands[1]));
    output_asm_insn("sla  %0, %1", operands);
    return("");
  }
}

static const char *
output_80 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2555 "../../gcc/config/tms9900/tms9900.md"
{
    int shift = INTVAL (operands[1]) + 8;
    if(shift > 15) shift = 15;
    operands[1] = GEN_INT(shift);
    output_asm_insn("sra  %0, %1", operands);
    return("");
  }
}

static const char *
output_81 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2588 "../../gcc/config/tms9900/tms9900.md"
{
    int shift = INTVAL (operands[1]) + 8;
    if(shift > 15) shift = 15;
    operands[1] = GEN_INT(shift);
    output_asm_insn("srl  %0, %1", operands);
    return("");
  }
}

static const char *
output_82 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2619 "../../gcc/config/tms9900/tms9900.md"
{
    int shift = INTVAL(operands[3]);
    if(shift == 0) {
      output_asm_insn("swpb %0", operands);
      }
    else if(shift >= 1 && shift <= 7) { 
      operands[3] = GEN_INT(8-shift);
      output_asm_insn("sra  %0, %3", operands);
      }
    else if(shift >= 9 && shift <= 15) {
      operands[3] = GEN_INT(shift-8);
      output_asm_insn("sla  %0, %3", operands);
      }

    operands[3] = GEN_INT(0x00FF << shift);
    output_asm_insn("andi %0, %3", operands);
   
    return("");
  }
}

static const char *
output_83 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2663 "../../gcc/config/tms9900/tms9900.md"
{
    int shift = INTVAL(operands[3]);
    if(shift >= 0 && shift <= 7) { 
      operands[3] = GEN_INT(8-shift);
      output_asm_insn("srl  %0, %3", operands);
      }
    else if(shift >= 9 && shift <= 15) {
      operands[3] = GEN_INT(shift-8);
      output_asm_insn("sla  %0, %3", operands);
      }

    operands[3] = GEN_INT(0xFFFF << shift);
    output_asm_insn("andi %0, %3", operands);
   
    return("");
  }
}

static const char *
output_84 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2717 "../../gcc/config/tms9900/tms9900.md"
{
    if(INTVAL(operands[1]) == 0) {
      output_asm_insn("clr  %0", operands);
    } else if((INTVAL(operands[1]) & 0xFFFF) == 0xFFFF) {
      output_asm_insn("seto  %0", operands);
    } else {
      output_asm_insn("li   %0, %1", operands);
    }
    return("");
  }
}

static const char *
output_85 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2804 "../../gcc/config/tms9900/tms9900.md"
{
    operands[1] = GEN_INT(((INTVAL(operands[1]) & 0xFF) << 8) |
                           (INTVAL(operands[3]) & 0xFF));
    return "li   %0, %1";
  }
}

static const char *
output_86 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2817 "../../gcc/config/tms9900/tms9900.md"
{
    if(INTVAL(operands[2]) == 8)
    {
      output_asm_insn("movb %1, %0", operands);
    }
    else if(INTVAL(operands[2]) == 0)
    {
      output_asm_insn("swpb %1", operands);
      output_asm_insn("movb %1, %0", operands);
    }
   return("");
  }
}

static const char *
output_87 (rtx *operands ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
#line 2876 "../../gcc/config/tms9900/tms9900.md"
{
    int val = INTVAL(operands[1]) & 0xFFFF;
    if(val == 0)
      return "clr  %0";
    else if(val == 0xFFFF)
      return "";
    else
      return "andi %0, %1";
  }
}



static const struct insn_operand_data operand_data[] = 
{
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "rR,Q",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "g,g",
    HImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR,Q",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "g,g",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR,rR,Q,Q,r",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rR,Q,rR,Q,i",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR,rR,Q,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR,Q,rR,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "r,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR,Q",
    HImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    scratch_operand,
    "=r,r",
    HImode,
    0,
    0
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    SImode,
    0,
    1
  },
  {
    shift_count_operand,
    "S,i",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r,r",
    HImode,
    0,
    0
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    shift_count_operand,
    "S,i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    shift_count_operand,
    "S,i",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q,r,R>,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0,0,0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rR>,Q,rR>,Q,i,i,i",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r,r,r,r,r,r,r",
    HImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q,rR>,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q,rR>,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q,r,R>,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0,0,0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "rR>,Q,rR>,Q,i,i,i",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r,r,r,r,r,r,r",
    QImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q,rR>,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q,rR>,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q,r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0,0,0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rR>,Q,rR>,Q,i,M",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0,0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "rR>,Q,rR>,Q,i",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "%0,0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "%0,0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,r,r,r,r,R,R,R,R,R,R,Q,Q,Q,Q,Q,Q",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "r,R,Q,I,J,K,r,R,Q,I,J,K,r,R,Q,I,J,K",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,Q,r,rR>,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0,0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rR>LMNO,rR>LNMO,i,Q,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,r,r,r,r,R,R,R,R,R,R,Q,Q,Q,Q,Q,Q",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "r,R,Q,I,J,K,r,R,Q,I,J,K,r,R,Q,I,J,K",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,Q,rR>,Q,rR>,Q,rR>,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0,rR>,rR>,Q,Q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,rR>,Q,Q,0,0,0,0",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,Q,rR>,Q,rR>,Q,rR>,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,0,0,rR>,rR>,Q,Q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,rR>,Q,Q,0,0,0,0",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0,0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "r,R,Q",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r,r,r",
    HImode,
    0,
    0
  },
  {
    scratch_operand,
    "=r,r,r",
    HImode,
    0,
    0
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR,Q",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rR>,rR>,Q,Q,r,r,W,r",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "rR>,Q,rR>,Q,MO,i,r,W",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=UrR>,rR>,Q,Q,r,W,r",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rROM>,Q,rROM>,Q,i,r,W",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,R,Q",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "g,g,g",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    immediate_operand,
    "LMNO,i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    QImode,
    0,
    1
  },
  {
    memory_operand,
    "=rR>,Q",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i,i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i,i",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i,i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    QImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    shift_count_operand,
    "S,i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "3,3",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "+0,0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+rR>,Q",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rR>,Q",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "+r,r",
    HImode,
    0,
    0
  },
  {
    scratch_operand,
    "+r,r",
    HImode,
    0,
    0
  },
  {
    scratch_operand,
    "+r,r",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "+r,r",
    HImode,
    0,
    0
  },
  {
    scratch_operand,
    "+r,r",
    HImode,
    0,
    0
  },
  {
    register_operand,
    "r",
    HImode,
    0,
    1
  },
  {
    immediate_operand,
    "LMNO",
    HImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    QImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "2",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "3",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "5",
    SImode,
    0,
    1
  },
  {
    const_int_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "i,i",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=R>,Q",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "i,i",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=R>,Q",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "r,r",
    HImode,
    0,
    0
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    HImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
};


#if GCC_VERSION >= 2007
__extension__
#endif

const struct insn_data insn_data[] = 
{
  /* ../../gcc/config/tms9900/tms9900.md:88 */
  {
    "call",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_0 },
#else
    { 0, 0, output_0 },
#endif
    (insn_gen_fn) gen_call,
    &operand_data[1],
    2,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:106 */
  {
    "call_value",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_1 },
#else
    { 0, 0, output_1 },
#endif
    (insn_gen_fn) gen_call_value,
    &operand_data[3],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:155 */
  {
    "*rt",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "b    *r11",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    0,
    &operand_data[6],
    1,
    0,
    0,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:168 */
  {
    "tsthi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_3 },
#else
    { 0, 0, output_3 },
#endif
    (insn_gen_fn) gen_tsthi,
    &operand_data[1],
    1,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:183 */
  {
    "tstqi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "movb %0, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_tstqi,
    &operand_data[7],
    1,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:192 */
  {
    "cmphi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_5 },
#else
    { 0, 0, output_5 },
#endif
    (insn_gen_fn) gen_cmphi,
    &operand_data[8],
    2,
    0,
    5,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:208 */
  {
    "cmpqi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "cb   %0, %1",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_cmpqi,
    &operand_data[10],
    2,
    0,
    4,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:224 */
  {
    "beq",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_7 },
#else
    { 0, 0, output_7 },
#endif
    (insn_gen_fn) gen_beq,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:246 */
  {
    "*beq_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_8 },
#else
    { 0, 0, output_8 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:268 */
  {
    "bne",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_9 },
#else
    { 0, 0, output_9 },
#endif
    (insn_gen_fn) gen_bne,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:288 */
  {
    "*bne_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_10 },
#else
    { 0, 0, output_10 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:308 */
  {
    "bltu",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_11 },
#else
    { 0, 0, output_11 },
#endif
    (insn_gen_fn) gen_bltu,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:328 */
  {
    "*bltu_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_12 },
#else
    { 0, 0, output_12 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:348 */
  {
    "bleu",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_13 },
#else
    { 0, 0, output_13 },
#endif
    (insn_gen_fn) gen_bleu,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:368 */
  {
    "*bleu_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_14 },
#else
    { 0, 0, output_14 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:388 */
  {
    "bgtu",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_15 },
#else
    { 0, 0, output_15 },
#endif
    (insn_gen_fn) gen_bgtu,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:408 */
  {
    "*bgtu_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_16 },
#else
    { 0, 0, output_16 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:428 */
  {
    "bgeu",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_17 },
#else
    { 0, 0, output_17 },
#endif
    (insn_gen_fn) gen_bgeu,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:448 */
  {
    "*bgeu_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_18 },
#else
    { 0, 0, output_18 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:468 */
  {
    "blt",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_19 },
#else
    { 0, 0, output_19 },
#endif
    (insn_gen_fn) gen_blt,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:489 */
  {
    "*blt_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_20 },
#else
    { 0, 0, output_20 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:509 */
  {
    "ble",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_21 },
#else
    { 0, 0, output_21 },
#endif
    (insn_gen_fn) gen_ble,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:529 */
  {
    "*ble_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_22 },
#else
    { 0, 0, output_22 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:549 */
  {
    "bgt",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_23 },
#else
    { 0, 0, output_23 },
#endif
    (insn_gen_fn) gen_bgt,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:570 */
  {
    "*bgt_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_24 },
#else
    { 0, 0, output_24 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:591 */
  {
    "bge",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_25 },
#else
    { 0, 0, output_25 },
#endif
    (insn_gen_fn) gen_bge,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:611 */
  {
    "*bge_reversed",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_26 },
#else
    { 0, 0, output_26 },
#endif
    0,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:636 */
  {
    "jump",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_27 },
#else
    { 0, 0, output_27 },
#endif
    (insn_gen_fn) gen_jump,
    &operand_data[3],
    1,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:654 */
  {
    "indirect_jump",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "b    %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_indirect_jump,
    &operand_data[12],
    1,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:663 */
  {
    "tablejump",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_29 },
#else
    { 0, 0, output_29 },
#endif
    (insn_gen_fn) gen_tablejump,
    &operand_data[13],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:686 */
  {
    "ashlsi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_30 },
#else
    { 0, 0, output_30 },
#endif
    (insn_gen_fn) gen_ashlsi3,
    &operand_data[16],
    4,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:758 */
  {
    "ashlhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_31 },
#else
    { 0, 0, output_31 },
#endif
    (insn_gen_fn) gen_ashlhi3,
    &operand_data[20],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:780 */
  {
    "ashlqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_32 },
#else
    { 0, 0, output_32 },
#endif
    (insn_gen_fn) gen_ashlqi3,
    &operand_data[23],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:825 */
  {
    "ashrsi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_33 },
#else
    { 0, 0, output_33 },
#endif
    (insn_gen_fn) gen_ashrsi3,
    &operand_data[16],
    4,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:901 */
  {
    "ashrhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_34 },
#else
    { 0, 0, output_34 },
#endif
    (insn_gen_fn) gen_ashrhi3,
    &operand_data[20],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:923 */
  {
    "ashrqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_35 },
#else
    { 0, 0, output_35 },
#endif
    (insn_gen_fn) gen_ashrqi3,
    &operand_data[23],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:967 */
  {
    "lshrsi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_36 },
#else
    { 0, 0, output_36 },
#endif
    (insn_gen_fn) gen_lshrsi3,
    &operand_data[16],
    4,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1039 */
  {
    "lshrhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_37 },
#else
    { 0, 0, output_37 },
#endif
    (insn_gen_fn) gen_lshrhi3,
    &operand_data[20],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1061 */
  {
    "lshrqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_38 },
#else
    { 0, 0, output_38 },
#endif
    (insn_gen_fn) gen_lshrqi3,
    &operand_data[23],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1123 */
  {
    "rotrhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .multi = output_39 },
#else
    { 0, output_39, 0 },
#endif
    (insn_gen_fn) gen_rotrhi3,
    &operand_data[20],
    3,
    0,
    2,
    2
  },
  /* ../../gcc/config/tms9900/tms9900.md:1144 */
  {
    "andhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_40 },
#else
    { 0, 0, output_40 },
#endif
    (insn_gen_fn) gen_andhi3,
    &operand_data[26],
    4,
    0,
    7,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1192 */
  {
    "*andnothi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "szc  %2, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    0,
    &operand_data[30],
    3,
    0,
    4,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1202 */
  {
    "*not_andhi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "szc  %1, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    0,
    &operand_data[33],
    3,
    0,
    4,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1212 */
  {
    "andqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_43 },
#else
    { 0, 0, output_43 },
#endif
    (insn_gen_fn) gen_andqi3,
    &operand_data[36],
    4,
    0,
    7,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1265 */
  {
    "*andnotqi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "szcb %2, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    0,
    &operand_data[40],
    3,
    0,
    4,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1275 */
  {
    "*not_andqi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "szcb %1, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    0,
    &operand_data[43],
    3,
    0,
    4,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1289 */
  {
    "iorhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_46 },
#else
    { 0, 0, output_46 },
#endif
    (insn_gen_fn) gen_iorhi3,
    &operand_data[46],
    3,
    0,
    6,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1311 */
  {
    "iorqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_47 },
#else
    { 0, 0, output_47 },
#endif
    (insn_gen_fn) gen_iorqi3,
    &operand_data[49],
    3,
    0,
    5,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1338 */
  {
    "xorhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor  %2, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_xorhi3,
    &operand_data[52],
    3,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1348 */
  {
    "xorqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor  %2, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_xorqi3,
    &operand_data[55],
    3,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1362 */
  {
    "one_cmplhi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "inv  %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_one_cmplhi2,
    &operand_data[58],
    2,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1371 */
  {
    "one_cmplqi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "inv  %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_one_cmplqi2,
    &operand_data[60],
    2,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1389 */
  {
    "addsi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_52 },
#else
    { 0, 0, output_52 },
#endif
    (insn_gen_fn) gen_addsi3,
    &operand_data[62],
    3,
    0,
    18,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1468 */
  {
    "addhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_53 },
#else
    { 0, 0, output_53 },
#endif
    (insn_gen_fn) gen_addhi3,
    &operand_data[65],
    3,
    0,
    5,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1507 */
  {
    "addqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_54 },
#else
    { 0, 0, output_54 },
#endif
    (insn_gen_fn) gen_addqi3,
    &operand_data[49],
    3,
    0,
    5,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1528 */
  {
    "subsi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_55 },
#else
    { 0, 0, output_55 },
#endif
    (insn_gen_fn) gen_subsi3,
    &operand_data[68],
    3,
    0,
    18,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1585 */
  {
    "subhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_56 },
#else
    { 0, 0, output_56 },
#endif
    (insn_gen_fn) gen_subhi3,
    &operand_data[71],
    3,
    0,
    8,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1606 */
  {
    "*rsubihi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_57 },
#else
    { 0, 0, output_57 },
#endif
    0,
    &operand_data[74],
    3,
    0,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1633 */
  {
    "subqi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_58 },
#else
    { 0, 0, output_58 },
#endif
    (insn_gen_fn) gen_subqi3,
    &operand_data[77],
    3,
    0,
    8,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1658 */
  {
    "mulsi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_59 },
#else
    { 0, 0, output_59 },
#endif
    (insn_gen_fn) gen_mulsi3,
    &operand_data[80],
    5,
    0,
    3,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1707 */
  {
    "umulhisi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_60 },
#else
    { 0, 0, output_60 },
#endif
    (insn_gen_fn) gen_umulhisi3,
    &operand_data[85],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1757 */
  {
    "divmodsihi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "div  %2, %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_divmodsihi3,
    &operand_data[88],
    3,
    2,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1856 */
  {
    "divfixuphi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_62 },
#else
    { 0, 0, output_62 },
#endif
    (insn_gen_fn) gen_divfixuphi2,
    &operand_data[91],
    2,
    4,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1877 */
  {
    "abshi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "abs  %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_abshi2,
    &operand_data[58],
    2,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1886 */
  {
    "absqi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "abs  %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_absqi2,
    &operand_data[93],
    2,
    0,
    1,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1899 */
  {
    "negsi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_65 },
#else
    { 0, 0, output_65 },
#endif
    (insn_gen_fn) gen_negsi2,
    &operand_data[95],
    2,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1929 */
  {
    "neghi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "neg  %0",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_neghi2,
    &operand_data[58],
    2,
    0,
    2,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:1938 */
  {
    "negqi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_67 },
#else
    { 0, 0, output_67 },
#endif
    (insn_gen_fn) gen_negqi2,
    &operand_data[93],
    2,
    0,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:1957 */
  {
    "movqi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_68 },
#else
    { 0, 0, output_68 },
#endif
    (insn_gen_fn) gen_movqi,
    &operand_data[97],
    2,
    0,
    8,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2023 */
  {
    "movhi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_69 },
#else
    { 0, 0, output_69 },
#endif
    (insn_gen_fn) gen_movhi,
    &operand_data[99],
    2,
    0,
    7,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2059 */
  {
    "zero_extendqihi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "srl  %0, 8",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_zero_extendqihi2,
    &operand_data[101],
    2,
    0,
    1,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:2068 */
  {
    "zero_extendhisi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_71 },
#else
    { 0, 0, output_71 },
#endif
    (insn_gen_fn) gen_zero_extendhisi2,
    &operand_data[103],
    2,
    0,
    3,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2090 */
  {
    "extendqihi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "sra  %0, 8",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_extendqihi2,
    &operand_data[101],
    2,
    0,
    1,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:2099 */
  {
    "extendhisi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_73 },
#else
    { 0, 0, output_73 },
#endif
    (insn_gen_fn) gen_extendhisi2,
    &operand_data[103],
    2,
    0,
    3,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2134 */
  {
    "nop",
#if HAVE_DESIGNATED_INITIALIZERS
    { .single =
#else
    {
#endif
    "nop",
#if HAVE_DESIGNATED_INITIALIZERS
    },
#else
    0, 0 },
#endif
    (insn_gen_fn) gen_nop,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  /* ../../gcc/config/tms9900/tms9900.md:2165 */
  {
    "*sub_const_hi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_75 },
#else
    { 0, 0, output_75 },
#endif
    0,
    &operand_data[105],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2232 */
  {
    "*cmpqi_as_hi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_76 },
#else
    { 0, 0, output_76 },
#endif
    0,
    &operand_data[108],
    4,
    0,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2427 */
  {
    "*ashiftrt_hi_to_qi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_77 },
#else
    { 0, 0, output_77 },
#endif
    0,
    &operand_data[112],
    3,
    1,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2466 */
  {
    "*lshiftrt_hi_to_qi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_78 },
#else
    { 0, 0, output_78 },
#endif
    0,
    &operand_data[112],
    3,
    1,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2505 */
  {
    "*ashift_hi_to_qi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_79 },
#else
    { 0, 0, output_79 },
#endif
    0,
    &operand_data[112],
    3,
    1,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2549 */
  {
    "*ashiftrt_qi_to_hi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_80 },
#else
    { 0, 0, output_80 },
#endif
    0,
    &operand_data[112],
    3,
    1,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2582 */
  {
    "*lshiftrt_qi_to_hi",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_81 },
#else
    { 0, 0, output_81 },
#endif
    0,
    &operand_data[112],
    3,
    1,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2613 */
  {
    "*qi_hi_shift",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_82 },
#else
    { 0, 0, output_82 },
#endif
    0,
    &operand_data[115],
    4,
    0,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2657 */
  {
    "*unsigned_qi_hi_shift",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_83 },
#else
    { 0, 0, output_83 },
#endif
    0,
    &operand_data[115],
    4,
    0,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2713 */
  {
    "*set_consthi2",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_84 },
#else
    { 0, 0, output_84 },
#endif
    0,
    &operand_data[112],
    2,
    0,
    1,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2798 */
  {
    "*movhi_combine_consts",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_85 },
#else
    { 0, 0, output_85 },
#endif
    0,
    &operand_data[119],
    4,
    0,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2812 */
  {
    "*movqi_for_initializer",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_86 },
#else
    { 0, 0, output_86 },
#endif
    0,
    &operand_data[123],
    3,
    0,
    2,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:2871 */
  {
    "*andi_const",
#if HAVE_DESIGNATED_INITIALIZERS
    { .function = output_87 },
#else
    { 0, 0, output_87 },
#endif
    0,
    &operand_data[126],
    2,
    1,
    0,
    3
  },
  /* ../../gcc/config/tms9900/tms9900.md:125 */
  {
    "prologue",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_prologue,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:136 */
  {
    "epilogue",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_epilogue,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:144 */
  {
    "sibcall_epilogue",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_sibcall_epilogue,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:806 */
  {
    "sibcall_epilogue+1",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[128],
    5,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:945 */
  {
    "sibcall_epilogue+2",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[133],
    8,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:1082 */
  {
    "rotlhi3-1",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[133],
    8,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:1105 */
  {
    "rotlhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_rotlhi3,
    &operand_data[20],
    3,
    0,
    2,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:1742 */
  {
    "mulhi3",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_mulhi3,
    &operand_data[141],
    3,
    2,
    2,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:1773 */
  {
    "udivmodhi4",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_udivmodhi4,
    &operand_data[144],
    4,
    2,
    2,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:1806 */
  {
    "divmodhi4",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    (insn_gen_fn) gen_divmodhi4,
    &operand_data[147],
    9,
    2,
    2,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2148 */
  {
    "divmodhi4+1",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[156],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2187 */
  {
    "divmodhi4+2",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[156],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2211 */
  {
    "divmodhi4+3",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2248 */
  {
    "divmodhi4+4",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2271 */
  {
    "divmodhi4+5",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2294 */
  {
    "divmodhi4+6",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2317 */
  {
    "divmodhi4+7",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2340 */
  {
    "divmodhi4+8",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2363 */
  {
    "divmodhi4+9",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2386 */
  {
    "divmodhi4+10",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[159],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2414 */
  {
    "divmodhi4+11",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[163],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2452 */
  {
    "divmodhi4+12",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[163],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2491 */
  {
    "divmodhi4+13",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[163],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2521 */
  {
    "divmodhi4+14",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[165],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2535 */
  {
    "divmodhi4+15",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[167],
    4,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2567 */
  {
    "divmodhi4+16",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[171],
    6,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2600 */
  {
    "divmodhi4+17",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[177],
    6,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2643 */
  {
    "divmodhi4+18",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[177],
    6,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2693 */
  {
    "divmodhi4+19",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[183],
    8,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2741 */
  {
    "divmodhi4+20",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[183],
    8,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2776 */
  {
    "divmodhi4+21",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[191],
    7,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2835 */
  {
    "divmodhi4+22",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[198],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2846 */
  {
    "divmodhi4+23",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[201],
    3,
    0,
    0,
    0
  },
  /* ../../gcc/config/tms9900/tms9900.md:2859 */
  {
    "divmodhi4+24",
#if HAVE_DESIGNATED_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    0,
    &operand_data[204],
    3,
    0,
    0,
    0
  },
};


const char *
get_insn_name (int code)
{
  if (code == NOOP_MOVE_INSN_CODE)
    return "NOOP_MOVE";
  else
    return insn_data[code].name;
}
