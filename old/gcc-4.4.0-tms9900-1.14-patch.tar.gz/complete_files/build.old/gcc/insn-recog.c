/* Generated automatically by the program `genrecog' from the target
   machine description file.  */

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "rtl.h"
#include "tm_p.h"
#include "function.h"
#include "insn-config.h"
#include "recog.h"
#include "real.h"
#include "output.h"
#include "flags.h"
#include "hard-reg-set.h"
#include "resource.h"
#include "toplev.h"
#include "reload.h"
#include "regs.h"
#include "tm-constrs.h"



/* `recog' contains a decision tree that recognizes whether the rtx
   X0 is a valid instruction.

   recog returns -1 if the rtx is not valid.  If the rtx is valid, recog
   returns a nonnegative number which is the insn code number for the
   pattern that matched.  This is the same as the order in the machine
   description of the entry that matched.  This number can be used as an
   index into `insn_data' and other tables.

   The third argument to recog is an optional pointer to an int.  If
   present, recog will accept a pattern if it matches except for missing
   CLOBBER expressions at the end.  In that case, the value pointed to by
   the optional pointer will be set to the number of CLOBBERs that need
   to be added (it should be initialized to zero by the caller).  If it
   is set nonzero, the caller should allocate a PARALLEL of the
   appropriate size, copy the initial entries, and call add_clobbers
   (found in insn-emit.c) to fill in the CLOBBERs.


   The function split_insns returns 0 if the rtl could not
   be split or the split rtl as an INSN list if it can be.

   The function peephole2_insns returns 0 if the rtl could not
   be matched. If there was a match, the new rtl is returned in an INSN list,
   and LAST_INSN will point to the last recognized insn in the old sequence.
*/


extern rtx gen_peephole2_91 (rtx, rtx *);
extern rtx gen_peephole2_92 (rtx, rtx *);
extern rtx gen_peephole2_93 (rtx, rtx *);
extern rtx gen_peephole2_98 (rtx, rtx *);
extern rtx gen_peephole2_99 (rtx, rtx *);
extern rtx gen_peephole2_100 (rtx, rtx *);
extern rtx gen_peephole2_101 (rtx, rtx *);
extern rtx gen_peephole2_102 (rtx, rtx *);
extern rtx gen_peephole2_103 (rtx, rtx *);
extern rtx gen_peephole2_104 (rtx, rtx *);
extern rtx gen_peephole2_105 (rtx, rtx *);
extern rtx gen_peephole2_106 (rtx, rtx *);
extern rtx gen_peephole2_107 (rtx, rtx *);
extern rtx gen_peephole2_108 (rtx, rtx *);
extern rtx gen_peephole2_109 (rtx, rtx *);
extern rtx gen_peephole2_110 (rtx, rtx *);
extern rtx gen_peephole2_111 (rtx, rtx *);
extern rtx gen_peephole2_112 (rtx, rtx *);
extern rtx gen_peephole2_113 (rtx, rtx *);
extern rtx gen_peephole2_114 (rtx, rtx *);
extern rtx gen_peephole2_115 (rtx, rtx *);
extern rtx gen_peephole2_116 (rtx, rtx *);
extern rtx gen_peephole2_117 (rtx, rtx *);
extern rtx gen_peephole2_118 (rtx, rtx *);
extern rtx gen_peephole2_119 (rtx, rtx *);
extern rtx gen_peephole2_120 (rtx, rtx *);
extern rtx gen_peephole2_121 (rtx, rtx *);



static int
recog_1 (rtx x0 ATTRIBUTE_UNUSED,
	rtx insn ATTRIBUTE_UNUSED,
	int *pnum_clobbers ATTRIBUTE_UNUSED)
{
  rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  rtx x1 ATTRIBUTE_UNUSED;
  rtx x2 ATTRIBUTE_UNUSED;
  rtx x3 ATTRIBUTE_UNUSED;
  rtx x4 ATTRIBUTE_UNUSED;
  rtx x5 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  operands[0] = x1;
  goto L5;
 L231: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x1))
    {
    case HImode:
      goto L932;
    case QImode:
      goto L933;
    case SImode:
      goto L936;
    default:
      break;
    }
 L11: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case CC0:
      goto L12;
    case PC:
      goto L212;
    default:
     break;
   }
  goto ret0;

 L5: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CALL)
    goto L6;
  x1 = XEXP (x0, 0);
  goto L231;

 L6: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L7;
    }
  x1 = XEXP (x0, 0);
  goto L231;

 L7: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      return 1;  /* call_value */
    }
  x1 = XEXP (x0, 0);
  goto L231;

 L932: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L232;
    }
 L934: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L291;
    }
 L938: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L545;
    }
  goto L11;

 L232: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L940;
  x1 = XEXP (x0, 0);
  goto L934;

 L940: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case ASHIFT:
      goto L233;
    case ASHIFTRT:
      goto L251;
    case LSHIFTRT:
      goto L269;
    case ROTATERT:
      goto L279;
    case XOR:
      goto L334;
    case MINUS:
      goto L377;
    case ZERO_EXTEND:
      goto L461;
    case SIGN_EXTEND:
      goto L469;
    case PLUS:
      goto L478;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L934;

 L233: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L234;
    }
 L508: ATTRIBUTE_UNUSED_LABEL
  if (rtx_equal_p (x2, operands[0]))
    goto L509;
  x1 = XEXP (x0, 0);
  goto L934;

 L234: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 31;  /* ashlhi3 */
    }
  x2 = XEXP (x1, 0);
  goto L508;

 L509: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == PLUS)
    goto L510;
  x1 = XEXP (x0, 0);
  goto L934;

 L510: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L511;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L511: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      return 79;  /* *ashift_hi_to_qi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L251: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L252;
    }
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L530;
    }
 L494: ATTRIBUTE_UNUSED_LABEL
  if (rtx_equal_p (x2, operands[0]))
    goto L495;
  x1 = XEXP (x0, 0);
  goto L934;

 L252: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 34;  /* ashrhi3 */
    }
  x2 = XEXP (x1, 0);
  goto L494;

 L530: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L531;
  x2 = XEXP (x1, 0);
  goto L494;

 L531: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L532;
    }
  x2 = XEXP (x1, 0);
  goto L494;

 L532: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[3] = x3;
      return 82;  /* *qi_hi_shift */
    }
  x2 = XEXP (x1, 0);
  goto L494;

 L495: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode)
    goto L949;
  x1 = XEXP (x0, 0);
  goto L934;

 L949: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MINUS:
      goto L496;
    case PLUS:
      goto L517;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L934;

 L496: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L497;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L497: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      return 77;  /* *ashiftrt_hi_to_qi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L517: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L518;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L518: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      return 80;  /* *ashiftrt_qi_to_hi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L269: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L270;
    }
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L537;
    }
 L501: ATTRIBUTE_UNUSED_LABEL
  if (rtx_equal_p (x2, operands[0]))
    goto L502;
  x1 = XEXP (x0, 0);
  goto L934;

 L270: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 37;  /* lshrhi3 */
    }
  x2 = XEXP (x1, 0);
  goto L501;

 L537: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L538;
  x2 = XEXP (x1, 0);
  goto L501;

 L538: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L539;
    }
  x2 = XEXP (x1, 0);
  goto L501;

 L539: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[3] = x3;
      return 83;  /* *unsigned_qi_hi_shift */
    }
  x2 = XEXP (x1, 0);
  goto L501;

 L502: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode)
    goto L951;
  x1 = XEXP (x0, 0);
  goto L934;

 L951: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MINUS:
      goto L503;
    case PLUS:
      goto L524;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L934;

 L503: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L504;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L504: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      return 78;  /* *lshiftrt_hi_to_qi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L524: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L525;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L525: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      return 81;  /* *lshiftrt_qi_to_hi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L279: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L280;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L280: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 39;  /* rotrhi3 */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L334: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L335;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L335: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[2] = x2;
      return 48;  /* xorhi3 */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L377: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (immediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L378;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L378: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      return 57;  /* *rsubihi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L461: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      return 70;  /* zero_extendqihi2 */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L469: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      return 72;  /* extendqihi2 */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L478: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L479;
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L479: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == NEG)
    goto L480;
  x1 = XEXP (x0, 0);
  goto L934;

 L480: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (immediate_operand (x3, HImode))
    {
      operands[2] = x3;
      return 75;  /* *sub_const_hi */
    }
  x1 = XEXP (x0, 0);
  goto L934;

 L291: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L953;
 L457: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, HImode))
    {
      operands[1] = x1;
      return 69;  /* movhi */
    }
  x1 = XEXP (x0, 0);
  goto L938;

 L953: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case AND:
      goto L292;
    case IOR:
      goto L324;
    case NOT:
      goto L344;
    case PLUS:
      goto L357;
    case MINUS:
      goto L372;
    case ABS:
      goto L435;
    case NEG:
      goto L447;
    default:
     break;
   }
  goto L457;

 L292: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == HImode)
    goto L961;
  goto L457;

 L961: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == NOT)
    goto L299;
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L293;
    }
  goto L457;

 L299: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L300;
    }
  goto L457;

 L300: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[2] = x2;
      return 42;  /* *not_andhi */
    }
  goto L457;

 L293: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == NOT)
    goto L294;
  goto L457;

 L294: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[2] = x3;
      return 41;  /* *andnothi */
    }
  goto L457;

 L324: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L325;
    }
  goto L457;

 L325: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      return 46;  /* iorhi3 */
    }
  goto L457;

 L344: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      return 50;  /* one_cmplhi2 */
    }
  goto L457;

 L357: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L358;
    }
  goto L457;

 L358: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      return 53;  /* addhi3 */
    }
  goto L457;

 L372: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L373;
    }
  goto L457;

 L373: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[2] = x2;
      return 56;  /* subhi3 */
    }
  goto L457;

 L435: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      return 63;  /* abshi2 */
    }
  goto L457;

 L447: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      return 66;  /* neghi2 */
    }
  goto L457;

 L545: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L962;
 L542: ATTRIBUTE_UNUSED_LABEL
  if (const_int_operand (x1, HImode))
    {
      operands[1] = x1;
      return 84;  /* *set_consthi2 */
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L962: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case IOR:
      goto L546;
    case AND:
      goto L559;
    default:
     break;
   }
  goto L542;

 L546: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L547;
  goto L542;

 L547: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L548;
    }
  goto L542;

 L548: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L549;
    }
  goto L542;

 L549: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, QImode))
    {
      operands[3] = x2;
      return 85;  /* *movhi_combine_consts */
    }
  goto L542;

 L559: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L560;
  goto L542;

 L560: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      return 87;  /* *andi_const */
    }
  goto L542;

 L933: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L237;
    }
 L935: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L311;
    }
 L939: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L552;
    }
  goto L11;

 L237: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode)
    goto L964;
  x1 = XEXP (x0, 0);
  goto L935;

 L964: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case ASHIFT:
      goto L238;
    case ASHIFTRT:
      goto L256;
    case LSHIFTRT:
      goto L274;
    case XOR:
      goto L339;
    case ABS:
      goto L439;
    case NEG:
      goto L451;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L935;

 L238: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L239;
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L239: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 32;  /* ashlqi3 */
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L256: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L257;
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L257: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 35;  /* ashrqi3 */
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L274: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L275;
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L275: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (shift_count_operand (x2, HImode))
    {
      operands[2] = x2;
      return 38;  /* lshrqi3 */
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L339: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L340;
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L340: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      return 49;  /* xorqi3 */
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L439: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      return 64;  /* absqi2 */
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L451: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      return 67;  /* negqi2 */
    }
  x1 = XEXP (x0, 0);
  goto L935;

 L311: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode)
    goto L970;
 L454: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, QImode))
    {
      operands[1] = x1;
      return 68;  /* movqi */
    }
  x1 = XEXP (x0, 0);
  goto L939;

 L970: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case AND:
      goto L312;
    case IOR:
      goto L329;
    case NOT:
      goto L348;
    case PLUS:
      goto L362;
    case MINUS:
      goto L382;
    default:
     break;
   }
  goto L454;

 L312: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == QImode)
    goto L976;
  goto L454;

 L976: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == NOT)
    goto L319;
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L313;
    }
  goto L454;

 L319: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L320;
    }
  goto L454;

 L320: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      return 45;  /* *not_andqi */
    }
  goto L454;

 L313: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == NOT)
    goto L314;
  goto L454;

 L314: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[2] = x3;
      return 44;  /* *andnotqi */
    }
  goto L454;

 L329: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L330;
    }
  goto L454;

 L330: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      return 47;  /* iorqi3 */
    }
  goto L454;

 L348: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      return 51;  /* one_cmplqi2 */
    }
  goto L454;

 L362: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L363;
    }
  goto L454;

 L363: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      return 54;  /* addqi3 */
    }
  goto L454;

 L382: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L383;
    }
  goto L454;

 L383: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      return 58;  /* subqi3 */
    }
  goto L454;

 L552: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode
      && GET_CODE (x1) == SUBREG
      && XINT (x1, 1) == 1)
    goto L553;
  x1 = XEXP (x0, 0);
  goto L11;

 L553: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L554;
  x1 = XEXP (x0, 0);
  goto L11;

 L554: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L555;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L555: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      return 86;  /* *movqi_for_initializer */
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L936: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L351;
    }
 L937: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L396;
    }
  goto L11;

 L351: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L977;
  x1 = XEXP (x0, 0);
  goto L937;

 L977: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case PLUS:
      goto L352;
    case MINUS:
      goto L367;
    case NEG:
      goto L443;
    case ZERO_EXTEND:
      goto L465;
    case SIGN_EXTEND:
      goto L473;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L937;

 L352: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L353;
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L353: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      return 52;  /* addsi3 */
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L367: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L368;
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L368: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      return 55;  /* subsi3 */
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L443: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      return 65;  /* negsi2 */
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L465: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (general_operand (x2, HImode))
    {
      operands[1] = x2;
      return 71;  /* zero_extendhisi2 */
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L473: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (general_operand (x2, HImode))
    {
      operands[1] = x2;
      return 73;  /* extendhisi2 */
    }
  x1 = XEXP (x0, 0);
  goto L937;

 L396: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L982;
  x1 = XEXP (x0, 0);
  goto L11;

 L982: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case MULT:
      goto L397;
    case IOR:
      goto L408;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L11;

 L397: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L984;
    case HImode:
      goto L985;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L984: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L398;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L398: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L399;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L399: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 59;  /* mulsi3 */
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L985: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L404;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L404: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[2] = x2;
      return 60;  /* umulhisi3 */
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L408: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ASHIFT)
    goto L409;
  x1 = XEXP (x0, 0);
  goto L11;

 L409: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTEND)
    goto L410;
  x1 = XEXP (x0, 0);
  goto L11;

 L410: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == HImode
      && GET_CODE (x4) == DIV)
    goto L411;
  x1 = XEXP (x0, 0);
  goto L11;

 L411: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, SImode))
    {
      operands[1] = x5;
      goto L412;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L412: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (nonimmediate_operand (x5, HImode))
    {
      operands[2] = x5;
      goto L413;
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L413: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (16)])
    goto L414;
  x1 = XEXP (x0, 0);
  goto L11;

 L414: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTEND)
    goto L415;
  x1 = XEXP (x0, 0);
  goto L11;

 L415: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == MOD)
    goto L416;
  x1 = XEXP (x0, 0);
  goto L11;

 L416: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[1]))
    goto L417;
  x1 = XEXP (x0, 0);
  goto L11;

 L417: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (rtx_equal_p (x4, operands[2]))
    {
      return 61;  /* divmodsihi3 */
    }
  x1 = XEXP (x0, 0);
  goto L11;

 L12: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  switch (GET_MODE (x1))
    {
    case HImode:
      goto L986;
    case QImode:
      goto L987;
    default:
      break;
    }
 L18: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == COMPARE)
    goto L19;
  goto ret0;

 L986: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, HImode))
    {
      operands[0] = x1;
      return 3;  /* tsthi */
    }
  goto L18;

 L987: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, QImode))
    {
      operands[0] = x1;
      return 4;  /* tstqi */
    }
  goto L18;

 L19: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L988;
    case QImode:
      goto L989;
    default:
      break;
    }
  goto ret0;

 L988: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L20;
    }
  goto ret0;

 L20: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[1] = x2;
      return 5;  /* cmphi */
    }
  goto ret0;

 L989: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L25;
    }
 L990: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L485;
    }
  goto ret0;

 L25: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      return 6;  /* cmpqi */
    }
  x2 = XEXP (x1, 0);
  goto L990;

 L485: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == PLUS)
    goto L486;
  goto ret0;

 L486: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L487;
    }
  goto ret0;

 L487: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == MULT)
    goto L488;
  goto ret0;

 L488: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (const_int_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L489;
    }
  goto ret0;

 L489: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_operand (x4, HImode))
    {
      operands[3] = x4;
      goto L490;
    }
  goto ret0;

 L490: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2238 "../../gcc/config/tms9900/tms9900.md"
(INTVAL(operands[3]) == 256 && (INTVAL(operands[1]) == 0 || INTVAL(operands[1]) == 255)))
    {
      return 76;  /* *cmpqi_as_hi */
    }
  goto ret0;

 L212: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonimmediate_operand (x1, HImode))
    {
      operands[0] = x1;
      return 28;  /* indirect_jump */
    }
  switch (GET_CODE (x1))
    {
    case IF_THEN_ELSE:
      goto L29;
    case LABEL_REF:
      goto L209;
    default:
     break;
   }
  goto ret0;

 L29: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_CODE (x2))
    {
    case EQ:
      goto L30;
    case NE:
      goto L48;
    case LTU:
      goto L66;
    case LEU:
      goto L84;
    case GTU:
      goto L102;
    case GEU:
      goto L120;
    case LT:
      goto L138;
    case LE:
      goto L156;
    case GT:
      goto L174;
    case GE:
      goto L192;
    default:
     break;
   }
  goto ret0;

 L30: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L31;
  goto ret0;

 L31: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L32;
  goto ret0;

 L32: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L33;
    case PC:
      goto L42;
    default:
     break;
   }
  goto ret0;

 L33: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L34;

 L34: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 7;  /* beq */
    }
  goto ret0;

 L42: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L43;
  goto ret0;

 L43: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 8;  /* *beq_reversed */

 L48: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L49;
  goto ret0;

 L49: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L50;
  goto ret0;

 L50: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L51;
    case PC:
      goto L60;
    default:
     break;
   }
  goto ret0;

 L51: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L52;

 L52: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 9;  /* bne */
    }
  goto ret0;

 L60: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L61;
  goto ret0;

 L61: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 10;  /* *bne_reversed */

 L66: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L67;
  goto ret0;

 L67: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L68;
  goto ret0;

 L68: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L69;
    case PC:
      goto L78;
    default:
     break;
   }
  goto ret0;

 L69: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L70;

 L70: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 11;  /* bltu */
    }
  goto ret0;

 L78: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L79;
  goto ret0;

 L79: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 12;  /* *bltu_reversed */

 L84: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L85;
  goto ret0;

 L85: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L86;
  goto ret0;

 L86: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L87;
    case PC:
      goto L96;
    default:
     break;
   }
  goto ret0;

 L87: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L88;

 L88: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 13;  /* bleu */
    }
  goto ret0;

 L96: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L97;
  goto ret0;

 L97: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 14;  /* *bleu_reversed */

 L102: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L103;
  goto ret0;

 L103: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L104;
  goto ret0;

 L104: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L105;
    case PC:
      goto L114;
    default:
     break;
   }
  goto ret0;

 L105: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L106;

 L106: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 15;  /* bgtu */
    }
  goto ret0;

 L114: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L115;
  goto ret0;

 L115: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 16;  /* *bgtu_reversed */

 L120: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L121;
  goto ret0;

 L121: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L122;
  goto ret0;

 L122: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L123;
    case PC:
      goto L132;
    default:
     break;
   }
  goto ret0;

 L123: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L124;

 L124: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 17;  /* bgeu */
    }
  goto ret0;

 L132: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L133;
  goto ret0;

 L133: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 18;  /* *bgeu_reversed */

 L138: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L139;
  goto ret0;

 L139: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L140;
  goto ret0;

 L140: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L141;
    case PC:
      goto L150;
    default:
     break;
   }
  goto ret0;

 L141: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L142;

 L142: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 19;  /* blt */
    }
  goto ret0;

 L150: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L151;
  goto ret0;

 L151: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 20;  /* *blt_reversed */

 L156: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L157;
  goto ret0;

 L157: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L158;
  goto ret0;

 L158: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L159;
    case PC:
      goto L168;
    default:
     break;
   }
  goto ret0;

 L159: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L160;

 L160: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 21;  /* ble */
    }
  goto ret0;

 L168: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L169;
  goto ret0;

 L169: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 22;  /* *ble_reversed */

 L174: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L175;
  goto ret0;

 L175: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L176;
  goto ret0;

 L176: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L177;
    case PC:
      goto L186;
    default:
     break;
   }
  goto ret0;

 L177: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L178;

 L178: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 23;  /* bgt */
    }
  goto ret0;

 L186: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L187;
  goto ret0;

 L187: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 24;  /* *bgt_reversed */

 L192: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == CC0)
    goto L193;
  goto ret0;

 L193: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (x3 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L194;
  goto ret0;

 L194: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L195;
    case PC:
      goto L204;
    default:
     break;
   }
  goto ret0;

 L195: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L196;

 L196: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 25;  /* bge */
    }
  goto ret0;

 L204: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L205;
  goto ret0;

 L205: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 26;  /* *bge_reversed */

 L209: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  operands[0] = x2;
  return 27;  /* jump */
 ret0:
  return -1;
}

int
recog (rtx x0 ATTRIBUTE_UNUSED,
	rtx insn ATTRIBUTE_UNUSED,
	int *pnum_clobbers ATTRIBUTE_UNUSED)
{
  rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  rtx x1 ATTRIBUTE_UNUSED;
  rtx x2 ATTRIBUTE_UNUSED;
  rtx x3 ATTRIBUTE_UNUSED;
  rtx x4 ATTRIBUTE_UNUSED;
  rtx x5 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;
  recog_data.insn = NULL_RTX;

  switch (GET_CODE (x0))
    {
    case CALL:
      goto L1;
    case SET:
      goto L4;
    case UNSPEC:
      goto L928;
    case PARALLEL:
      goto L929;
    case CONST_INT:
      goto L931;
    default:
     break;
   }
  goto ret0;

 L1: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  if (nonimmediate_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L2;
    }
  goto ret0;

 L2: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, HImode))
    {
      operands[1] = x1;
      return 0;  /* call */
    }
  goto ret0;

 L4: ATTRIBUTE_UNUSED_LABEL
  return recog_1 (x0, insn, pnum_clobbers);

 L928: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x0, 0) == 1
      && XINT (x0, 1) == 0)
    goto L9;
  goto ret0;

 L9: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (general_operand (x1, HImode))
    {
      operands[0] = x1;
      return 2;  /* *rt */
    }
  goto ret0;

 L929: ATTRIBUTE_UNUSED_LABEL
  switch (XVECLEN (x0, 0))
    {
    case 3:
      goto L214;
    case 2:
      goto L223;
    default:
      break;
    }
  goto ret0;

 L214: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  switch (GET_CODE (x1))
    {
    case CLOBBER:
      goto L215;
    case SET:
      goto L386;
    default:
     break;
   }
  goto ret0;

 L215: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L216;
    }
  goto ret0;

 L216: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L217;
  goto ret0;

 L217: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == PC)
    goto L218;
  goto ret0;

 L218: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L219;
    }
  goto ret0;

 L219: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L220;
  goto ret0;

 L220: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == LABEL_REF)
    goto L221;
  goto ret0;

 L221: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[1] = x3;
  return 29;  /* tablejump */

 L386: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L387;
    }
  goto ret0;

 L387: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MULT)
    goto L388;
  goto ret0;

 L388: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L389;
    }
  goto ret0;

 L389: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L390;
    }
  goto ret0;

 L390: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L391;
  goto ret0;

 L391: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L392;
    }
  goto ret0;

 L392: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L393;
  goto ret0;

 L393: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[4] = x2;
      return 59;  /* mulsi3 */
    }
  goto ret0;

 L223: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  switch (GET_CODE (x1))
    {
    case CLOBBER:
      goto L224;
    case SET:
      goto L420;
    default:
     break;
   }
  goto ret0;

 L224: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L991;
    case QImode:
      goto L992;
    default:
      break;
    }
  goto ret0;

 L991: ATTRIBUTE_UNUSED_LABEL
  if (scratch_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L225;
    }
  goto ret0;

 L225: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L226;
  goto ret0;

 L226: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L993;
    case HImode:
      goto L994;
    default:
      break;
    }
  goto ret0;

 L993: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L227;
    }
  goto ret0;

 L227: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L995;
  goto ret0;

 L995: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ASHIFT:
      goto L228;
    case ASHIFTRT:
      goto L246;
    case LSHIFTRT:
      goto L264;
    default:
     break;
   }
  goto ret0;

 L228: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L229;
    }
  goto ret0;

 L229: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (shift_count_operand (x3, HImode))
    {
      operands[2] = x3;
      return 30;  /* ashlsi3 */
    }
  goto ret0;

 L246: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L247;
    }
  goto ret0;

 L247: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (shift_count_operand (x3, HImode))
    {
      operands[2] = x3;
      return 33;  /* ashrsi3 */
    }
  goto ret0;

 L264: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L265;
    }
  goto ret0;

 L265: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (shift_count_operand (x3, HImode))
    {
      operands[2] = x3;
      return 36;  /* lshrsi3 */
    }
  goto ret0;

 L994: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L286;
    }
  goto ret0;

 L286: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == AND)
    goto L287;
  goto ret0;

 L287: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L288;
    }
  goto ret0;

 L288: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      return 40;  /* andhi3 */
    }
  goto ret0;

 L992: ATTRIBUTE_UNUSED_LABEL
  if (scratch_operand (x2, QImode))
    {
      operands[3] = x2;
      goto L304;
    }
  goto ret0;

 L304: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L305;
  goto ret0;

 L305: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L306;
    }
  goto ret0;

 L306: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == AND)
    goto L307;
  goto ret0;

 L307: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L308;
    }
  goto ret0;

 L308: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      return 43;  /* andqi3 */
    }
  goto ret0;

 L420: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L421;
    }
  goto ret0;

 L421: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == NOT)
    goto L422;
  goto ret0;

 L422: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L423;
  goto ret0;

 L423: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L424;
  goto ret0;

 L424: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L425;
    }
  goto ret0;

 L425: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == IF_THEN_ELSE)
    goto L426;
  goto ret0;

 L426: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == LT)
    goto L427;
  goto ret0;

 L427: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[1]))
    goto L428;
  goto ret0;

 L428: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L429;
  goto ret0;

 L429: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == NEG)
    goto L430;
  goto ret0;

 L430: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[0]))
    goto L431;
  goto ret0;

 L431: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (rtx_equal_p (x3, operands[0]))
    {
      return 62;  /* divfixuphi2 */
    }
  goto ret0;

 L931: ATTRIBUTE_UNUSED_LABEL
  if (XWINT (x0, 0) == 0L)
    {
      return 74;  /* nop */
    }
  goto ret0;
 ret0:
  return -1;
}

rtx
split_insns (rtx x0 ATTRIBUTE_UNUSED, rtx insn ATTRIBUTE_UNUSED)
{
  rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  rtx x1 ATTRIBUTE_UNUSED;
  rtx x2 ATTRIBUTE_UNUSED;
  rtx x3 ATTRIBUTE_UNUSED;
  rtx x4 ATTRIBUTE_UNUSED;
  rtx x5 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;
  recog_data.insn = NULL_RTX;
  goto ret0;
 ret0:
  return 0;
}

rtx
peephole2_insns (rtx x0 ATTRIBUTE_UNUSED,
	rtx insn ATTRIBUTE_UNUSED,
	int *_pmatch_len ATTRIBUTE_UNUSED)
{
  rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  rtx x1 ATTRIBUTE_UNUSED;
  rtx x2 ATTRIBUTE_UNUSED;
  rtx x3 ATTRIBUTE_UNUSED;
  rtx x4 ATTRIBUTE_UNUSED;
  rtx x5 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;
  recog_data.insn = NULL_RTX;

  if (peep2_current_count >= 2)
    goto L562;
 L573: ATTRIBUTE_UNUSED_LABEL
  if (peep2_current_count >= 3)
    goto L574;
 L815: ATTRIBUTE_UNUSED_LABEL
  if (peep2_current_count >= 2)
    goto L816;
 L892: ATTRIBUTE_UNUSED_LABEL
  if (peep2_current_count >= 4)
    goto L893;
  goto ret0;

 L562: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x0) == SET)
    goto L563;
  goto L573;

 L563: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  switch (GET_MODE (x1))
    {
    case HImode:
      goto L998;
    case QImode:
      goto L999;
    default:
      break;
    }
 L603: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == CC0)
    goto L604;
  goto L573;

 L998: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L564;
    }
  goto L603;

 L564: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L1000;
  x1 = XEXP (x0, 0);
  goto L603;

 L1000: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case SIGN_EXTEND:
      goto L565;
    case ASHIFTRT:
      goto L779;
    case LSHIFTRT:
      goto L789;
    case ASHIFT:
      goto L799;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L603;

 L565: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L566;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L566: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L567;
  x1 = XEXP (x0, 0);
  goto L603;

 L567: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L568;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L568: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L569;
  x1 = XEXP (x0, 0);
  goto L603;

 L569: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L570;
  x1 = XEXP (x0, 0);
  goto L603;

 L570: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == PLUS)
    goto L571;
  x1 = XEXP (x0, 0);
  goto L603;

 L571: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (const_int_operand (x4, HImode))
    {
      operands[3] = x4;
      goto L572;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L572: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_operand (x4, HImode))
    {
      operands[4] = x4;
      *_pmatch_len = 1;
      tem = gen_peephole2_91 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L779: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L780;
  x1 = XEXP (x0, 0);
  goto L603;

 L780: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L781;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L781: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L782;
  x1 = XEXP (x0, 0);
  goto L603;

 L782: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L783;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L783: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 1)
    goto L784;
  x1 = XEXP (x0, 0);
  goto L603;

 L784: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0])
      && 
#line 2420 "../../gcc/config/tms9900/tms9900.md"
(REGNO(operands[0]) == REGNO(operands[2])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_108 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L789: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L790;
  x1 = XEXP (x0, 0);
  goto L603;

 L790: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L791;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L791: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L792;
  x1 = XEXP (x0, 0);
  goto L603;

 L792: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L793;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L793: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 1)
    goto L794;
  x1 = XEXP (x0, 0);
  goto L603;

 L794: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0])
      && 
#line 2458 "../../gcc/config/tms9900/tms9900.md"
(REGNO(operands[0]) == REGNO(operands[2])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_109 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L799: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L800;
  x1 = XEXP (x0, 0);
  goto L603;

 L800: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L801;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L801: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L802;
  x1 = XEXP (x0, 0);
  goto L603;

 L802: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L803;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L803: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 1)
    goto L804;
  x1 = XEXP (x0, 0);
  goto L603;

 L804: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0])
      && 
#line 2497 "../../gcc/config/tms9900/tms9900.md"
(REGNO(operands[0]) == REGNO(operands[2])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_110 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L999: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L808;
    }
  goto L603;

 L808: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode
      && GET_CODE (x1) == ASHIFTRT)
    goto L809;
  x1 = XEXP (x0, 0);
  goto L603;

 L809: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L810;
  x1 = XEXP (x0, 0);
  goto L603;

 L810: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L811;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L811: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L812;
  x1 = XEXP (x0, 0);
  goto L603;

 L812: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L813;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L813: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == SIGN_EXTEND)
    goto L814;
  x1 = XEXP (x0, 0);
  goto L603;

 L814: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0])
      && 
#line 2527 "../../gcc/config/tms9900/tms9900.md"
(REGNO(operands[0]) == REGNO(operands[2])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_111 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L603;

 L604: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == COMPARE)
    goto L605;
  goto L573;

 L605: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L606;
    }
  goto L573;

 L606: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (immediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L607;
    }
  goto L573;

 L607: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L608;
  goto L573;

 L608: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == PC)
    goto L609;
  goto L573;

 L609: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L610;
  goto L573;

 L610: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_CODE (x3))
    {
    case EQ:
      goto L611;
    case NE:
      goto L626;
    default:
     break;
   }
  goto L573;

 L611: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L612;
  goto L573;

 L612: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L613;
  goto L573;

 L613: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L614;
  goto L573;

 L614: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[2] = x4;
  goto L615;

 L615: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2155 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(2, operands[0])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_98 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L573;

 L626: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L627;
  goto L573;

 L627: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L628;
  goto L573;

 L628: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L629;
  goto L573;

 L629: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[2] = x4;
  goto L630;

 L630: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2194 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(2, operands[0])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_99 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L573;

 L574: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x0) == SET)
    goto L575;
  goto L815;

 L575: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  switch (GET_MODE (x1))
    {
    case HImode:
      goto L1004;
    case QImode:
      goto L1005;
    default:
      break;
    }
  goto L815;

 L1004: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L576;
    }
  goto L815;

 L576: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L1006;
  goto L815;

 L1006: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == SIGN_EXTEND)
    goto L577;
  if (register_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L864;
    }
  goto L815;

 L577: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L578;
    }
  goto L815;

 L578: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L579;
  goto L815;

 L579: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L580;
    }
  goto L815;

 L580: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode)
    goto L1008;
  goto L815;

 L1008: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ASHIFTRT:
      goto L581;
    case LSHIFTRT:
      goto L595;
    default:
     break;
   }
  goto L815;

 L581: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[4] = x3;
      goto L582;
    }
  goto L815;

 L582: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (shift_count_operand (x3, HImode))
    {
      operands[5] = x3;
      goto L583;
    }
  goto L815;

 L583: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L584;
  goto L815;

 L584: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[6] = x2;
      goto L585;
    }
  goto L815;

 L585: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 1)
    goto L586;
  goto L815;

 L586: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[7] = x3;
      *_pmatch_len = 2;
      tem = gen_peephole2_92 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L595: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[4] = x3;
      goto L596;
    }
  goto L815;

 L596: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (shift_count_operand (x3, HImode))
    {
      operands[5] = x3;
      goto L597;
    }
  goto L815;

 L597: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L598;
  goto L815;

 L598: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[6] = x2;
      goto L599;
    }
  goto L815;

 L599: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 1)
    goto L600;
  goto L815;

 L600: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[7] = x3;
      *_pmatch_len = 2;
      tem = gen_peephole2_93 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L864: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L865;
  goto L815;

 L865: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L866;
    }
  goto L815;

 L866: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L867;
    }
  goto L815;

 L867: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == PARALLEL
      && XVECLEN (x1, 0) == 2)
    goto L868;
  goto L815;

 L868: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_CODE (x2) == CLOBBER)
    goto L869;
  goto L815;

 L869: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[4] = x3;
      goto L870;
    }
  goto L815;

 L870: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 1);
  if (GET_CODE (x2) == SET)
    goto L871;
  goto L815;

 L871: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[5] = x3;
      goto L872;
    }
  goto L815;

 L872: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode)
    goto L1010;
  goto L815;

 L1010: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x3))
    {
    case LSHIFTRT:
      goto L873;
    case ASHIFT:
      goto L889;
    default:
     break;
   }
  goto L815;

 L873: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[6] = x4;
      goto L874;
    }
  goto L815;

 L874: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_operand (x4, HImode))
    {
      operands[7] = x4;
      goto L875;
    }
  goto L815;

 L875: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2704 "../../gcc/config/tms9900/tms9900.md"
(((REGNO(operands[0]) == REGNO(operands[5])) &&
    (REGNO(operands[2]) == (REGNO(operands[0])+1)) &&
    (INTVAL(operands[7]) == 16)
   )))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_116 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L889: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[6] = x4;
      goto L890;
    }
  goto L815;

 L890: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_operand (x4, HImode))
    {
      operands[7] = x4;
      goto L891;
    }
  goto L815;

 L891: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2752 "../../gcc/config/tms9900/tms9900.md"
(((REGNO(operands[0]) == REGNO(operands[5])) &&
    (REGNO(operands[2]) == (REGNO(operands[0])+1)) &&
    (INTVAL(operands[7]) == 16)
   )))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_117 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L1005: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L634;
    }
  goto L815;

 L634: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (const_int_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L635;
    }
  goto L815;

 L635: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L636;
  goto L815;

 L636: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == CC0)
    goto L637;
  goto L815;

 L637: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == COMPARE)
    goto L638;
  goto L815;

 L638: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L639;
    }
  goto L815;

 L639: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[0]))
    goto L640;
  goto L815;

 L640: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L641;
  goto L815;

 L641: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == PC)
    goto L642;
  goto L815;

 L642: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L643;
  goto L815;

 L643: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_CODE (x3))
    {
    case GTU:
      goto L644;
    case LTU:
      goto L662;
    case GEU:
      goto L680;
    case LEU:
      goto L698;
    case GT:
      goto L716;
    case LT:
      goto L734;
    case GE:
      goto L752;
    case LE:
      goto L770;
    default:
     break;
   }
  goto L815;

 L644: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L645;
  goto L815;

 L645: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L646;
  goto L815;

 L646: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L647;
  goto L815;

 L647: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L648;

 L648: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2220 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_100 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L662: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L663;
  goto L815;

 L663: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L664;
  goto L815;

 L664: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L665;
  goto L815;

 L665: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L666;

 L666: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2257 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_101 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L680: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L681;
  goto L815;

 L681: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L682;
  goto L815;

 L682: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L683;
  goto L815;

 L683: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L684;

 L684: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2280 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_102 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L698: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L699;
  goto L815;

 L699: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L700;
  goto L815;

 L700: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L701;
  goto L815;

 L701: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L702;

 L702: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2303 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_103 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L716: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L717;
  goto L815;

 L717: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L718;
  goto L815;

 L718: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L719;
  goto L815;

 L719: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L720;

 L720: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2326 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_104 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L734: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L735;
  goto L815;

 L735: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L736;
  goto L815;

 L736: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L737;
  goto L815;

 L737: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L738;

 L738: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2349 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_105 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L752: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L753;
  goto L815;

 L753: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L754;
  goto L815;

 L754: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L755;
  goto L815;

 L755: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L756;

 L756: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2372 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_106 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L770: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CC0)
    goto L771;
  goto L815;

 L771: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (x4 == const_int_rtx[MAX_SAVED_CONST_INT + (0)])
    goto L772;
  goto L815;

 L772: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L773;
  goto L815;

 L773: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L774;

 L774: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC
      && 
#line 2395 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(3, operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_107 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L815;

 L816: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x0) == SET)
    goto L817;
  goto L892;

 L817: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  switch (GET_MODE (x1))
    {
    case HImode:
      goto L1012;
    case QImode:
      goto L1013;
    default:
      break;
    }
  goto L892;

 L1012: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L818;
    }
  goto L892;

 L818: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L1014;
  goto L892;

 L1014: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case SIGN_EXTEND:
      goto L819;
    case LSHIFTRT:
      goto L830;
    case ZERO_EXTEND:
      goto L853;
    case SUBREG:
    case MEM:
      goto L1017;
    default:
      goto L892;
   }
 L1017: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L909;
    }
  goto L892;

 L819: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L820;
    }
  goto L892;

 L820: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L821;
  goto L892;

 L821: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == HImode)
    goto L1018;
  goto L892;

 L1018: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L822;
    }
 L1019: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L845;
    }
  goto L892;

 L822: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L823;
  x2 = XEXP (x1, 0);
  goto L1019;

 L823: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[2]))
    goto L824;
  x2 = XEXP (x1, 0);
  goto L1019;

 L824: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[3] = x3;
      goto L825;
    }
  x2 = XEXP (x1, 0);
  goto L1019;

 L825: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2541 "../../gcc/config/tms9900/tms9900.md"
(REGNO(operands[0]) == REGNO(operands[2])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_112 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x2 = XEXP (x1, 0);
  goto L1019;

 L845: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L846;
  goto L892;

 L846: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[4] = x3;
      goto L847;
    }
  goto L892;

 L847: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[5] = x3;
      goto L848;
    }
  goto L892;

 L848: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2606 "../../gcc/config/tms9900/tms9900.md"
((REGNO(operands[0]) == REGNO(operands[3]))))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_114 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L892;

 L830: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L831;
    }
  goto L892;

 L831: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L832;
    }
  goto L892;

 L832: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L833;
  goto L892;

 L833: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L834;
    }
  goto L892;

 L834: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == AND)
    goto L835;
  goto L892;

 L835: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (const_int_operand (x3, HImode))
    {
      operands[4] = x3;
      goto L836;
    }
  goto L892;

 L836: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[5] = x3;
      goto L837;
    }
  goto L892;

 L837: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2574 "../../gcc/config/tms9900/tms9900.md"
((REGNO(operands[0]) == REGNO(operands[3])) && (INTVAL(operands[5]) == (1<<(8-INTVAL(operands[2])))-1)))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_113 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L892;

 L853: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L854;
    }
  goto L892;

 L854: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L855;
  goto L892;

 L855: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L856;
    }
  goto L892;

 L856: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L857;
  goto L892;

 L857: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[4] = x3;
      goto L858;
    }
  goto L892;

 L858: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[5] = x3;
      goto L859;
    }
  goto L892;

 L859: ATTRIBUTE_UNUSED_LABEL
  if (
#line 2649 "../../gcc/config/tms9900/tms9900.md"
((REGNO(operands[0]) == REGNO(operands[3]))))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_115 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L892;

 L909: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L910;
  goto L892;

 L910: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L911;
    }
  goto L892;

 L911: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0])
      && 
#line 2840 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(2, operands[0])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_119 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L892;

 L1013: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L915;
    }
  goto L892;

 L915: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode)
    goto L1021;
  goto L892;

 L1021: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == SUBREG
      && XINT (x1, 1) == 1)
    goto L923;
 L1020: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L916;
    }
  goto L892;

 L923: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L924;
    }
  goto L1020;

 L924: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L925;
  x1 = XEXP (x0, 1);
  goto L1020;

 L925: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L926;
    }
  x1 = XEXP (x0, 1);
  goto L1020;

 L926: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ZERO_EXTEND)
    goto L927;
  x1 = XEXP (x0, 1);
  goto L1020;

 L927: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0])
      && 
#line 2864 "../../gcc/config/tms9900/tms9900.md"
(REGNO(operands[0]) == REGNO(operands[2])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_121 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 1);
  goto L1020;

 L916: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L917;
  goto L892;

 L917: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L918;
    }
  goto L892;

 L918: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0])
      && 
#line 2851 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(2, operands[0])))
    {
      *_pmatch_len = 1;
      tem = gen_peephole2_120 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto L892;

 L893: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x0) == SET)
    goto L894;
  goto ret0;

 L894: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  if (register_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L895;
    }
  goto ret0;

 L895: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (const_int_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L896;
    }
  goto ret0;

 L896: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L897;
  goto ret0;

 L897: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L898;
    }
  goto ret0;

 L898: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    goto L899;
  goto ret0;

 L899: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L900;
  goto ret0;

 L900: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[3] = x2;
      goto L901;
    }
  goto ret0;

 L901: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, QImode))
    {
      operands[4] = x2;
      goto L902;
    }
  goto ret0;

 L902: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (3);
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L903;
  goto ret0;

 L903: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[5] = x2;
      goto L904;
    }
  goto ret0;

 L904: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[3])
      && 
#line 2786 "../../gcc/config/tms9900/tms9900.md"
(peep2_reg_dead_p(4, operands[0]) && peep2_reg_dead_p(4, operands[3])))
    {
      *_pmatch_len = 3;
      tem = gen_peephole2_118 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;
 ret0:
  return 0;
}

