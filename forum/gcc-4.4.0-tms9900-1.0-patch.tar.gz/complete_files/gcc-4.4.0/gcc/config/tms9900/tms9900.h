/* Definitions of target machine for GNU compiler.
   Texas Instruments TMS9900
   Copyright (C) 2009
   Free Software Foundation, Inc.
   Contributed by Eric Welser (ewelser@gmail.com)

This file is part of GCC.

GCC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

GCC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GCC; see the file COPYING3.  If not see
<http://www.gnu.org/licenses/>.
*/

/*****************************************************************************
**
** Controlling the Compilation Driver, `gcc'
**
*****************************************************************************/


#undef ENDFILE_SPEC

/* Options to pass to the assembler */
#ifndef ASM_SPEC
#define ASM_SPEC ""
#endif

/* Options for the linker. 
   We need to tell the linker the target elf format.
   This can be overridden by -Wl option of gcc.  */
#ifndef LINK_SPEC
#define LINK_SPEC "-m tms9900"
#endif

/* More linker options, these are used at the beginning of the command */
#undef STARTFILE_SPEC
/*#define STARTFILE_SPEC "crt1%O%s"*/
#define STARTFILE_SPEC ""

/* More linker options, used at the end of the command string */
#ifndef LIB_SPEC
#define LIB_SPEC       ""
#endif

/* Options to pass to CC1 and other language front ends */
#ifndef CC1_SPEC
#define CC1_SPEC       ""
#endif

/* Options to pass to the C Preprocessor */
#ifndef CPP_SPEC
#define CPP_SPEC ""
#endif

/* Names to predefine in the preprocessor for this target machine.  */
#define TARGET_CPU_CPP_BUILTINS()		\
  do						\
    {						\
      builtin_define_std ("tms9900");		\
    }						\
  while (0)

/* As an embedded target, we have no libc.  */
#ifndef inhibit_libc
#  define inhibit_libc
#endif

/* Forward type declaration for prototypes definitions.
   rtx_ptr is equivalent to rtx. Can't use the same name.  */
struct rtx_def;
typedef struct rtx_def *rtx_ptr;

union tree_node;
typedef union tree_node *tree_ptr;

/* We can't declare enum machine_mode forward nor include 'machmode.h' here.
   Prototypes defined here will use an int instead. It's better than no
   prototype at all.  */
typedef int enum_machine_mode;

/*****************************************************************************
**
** Run-time Target Specification
**
*****************************************************************************/

/* Run-time compilation parameters selecting different hardware subsets.  */

extern short *reg_renumber;	/* def in local_alloc.c */

#define TARGET_OP_TIME		(optimize && optimize_size == 0)
#define TARGET_RELAX            (TARGET_NO_DIRECT_MODE)

/* Default target_flags if no switches specified.  */
#ifndef TARGET_DEFAULT
# define TARGET_DEFAULT		0
#endif

/* Define this macro as a C expression for the initializer of an
   array of string to tell the driver program which options are
   defaults for this target and thus do not need to be handled
   specially when using `MULTILIB_OPTIONS'.  */
#ifndef MULTILIB_DEFAULTS
# define MULTILIB_DEFAULTS { "tms9900" }
#endif

/* Print subsidiary information on the compiler version in use.  */
#define TARGET_VERSION	fprintf (stderr, " (TMS9900)")

/* Sometimes certain combinations of command options do not make
   sense on a particular target machine.  You can define a macro
   `OVERRIDE_OPTIONS' to take account of this.  This macro, if
   defined, is executed once just after all the command options have
   been parsed.

   Don't use this macro to turn on various extra optimizations for
   `-O'.  That is what `OPTIMIZATION_OPTIONS' is for.  */
/*EMW
#define OVERRIDE_OPTIONS	tms9900_override_options ()
*/


/* target machine storage layout */

/* Define this as 1 if most significant byte of a word is the lowest numbered.  */
#define BYTES_BIG_ENDIAN 	1

/* Define this as 1 if most significant bit is lowest numbered
   in instructions that operate on numbered bit-fields.  */
#define BITS_BIG_ENDIAN         1

/* Define this as 1 if most significant word of a multiword number is lowest numbered.  */
#define WORDS_BIG_ENDIAN 	1

/* Width of a word, in units (bytes).  */
#define UNITS_PER_WORD		2

/* Definition of size_t.  This is really an unsigned short as the
   TMS9900 only handles a 64K address space.  */
#define SIZE_TYPE               "short unsigned int"

/* A C expression for a string describing the name of the data type
   to use for the result of subtracting two pointers.  The typedef
   name `ptrdiff_t' is defined using the contents of the string.
   The 68hc11 only has a 64K address space.  */
#define PTRDIFF_TYPE            "short int"

/* Allocation boundary (bits) for storing pointers in memory.  */
#define POINTER_BOUNDARY	16

/* Normal alignment required for function parameters on the stack, in bits.
   This can't be less than BITS_PER_WORD */
#define PARM_BOUNDARY		(BITS_PER_WORD)

/* Boundary (bits) on which stack pointer should be aligned.  */
#define STACK_BOUNDARY		16

/* Allocation boundary (bits) for the code of a function.  */
#define FUNCTION_BOUNDARY	16

/* Biggest alignment which, if violated, may cause a fault */
#define BIGGEST_ALIGNMENT	16

/* Alignment of field after `int : 0' in a structure.  */
#define EMPTY_FIELD_BOUNDARY	16

/* Every structure's size must be a multiple of this.  */
#define STRUCTURE_SIZE_BOUNDARY 16

/* Define this as 1 if instructions will fail to work if given data not
   on the nominal alignment.  If instructions will merely go slower
   in that case, do not define this macro.  */
#define STRICT_ALIGNMENT	1

/* An integer expression for the size in bits of the largest integer
   machine mode that should actually be used.  All integer machine modes of
   this size or smaller can be used for structures and unions with the
   appropriate sizes.  */
#define MAX_FIXED_MODE_SIZE	64

/* target machine storage layout */

/* Size (bits) of the type "int" on target machine */
#define INT_TYPE_SIZE           16

/* Size (bits) of the type "short" on target machine */
#define SHORT_TYPE_SIZE		16

/* Size (bits) of the type "long" on target machine */
#define LONG_TYPE_SIZE		32

/* Size (bits) of the type "long long" on target machine */
#define LONG_LONG_TYPE_SIZE     64

/* A C expression for the size in bits of the type `float' on the
   target machine. If you don't define this, the default is one word.
   Don't use default: a word is only 16.  */
#define FLOAT_TYPE_SIZE         32

/* A C expression for the size in bits of the type double on the target
   machine. If you don't define this, the default is two words.
   Be IEEE compliant.  */
#define DOUBLE_TYPE_SIZE        64

#define LONG_DOUBLE_TYPE_SIZE   64

/* Define this as 1 if `char' should by default be signed; else as 0.  */
#define DEFAULT_SIGNED_CHAR	1

/* A C expression for a string describing the name of the data type
   to use for wide characters.  The typedef name `wchar_t' is defined
   using the contents of the string.
   
   Define these to avoid dependence on meaning of `int'.
   Note that WCHAR_TYPE_SIZE is used in cexp.y,
   where TARGET_SHORT is not available.  */
#define WCHAR_TYPE              "short int"
#define WCHAR_TYPE_SIZE         16

/* Standard register usage.  */

#define HARD_REG_SIZE           (1)

#define REGS_PER_WORD (UNITS_PER_WORD / HARD_REG_SIZE)

/* Assign names to real TMS9900 registers. */

/* Shift count register */
#define HARD_SC_REGNUM		0
#define HARD_R1_REGNUM		2
#define HARD_R2_REGNUM		4
#define HARD_R3_REGNUM		6
#define HARD_R4_REGNUM		8
#define HARD_R5_REGNUM		10
#define HARD_R6_REGNUM		12
#define HARD_R7_REGNUM		14
#define HARD_R8_REGNUM		16
#define HARD_R9_REGNUM		18
/* Stack pointer */
#define HARD_SP_REGNUM		20
/* Old PC after BL instruction */
#define HARD_LR_REGNUM		22
/* CRU base address */
#define HARD_CB_REGNUM		24
/* Old workspace after BLWP instruction */
#define HARD_LW_REGNUM		26
/* Old PC after BLWP instruction */
#define HARD_LP_REGNUM		28
/* Old status register after BLWP instruction */
#define HARD_LS_REGNUM		30
/* Fake PC register */
#define HARD_PC_REGNUM          32


/* Number of actual hardware registers. The hardware registers are assigned
   numbers for the compiler from 0 to just below FIRST_PSEUDO_REGISTER. 
   All registers that the compiler knows about must be given numbers, even
   those that are not normally considered general registers.  */
#define FIRST_PSEUDO_REGISTER	(34)

/* Last available soft-register for GCC.  */
#define SOFT_AP_REGNUM		(FIRST_PSEUDO_REGISTER)
#define SOFT_REG_LAST           (FIRST_PSEUDO_REGISTER + 2)


/* 1 for registers that have pervasive standard uses and are not available
   for the register allocator.  */
/* EMW - I'm only considering the stack pointer fixed for now */
#define FIXED_REGISTERS \
  {0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 1,1, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0}
/* sc   1    2    3    4    5    6    7    8    9    SP   LR   CB   LW   LP   LS   PC*/

/* 0 for registers which must be preserved across function call boundaries */
#define CALL_USED_REGISTERS \
  {1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 0,0, 1,1, 0,0, 0,0, 0,0, 0,0}
/* sc   1    2    3    4    5    6    7    8    9    SP   LR   CB   LW   LP   LS   PC*/


/* Define this macro to change register usage conditional on target flags. */
#define CONDITIONAL_REGISTER_USAGE 

/* List the order in which to allocate registers.  Each register must be
   listed once, even those in FIXED_REGISTERS.  */
#define REG_ALLOC_ORDER	\
   {HARD_R1_REGNUM, HARD_R2_REGNUM, HARD_R3_REGNUM, HARD_R4_REGNUM,\
    HARD_R5_REGNUM, HARD_R6_REGNUM, HARD_R7_REGNUM, HARD_R8_REGNUM,\
    HARD_SC_REGNUM, HARD_CB_REGNUM, HARD_R9_REGNUM, HARD_LW_REGNUM,\
    HARD_LP_REGNUM, HARD_LS_REGNUM, HARD_LR_REGNUM, HARD_SP_REGNUM,\
    1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 32, 33}

#define IRA_HARD_REGNO_ADD_COST_MULTIPLIER(REGNO) \
   (REGNO == HARD_R9_REGNUM || \
    REGNO == HARD_LR_REGNUM || \
    REGNO == HARD_LW_REGNUM || \
    REGNO == HARD_LP_REGNUM || \
    REGNO == HARD_LS_REGNUM ? 4.0 : 0.0)
     
/* A C expression for the number of consecutive hard registers,
   starting at register number REGNO, required to hold a value of
   mode MODE.  */
#define HARD_REGNO_NREGS(REGNO, MODE) \
   ((GET_MODE_SIZE (MODE) + HARD_REG_SIZE - 1) / HARD_REG_SIZE)

/* Value is 1 if hard register REGNO (or starting with REGNO) can hold a value of machine-mode MODE */
#define HARD_REGNO_MODE_OK(REGNO, MODE) \
   ( (GET_MODE_SIZE (MODE) <= HARD_REG_SIZE)   && ((REGNO & 1) == 0) ? 1:\
   ( (GET_MODE_SIZE (MODE) <= HARD_REG_SIZE*2) && ((REGNO & 1) == 0) && (REGNO <= 30) ? 1:\
   ( (GET_MODE_SIZE (MODE) <= HARD_REG_SIZE*4) && ((REGNO & 1) == 0) && (REGNO <= 28) ? 1: 0)))
  
/* A C expression that is nonzero if hard register number REGNO2 can be
   considered for use as a rename register for REGNO1 */
#define HARD_REGNO_RENAME_OK(REGNO1,REGNO2) \
   ((REGNO1 & 1) == 0 && (REGNO2 & 1) == 0) 

/* Value is 1 if it is a good idea to tie two pseudo registers when one has
   mode MODE1 and one has mode MODE2.  If HARD_REGNO_MODE_OK could produce
   different values for MODE1 and MODE2, for any hard reg, then this must be
   0 for correct output. */
#define MODES_TIEABLE_P(MODE1, MODE2) 0

/* Define the classes of registers for register constraints in the
   machine description.  Also define ranges of constants.

   One of the classes must always be named ALL_REGS and include all hard regs.
   If there is more than one class, another class must be named NO_REGS
   and contain no registers.

   The classes must be numbered in nondecreasing order; that is,
   a larger-numbered class must never be contained completely
   in a smaller-numbered class.

   For any two classes, it is very desirable that there be another
   class that represents their union.  */
enum reg_class
{
  NO_REGS,
  SHIFT_REGS,  /* Register used for variable shift (SC) */
  CRU_REGS,    /* Register used for CRU access (CB) */
  ALL_REGS,
  LIM_REG_CLASSES
};

/* The name GENERAL_REGS must be the name of a class (or an alias for
   another name such as ALL_REGS).  This is the class of registers
   that is allowed by "g" or "r" in a register constraint.
   Also, registers outside this class are allocated only when
   instructions express preferences for them. */
#define GENERAL_REGS	ALL_REGS

/* The number of distict register classes */
#define N_REG_CLASSES	(int) LIM_REG_CLASSES

/* Give names of register classes as strings for dump file.  */
#define REG_CLASS_NAMES \
{ "NO_REGS",\
  "SHIFT_REGS",\
  "CRU_REGS",\
  "ALL_REGS" }

/* An initializer containing the contents of the register classes,
   as integers which are bit masks.  The Nth integer specifies the
   contents of class N.  The way the integer MASK is interpreted is
   that register R is in the class if `MASK & (1 << R)' is 1.  */

/*--------------------------------------------------------------
   SC  0x00000001
   SC. 0x00000002
   R1  0x00000004
   R1. 0x00000008
   R2  0x00000010
   R2. 0x00000020
   R3  0x00000040
   R3. 0x00000080
   R4  0x00000100
   R4. 0x00000200
   R5  0x00000400
   R5. 0x00000800
   R6  0x00001000
   R6. 0x00002000
   R7  0x00004000
   R7. 0x00008000
   R8  0x00010000
   R8. 0x00020000
   R9  0x00040000
   R9. 0x00080000
   SP  0x00100000
   SP. 0x00200000
   LR  0x00400000
   LR. 0x00800000
   CB  0x01000000
   CB. 0x02000000
   LW  0x04000000
   LW. 0x08000000
   LP  0x10000000
   LP. 0x20000000
   LS  0x40000000
   LS. 0x80000000
--------------------------------------------------------------*/

#define REG_CLASS_CONTENTS \
/* NO_REGS    */        {{ 0x00000000, 0 },\
/* SHIFT_REGS */         { 0x00000003, 0 }, /* SC */ \
/* CRU_REGS   */         { 0x03000000, 0 }, /* CB */ \
/* ALL_REGS   */         { 0xFFFFFFFF, 3 }}

/* Set up a C expression whose value is a register class containing hard
   register REGNO */
#define REGNO_REG_CLASS(REGNO) \
   (REGNO == HARD_SC_REGNUM || REGNO == HARD_SC_REGNUM + 1 ? SHIFT_REGS : \
   (REGNO == HARD_SC_REGNUM || REGNO == HARD_SC_REGNUM + 1 ? CRU_REGS   : \
                                                             ALL_REGS))

/* The name of the class to which a valid base register must belong.
   A base register is one used in an address which is the register
   value plus a displacement. */
#define BASE_REG_CLASS ALL_REGS

/* Get register class from a letter in the machine description. */
#define REG_CLASS_FROM_LETTER(C) \
   ((C) == 'S' ? SHIFT_REGS : \
    (C) == 'C' ? CRU_REGS   : \
    NO_REGS)

/* A C expression that places additional restrictions of the register
   class to use when it is necessary to copy value X into a register
   in class CLASS. Some values may require the use of a more restrictive
   class.*/
#define PREFERRED_RELOAD_CLASS(X,CLASS)	CLASS

/* Return the maximum number of consecutive registers needed to represent
   mode MODE in a register of class CLASS.  */
#define CLASS_MAX_NREGS(CLASS, MODE) \
   ((GET_MODE_SIZE (MODE) + UNITS_PER_WORD - 1) / UNITS_PER_WORD)

/* The letters I, J, K, L and M in a register constraint string
   can be used to stand for particular ranges of immediate operands.
   This macro defines what the ranges are.
   C is the letter, and VALUE is a constant value.
   Return 1 if VALUE is in the range specified by C.

   'I' is for 32-bit value xxxx0000
   'J' is for 32-bit value 0000xxxx
   'K' is for 32-bit value xxxxxxxx
   'L' is for 1
   'M' is for -1
   'N' is for 0
   'O' is for 2
   'P' is for -2
*/

#define CONST_OK_FOR_LETTER_P(VALUE, C) \
  ((C) == 'I' ? ((VALUE) & 0xffff0000) == 0: \
   (C) == 'J' ? ((VALUE) & 0x0000ffff) == 0: \
   (C) == 'K' ? (((VALUE) & 0xffff0000) != 0 && \
		 ((VALUE) & 0x0000ffff) != 0): \
   (C) == 'L' ? ((VALUE) == 1): \
   (C) == 'M' ? ((VALUE) == -1): \
   (C) == 'N' ? ((VALUE) == 0): \
   (C) == 'O' ? ((VALUE) == 2): \
   (C) == 'P' ? ((VALUE) == -2): \
   0)

/* Similar, but for floating constants, and defining letters G and H.

   `G' is for 0.0.  */
#define CONST_DOUBLE_OK_FOR_LETTER_P(VALUE, C) \
  ((C) == 'G' ? (GET_MODE_CLASS (GET_MODE (VALUE)) == MODE_FLOAT \
		 && VALUE == CONST0_RTX (GET_MODE (VALUE))) : 0) 

/* Letters in the range `Q' through `U' may be defined in a
   machine-dependent fashion to stand for arbitrary operand types. 
   The machine description macro `EXTRA_CONSTRAINT' is passed the
   operand as its first argument and the constraint letter as its
   second operand.

   `Q'	is for memory references that require an extra word after the opcode.
   `R'	is for memory references which are encoded within the opcode.  */
#define EXTRA_CONSTRAINT(OP,CODE)					\
  ((GET_CODE (OP) != MEM) ? 0						\
   : !legitimate_address_p (GET_MODE (OP), XEXP (OP, 0)) ? 0		\
   : ((CODE) == 'Q')	  ? !simple_memory_operand (OP, GET_MODE (OP))	\
   : ((CODE) == 'R')	  ? simple_memory_operand (OP, GET_MODE (OP))	\
   : 0)

/* Stack layout; function entry, exit and calling.  */

/* Define this if pushing a word on the stack
   makes the stack pointer a smaller address.  */
#define STACK_GROWS_DOWNWARD

/* Define this to nonzero if the nominal address of the stack frame
   is at the high-address end of the local variables;
   that is, each additional local variable allocated
   goes at a more negative offset in the frame.

   Define to 0 for 68HC11, the frame pointer is the bottom
   of local variables.  */
#define FRAME_GROWS_DOWNWARD 0

/* Offset within stack frame to start allocating local variables at.
   If FRAME_GROWS_DOWNWARD, this is the offset to the END of the
   first local allocated.  Otherwise, it is the offset to the BEGINNING
   of the first local allocated.  */
#define STARTING_FRAME_OFFSET		0

#define INITIAL_FRAME_POINTER_OFFSET(DEPTH_VAR) \
{\
  (DEPTH_VAR)=0;\
}


/* Offset of first parameter from the argument pointer register value.  */
#define FIRST_PARM_OFFSET(FNDECL)	0

/* After the prologue, RA is at 0(AP) in the current frame.  */
#define RETURN_ADDR_RTX(COUNT, FRAME)					\
  ((COUNT) == 0								\
   ? gen_rtx_MEM (Pmode, arg_pointer_rtx)                               \
   : 0)

/* Before the prologue, the top of the frame is at 2(sp).  */
#define INCOMING_FRAME_SP_OFFSET        0

/* Register to use for pushing function arguments.  */
#define STACK_POINTER_REGNUM		HARD_SP_REGNUM

/* Base register for access to local variables of the function.  */
#define FRAME_POINTER_REGNUM		HARD_R8_REGNUM

/* Base register for access to arguments of the function.  */
#define ARG_POINTER_REGNUM		HARD_R7_REGNUM

/* Register in which static-chain is passed to a function.  */
#define STATIC_CHAIN_REGNUM	        HARD_R8_REGNUM

/* Definitions for register eliminations.

   This is an array of structures.  Each structure initializes one pair
   of eliminable registers.  The "from" register number is given first,
   followed by "to".  Eliminations of the same "from" register are listed
   in order of preference.

   We have two registers that are eliminated on the 6811. The pseudo arg
   pointer and pseudo frame pointer registers can always be eliminated;
   they are replaced with either the stack or the real frame pointer.  */
#define ELIMINABLE_REGS \
  {{ARG_POINTER_REGNUM,   STACK_POINTER_REGNUM},\
   {ARG_POINTER_REGNUM,   FRAME_POINTER_REGNUM},\
   {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}}

/* Value should be nonzero if functions must have frame pointers.
   Zero means the frame pointer need not be set up (and parms may be
   accessed via the stack pointer) in functions that seem suitable.
   This is computed in `reload', in reload1.c.  */
#define FRAME_POINTER_REQUIRED	0

#define CAN_DEBUG_WITHOUT_FP 1

/* Given FROM and TO register numbers, say whether this elimination is allowed.
   Frame pointer elimination is automatically handled.

   All other eliminations are valid.  */
#define CAN_ELIMINATE(FROM, TO)					\
  1

/* Define the offset between two registers, one to be eliminated, and the other
   its replacement, at the start of a routine.  */
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET)			\
    { OFFSET = tms9900_initial_elimination_offset (FROM, TO); }

/* Passing Function Arguments on the Stack.  */

/* A C expression.  If nonzero, push insns will be used to pass
   outgoing arguments.  If the target machine does not have a push
   instruction, set it to zero.  That directs GCC to use an alternate
   strategy: to allocate the entire argument block and then store the
   arguments into it.  When `PUSH_ARGS' is nonzero, `PUSH_ROUNDING'
   must be defined too. */
#define PUSH_ARGS 0

/* Value is 1 if returning from a function call automatically pops the
   arguments described by the number-of-args field in the call. FUNTYPE is
   the data type of the function (as a tree), or for a library call it is
   an identifier node for the subroutine name.
  
   The standard MC6811 call, with arg count word, includes popping the
   args as part of the call template.  */
#define RETURN_POPS_ARGS(FUNDECL,FUNTYPE,SIZE)	0

/* Passing Arguments in Registers.  */


/* The number of argument registers we can use */
#define TMS9900_ARG_REGS 12

/* Define a data type for recording info about an argument list
   during the scan of that argument list.  This data type should
   hold all necessary information about the function itself
   and about the args processed so far, enough to enable macros
   such as FUNCTION_ARG to determine where the next arg should go.  */

typedef struct tms9900_args
{
  int nregs;        /* Number of registers used so far */
  int named_count;  /* Number of named arguments (for varargs) */  
} CUMULATIVE_ARGS;

/* If defined, a C expression which determines whether, and in which direction,
   to pad out an argument with extra space.  The value should be of type
   `enum direction': either `upward' to pad above the argument,
   `downward' to pad below, or `none' to inhibit padding.

   Structures are stored left shifted in their argument slot.  */
#define FUNCTION_ARG_PADDING(MODE, TYPE) \
  tms9900_function_arg_padding ((MODE), (TYPE))

#undef PAD_VARARGS_DOWN
#define PAD_VARARGS_DOWN \
  (tms9900_function_arg_padding (TYPE_MODE (type), type) == downward)

/* Initialize a variable CUM of type CUMULATIVE_ARGS for a call to a
   function whose data type is FNTYPE. For a library call, FNTYPE is 0.  */
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, INDIRECT, N_NAMED_ARGS) \
   (tms9900_init_cumulative_args (&CUM, FNTYPE, LIBNAME))

/* Update the data in CUM to advance over an argument of mode MODE and data
   type TYPE. (TYPE is null for libcalls where that information may not be
   available.) */
#define FUNCTION_ARG_ADVANCE(CUM, MODE, TYPE, NAMED) \
    (tms9900_function_arg_advance (&CUM, MODE, TYPE, NAMED))

/* Define where to put the arguments to a function.
   Value is zero to push the argument on the stack,
   or a hard register in which to store the argument.

   MODE is the argument's machine mode.
   TYPE is the data type of the argument (as a tree).
    This is null for libcalls where that information may
    not be available.
   CUM is a variable of type CUMULATIVE_ARGS which gives info about
    the preceding args and about the function being called.
   NAMED is nonzero if this argument is a named parameter
    (otherwise it is an extra parameter matching an ellipsis).  */
#define FUNCTION_ARG(CUM, MODE, TYPE, NAMED) \
  (tms9900_function_arg (&CUM, MODE, TYPE, NAMED))

/* Define the profitability of saving registers around calls.

   Disable this because the saving instructions generated by
   caller-save need a reload and the way it is implemented,
   it forbids all spill registers at that point.  Enabling
   caller saving results in spill failure.  */
#define CALLER_SAVE_PROFITABLE(REFS,CALLS) 0

/* 1 if N is a possible register number for function argument passing. */
#define FUNCTION_ARG_REGNO_P(N)	\
     (((N) >= HARD_R1_REGNUM) && ((N) <= HARD_R6_REGNUM))

/*EMW - 8- and 16-bit values are returned in R1, 32-bit values are
   passed in R1+R0, The high word is in R1. For GCC, always use R1 */
#define FUNCTION_VALUE tms9900_function_value
#define FUNCTION_OUTGOING_VALUE tms9900_function_value
/*#define TARGET_FUNCTION_VALUE tms9900_function_value */
/*
#define TARGET_FUNCTION_VALUE(RET_TYPE, FN_DECL_OR_TYPE, OUTGOING) \
     gen_rtx_REG (TYPE_MODE (RET_TYPE), HARD_R1_REGNUM)*/


/* 8- and 16-bit values are returned in R1, 32-bit values are
   passed in R1+R2, The high word is in R1. For GCC, always use R1 */
#define LIBCALL_VALUE(MODE)						\
     gen_rtx_REG (MODE, HARD_R1_REGNUM)

/* 1 if N is a possible register number for a function value.  */
#define FUNCTION_VALUE_REGNO_P(N) \
     ((N) == HARD_R1_REGNUM)

/* EXIT_IGNORE_STACK should be nonzero if, when returning from a function,
   the stack pointer does not matter.  The value is tested only in functions
   that have frame pointers. No definition is equivalent to always zero.  */
#define EXIT_IGNORE_STACK	0

/* Generating Code for Profiling.  */

/* Output assembler code to FILE to increment profiler label # LABELNO
   for profiling a function entry.  */
#define FUNCTION_PROFILER(FILE, LABELNO)		\
    fprintf (FILE, "\tldy\t.LP%d\n\tjsr mcount\n", (LABELNO))

/* lets see whether this works as trampoline:
LI	Rn, @STATIC	0x0200	0x0000 <- STATIC; Y = STATIC_CHAIN_REGNUM
B	FUNCTION	0x0820  0x0000 <- FUNCTION
*/
#define TRAMPOLINE_TEMPLATE(FILE)	\
{					\
  assemble_aligned_integer (2, GEN_INT (0x0200+STATIC_CHAIN_REGNUM));	\
  assemble_aligned_integer (2, const0_rtx);				\
  assemble_aligned_integer (2, GEN_INT(0x0820));			\
  assemble_aligned_integer (2, const0_rtx);				\
}

#define TRAMPOLINE_SIZE 8
#define TRAMPOLINE_ALIGNMENT 16

/* Emit RTL insns to initialize the variable parts of a trampoline.
   FNADDR is an RTX for the address of the function's pure code.
   CXT is an RTX for the static chain value for the function.  */

#define INITIALIZE_TRAMPOLINE(TRAMP,FNADDR,CXT)	\
{					\
  emit_move_insn (gen_rtx_MEM (HImode, plus_constant (TRAMP, 2)), CXT); \
  emit_move_insn (gen_rtx_MEM (HImode, plus_constant (TRAMP, 6)), FNADDR); \
}

/* The TMS9900 can only do post increment */
#define HAVE_POST_INCREMENT  (1)
#define HAVE_PRE_INCREMENT   (0)
#define HAVE_POST_DECREMENT  (0)
#define HAVE_PRE_DECREMENT   (0)
#define HAVE_POST_MODIFY_REG (1)

/* The class value for base registers. */
#define BASE_REG_CLASS	ALL_REGS

/* The class value for index registers. */
#define INDEX_REG_CLASS	NO_REGS

/* A C expression which is nonzero if register number NUM is suitable
   for use as a base register in operand addresses.  It may be either
   a suitable hard register or a pseudo register that has been
   allocated such a hard register. 
   Any hard register except R0 is a valid base */
#define REGNO_OK_FOR_BASE_P(NUM) \
   ((NUM) < FIRST_PSEUDO_REGISTER && (NUM) > 0)

/* A C expression which is nonzero if register number NUM is suitable
   for use as an index register in operand addresses.  It may be
   either a suitable hard register or a pseudo register that has been
   allocated such a hard register. The difference between an index
   register and a base register is that the index register may be scaled. */
#define REGNO_OK_FOR_INDEX_P(NUM) 0

/* 1 if X is an rtx for a constant that is a valid address.  */
#define CONSTANT_ADDRESS_P(X)	(CONSTANT_P (X))

/* Maximum number of registers that can appear in a valid memory address */
#define MAX_REGS_PER_ADDRESS	1

/* GO_IF_LEGITIMATE_ADDRESS recognizes an RTL expression that is a
   valid memory address for an instruction. The MODE argument is the
   machine mode for the MEM expression that wants to use this address.  */

/*--------------------------------------------------------------
   Valid addresses are either direct or indirect (MEM) versions
   of the following forms:
	constant		N
	register		X
	indexed			N,X
--------------------------------------------------------------*/

/* GO_IF_LEGITIMATE_ADDRESS recognizes an RTL expression
   that is a valid memory address for an instruction.
   The MODE argument is the machine mode for the MEM expression
   that wants to use this address. */
#define GO_IF_LEGITIMATE_ADDRESS(mode, operand, ADDR) \
{						      \
    rtx xfoob;								\
									\
    /* accept *R0 */							\
    if (GET_CODE (operand) == REG					\
	&& REG_OK_FOR_BASE_P(operand))					\
      goto ADDR;							\
									\
    /* accept *R0+ */							\
    if (GET_CODE (operand) == POST_INC					\
	&& GET_CODE (XEXP (operand, 0)) == REG				\
	&& REG_OK_FOR_BASE_P (XEXP (operand, 0)))			\
      goto ADDR;							\
									\
    /* accept @xxxx */							\
    if (CONSTANT_ADDRESS_P (operand))					\
      goto ADDR;							\
    									\
    /* accept @xxxx(R0)*/						\
    if (GET_CODE (operand) == PLUS       				\
	&& GET_CODE (XEXP (operand, 0)) == REG				\
	&& REG_OK_FOR_BASE_P (XEXP (operand, 0))			\
	&& CONSTANT_ADDRESS_P (XEXP (operand, 1)))			\
      goto ADDR;							\
    									\
    /* handle another level of indirection ! */				\
    if (GET_CODE(operand) != MEM)					\
      goto fail;							\
									\
    xfoob = XEXP (operand, 0);						\
									\
    /* (MEM:xx (MEM:xx ())) is not valid for SI, DI and currently */    \
    /* also forbidden for float, because we have to handle this */  	\
    /* in output_move_double and/or output_move_quad() - we could */   	\
    /* do it, but currently it's not worth it!!! */			\
    /* now that DFmode cannot go into CPU register file, */		\
    /* maybe I should allow float ... */				\
    /*  but then I have to handle memory-to-memory moves in movdf ?? */ \
									\
    if (GET_MODE_BITSIZE(mode) > 16)					\
      goto fail;							\
									\
    /* accept @address */						\
    if (CONSTANT_ADDRESS_P (xfoob))					\
      goto ADDR;							\
    									\
    /* accept @X(R0) */							\
    if (GET_CODE (xfoob) == PLUS       					\
	&& GET_CODE (XEXP (xfoob, 0)) == REG				\
	&& REG_OK_FOR_BASE_P (XEXP (xfoob, 0))				\
	&& CONSTANT_ADDRESS_P (XEXP (xfoob, 1)))			\
      goto ADDR;							\
									\
  /* anything else is invalid */					\
  fail: ;								\
}

/* The macros REG_OK_FOR..._P assume that the arg is a REG rtx and check its
   validity for a certain class.  We have two alternate definitions for each
   of them.  The usual definition accepts all pseudo regs; the other rejects
   them unless they have been allocated suitable hard regs.  The symbol
   REG_OK_STRICT causes the latter definition to be used.
  
   Most source files want to accept pseudo regs in the hope that they will
   get allocated to the class that the insn wants them to be in. Source files
   for reload pass need to be strict. After reload, it makes no difference,
   since pseudo regs have been eliminated by then.  */

/* Nonzero if X is a hard reg that can be used as a base reg.  */
#define REG_OK_FOR_BASE_P(X) (1)

/* Nonzero if X is a hard reg that can be used as an index.  */
#define REG_OK_FOR_INDEX_P(X) (0)

/* Try machine-dependent ways of modifying an illegitimate address
   to be legitimate.  If we find one, return the new, valid address.
   This macro is used in only one place: `memory_address' in explow.c.
  
   OLDX is the address as it was before break_out_memory_refs was called.
   In some cases it is useful to look at this to decide what needs to be done.
  
   MODE and WIN are passed so that this macro can use
   GO_IF_LEGITIMATE_ADDRESS.
  
   It is always safe for this macro to do nothing.
   It exists to recognize opportunities to optimize the output.  */
/* EMW - OK then, do nothing... */
#define LEGITIMIZE_ADDRESS(X,OLDX,MODE,WIN)

/* Go to LABEL if ADDR (a legitimate address expression)
   has an effect that depends on the machine mode it is used for.  */
#define GO_IF_MODE_DEPENDENT_ADDRESS(ADDR,LABEL)

/* Nonzero if the constant value X is a legitimate general operand.
   It is given that X satisfies CONSTANT_P or is a CONST_DOUBLE.  */
#define LEGITIMATE_CONSTANT_P(X)	1

/* Tell final.c how to eliminate redundant test instructions.  */
#define NOTICE_UPDATE_CC(EXP, INSN) \
{ if (GET_CODE (EXP) == SET)					\
    {								\
      notice_update_cc_on_set(EXP, INSN);			\
    }								\
  else if (GET_CODE (EXP) == PARALLEL				\
	   && GET_CODE (XVECEXP (EXP, 0, 0)) == SET)		\
    {								\
      notice_update_cc_on_set(XVECEXP (EXP, 0, 0), INSN);	\
    }								\
  else if (GET_CODE (EXP) == CALL)				\
    { /* all bets are off */ CC_STATUS_INIT; }			\
  if (cc_status.value1 && GET_CODE (cc_status.value1) == REG	\
      && cc_status.value2					\
      && reg_overlap_mentioned_p (cc_status.value1, cc_status.value2)) \
    { 								\
      printf ("here!\n");					\
      cc_status.value2 = 0;					\
    }								\
}

/* A C expression for the cost of moving data of mode MODE between a
   register of class CLASS and memory; IN is zero if the value is to
   be written to memory, nonzero if it is to be read in.  This cost
   is relative to those in `REGISTER_MOVE_COST'.  If moving between
   registers and memory is more expensive than between two registers,
   you should define this macro to express the relative cost

   For the TMS9900, memory access is four times slower than registers */
#define MEMORY_MOVE_COST(MODE,CLASS,IN)	8

/* A C expression for the cost of a branch instruction.  A value of 1
   is the default; other values are interpreted relative to that.

   Pretend branches are cheap because GCC generates sub-optimal code
   for the default value.  */
#define BRANCH_COST(speed_p, predictable_p) 0

/* Nonzero if access to memory by bytes is slow and undesirable.  */
#define SLOW_BYTE_ACCESS	1

/* Defining the Output Assembler Language.  */

/* A default list of other sections which we might be "in" at any given
   time.  For targets that use additional sections (e.g. .tdesc) you
   should override this definition in the target-specific file which
   includes this file.  */

/* Output before read-only data.  */
#define TEXT_SECTION_ASM_OP	("\tpseg")

/* Output before writable data.  */
#define DATA_SECTION_ASM_OP	("\tdseg")

/* Output before uninitialized data.  */
#define BSS_SECTION_ASM_OP 	("\tcseg")

/* Define the pseudo-ops used to switch to the .ctors and .dtors sections.

   Same as config/elfos.h but don't mark these section SHF_WRITE since
   there is no shared library problem.  */
/*EMW - Neglect C++ for now...
#undef CTORS_SECTION_ASM_OP
#define CTORS_SECTION_ASM_OP	"\t.section\t.ctors,\"a\""

#undef DTORS_SECTION_ASM_OP
#define DTORS_SECTION_ASM_OP	"\t.section\t.dtors,\"a\""

#define TARGET_ASM_CONSTRUCTOR  m68hc11_asm_out_constructor
#define TARGET_ASM_DESTRUCTOR   m68hc11_asm_out_destructor
EMW*/

/* Comment character */
#define ASM_COMMENT_START	"*"

/* Output to assembler file text saying following lines
   may contain character constants, extra white space, comments, etc.  */
#define ASM_APP_ON 		"* Begin inline assembler code\n#APP\n"

/* Output to assembler file text saying following lines
   no longer contain unusual constructs.  */
#define ASM_APP_OFF 		"* End of inline assembler code\n#NO_APP\n"

/* Write the extra assembler code needed to declare a function properly.
   Some svr4 assemblers need to also have something extra said about the
   function's return value.  We allow for that here.

   For 68HC12 we mark functions that return with 'rtc'.  The linker
   will ensure that a 'call' is really made (instead of 'jsr').
   The debugger needs this information to correctly compute the stack frame.

   For 68HC11/68HC12 we also mark interrupt handlers for gdb to
   compute the correct stack frame.  */
/*EMW
#undef ASM_DECLARE_FUNCTION_NAME
#define ASM_DECLARE_FUNCTION_NAME(FILE, NAME, DECL)	\
  do							\
    {							\
      fprintf (FILE, "%s", TYPE_ASM_OP);		\
      assemble_name (FILE, NAME);			\
      putc (',', FILE);					\
      fprintf (FILE, TYPE_OPERAND_FMT, "function");	\
      putc ('\n', FILE);				\
      							\
      if (current_function_far)                         \
        {						\
          fprintf (FILE, "\t.far\t");			\
	  assemble_name (FILE, NAME);			\
	  putc ('\n', FILE);				\
	}						\
      else if (current_function_interrupt		\
	       || current_function_trap)		\
        {						\
	  fprintf (FILE, "\t.interrupt\t");		\
	  assemble_name (FILE, NAME);			\
	  putc ('\n', FILE);				\
	}						\
      ASM_DECLARE_RESULT (FILE, DECL_RESULT (DECL));	\
      ASM_OUTPUT_LABEL(FILE, NAME);			\
    }							\
  while (0)
EMW*/

/* Output #ident as a .ident.  */

/* output external reference */
#undef ASM_OUTPUT_EXTERNAL
#define ASM_OUTPUT_EXTERNAL(FILE,DECL,NAME) \
  {fputs ("def\t", FILE); \
  assemble_name (FILE, NAME); \
  fputs ("\n", FILE);}

#define ASM_OUTPUT_LABEL(FILE,NAME) \
  {							\
    assemble_name ((FILE), (NAME));			\
    fputc ('\n', (FILE));				\
  }

#define ASM_OUTPUT_INTERNAL_LABEL(FILE,NAME) \
  {							\
    assemble_name ((FILE), (NAME));			\
    fputc ('\n', (FILE));				\
  }

/* How to refer to registers in assembler output.  This sequence is indexed
   by compiler's hard-register-number (see above).  

   The "FAKE" names are for registers which do not really exist, but are
   useful fictions for GCC. They should never appear in compiled output.
*/
#define REGISTER_NAMES \
{ "r0",  "FAKE_R0",  "r1",  "FAKE_R1",  "r2",  "FAKE_R2",  "r3",  "FAKE_R3",\
  "r4",  "FAKE_R4",  "r5",  "FAKE_R5",  "r6",  "FAKE_R6",  "r7",  "FAKE_R7",\
  "r8",  "FAKE_R8",  "r9",  "FAKE_R9",  "r10", "FAKE_R10", "r11", "FAKE_R11",\
  "r12", "FAKE_R12", "r13", "FAKE_R13", "r14", "FAKE_R14", "r15", "FAKE_R15",\
  \
  "SOFT_FP", "FAKE_SOFT_FP", "SOFT_AP", "FAKE_SOFT_AP"}

/* Print operand X (an rtx) in assembler syntax to file FILE.
   CODE is a letter or dot (`z' in `%z0') or 0 if no letter was specified.
   For `%' followed by punctuation, CODE is the punctuation and X is null. */
#define PRINT_OPERAND(FILE, X, CODE)  				\
{ if (CODE == '#') fprintf (FILE, "#");				\
  else if (GET_CODE (X) == REG)					\
    fprintf (FILE, "%s", reg_names[REGNO (X)]);			\
  else if (GET_CODE (X) == MEM)					\
    output_address (XEXP (X, 0));				\
  else output_addr_const (FILE, X);}
  

/* Print a memory operand whose address is ADDR, on file FILE.  */
#define PRINT_OPERAND_ADDRESS(FILE, ADDR) \
  print_operand_address (FILE, ADDR)

/* This is how to output an insn to push/pop a register on the stack.
   It need not be very fast code.  

   Don't define because we don't know how to handle that with
   the STATIC_CHAIN_REGNUM (soft register).  Saving the static
   chain must be made inside FUNCTION_PROFILER.  */

#undef ASM_OUTPUT_REG_PUSH
#undef ASM_OUTPUT_REG_POP

/* This is how to output an element of a case-vector that is relative.  */
#define ASM_OUTPUT_ADDR_DIFF_ELT(FILE, BODY, VALUE, REL) \
  fprintf (FILE, "\t%s\tL%d-L%d\n", integer_asm_op (2, TRUE), VALUE, REL)

/* This is how to output an element of a case-vector that is absolute.  */
#define ASM_OUTPUT_ADDR_VEC_ELT(FILE, VALUE) \
  fprintf (FILE, "\t%s\t.L%d\n", integer_asm_op (2, TRUE), VALUE)

/* This is how to output an assembler line that says to advance the
   location counter to a multiple of 2**LOG bytes.  */
#undef ALIGN_ASM_OP
#define ALIGN_ASM_OP "\teven\t"
#define ASM_OUTPUT_ALIGN(FILE,LOG)			\
  do {                                                  \
      if ((LOG) > 1)                                    \
          fprintf ((FILE), "%s\n", ALIGN_ASM_OP); \
  } while (0)

/* Assembler Commands for Exception Regions.  */

/* Default values provided by GCC should be ok. Assuming that DWARF-2
   frame unwind info is ok for this platform.  */
/*EMW
#undef PREFERRED_DEBUGGING_TYPE
#define PREFERRED_DEBUGGING_TYPE DWARF2_DEBUG
EMW*/

/* For the support of memory banks we need addresses that indicate
   the page number.  */
#define DWARF2_ADDR_SIZE 4

/* SCz 2003-07-08: Don't use as dwarf2 .file/.loc directives because
   the linker is doing relaxation and it does not adjust the debug_line
   sections when it shrinks the code.  This results in invalid addresses
   when debugging.  This does not bless too much the HC11/HC12 as most
   applications are embedded and small, hence a reasonable debug info.
   This problem is known for binutils 2.13, 2.14 and mainline.  */
#undef HAVE_AS_DWARF2_DEBUG_LINE

/* The prefix for local labels.  You should be able to define this as
   an empty string, or any arbitrary string (such as ".", ".L%", etc)
   without having to make any other changes to account for the specific
   definition.  Note it is a string literal, not interpreted by printf
   and friends.  */
/*#define LOCAL_LABEL_PREFIX "."*/

/* The prefix for immediate operands.  */
/*#define IMMEDIATE_PREFIX "#"*/
#define GLOBAL_ASM_OP   "\n\tdef\t"


/* Miscellaneous Parameters.  */

/* Specify the machine mode that this machine uses
   for the index in the tablejump instruction.  */
#define CASE_VECTOR_MODE	Pmode

/* This flag, if defined, says the same insns that convert to a signed fixnum
   also convert validly to an unsigned one.  */
#define FIXUNS_TRUNC_LIKE_FIX_TRUNC

/* Max number of bytes we can move from memory to memory in one
   reasonably fast instruction.  */
#define MOVE_MAX 		2

/* MOVE_RATIO is the number of move instructions that is better than a
   block move.  Make this small on 6811, since the code size grows very
   large with each move.  */
#define MOVE_RATIO(speed)	3

/* Define if shifts truncate the shift count which implies one can omit
   a sign-extension or zero-extension of a shift count.  */
#define SHIFT_COUNT_TRUNCATED	1

/* Value is 1 if truncating an integer of INPREC bits to OUTPREC bits
   is done just by pretending it is already truncated.  */
#define TRULY_NOOP_TRUNCATION(OUTPREC, INPREC)	0

/* Specify the machine mode that pointers have. After generation of rtl, the
   compiler makes no further distinction between pointers and any other
   objects of this machine mode.  */
#define Pmode			HImode

/* A function address in a call instruction is a byte address (for indexing
   purposes) so give the MEM rtx a byte's mode.  */
#define FUNCTION_MODE		HImode

/* A C statement (sans semicolon) to output a reference to
   `SYMBOL_REF' SYM.  If not defined, `assemble_name' will be used to
   output the name of the symbol.  This macro may be used to modify
   the way a symbol is referenced depending on information encoded by
   `TARGET_ENCODE_SECTION_INFO'. */
#define ASM_GENERATE_INTERNAL_LABEL(STRING, PREFIX, NUM) \
  sprintf (STRING, "*%s%ld", PREFIX, (long)(NUM))

/* A C statement to output to the stdio stream STREAM an assembler
   instruction to advance the location counter by NBYTES bytes.
   Those bytes should be zero when loaded.  NBYTES will be a C
   expression of type `unsigned HOST_WIDE_INT'. */
#define ASM_OUTPUT_SKIP(STREAM, NBYTES) \
   fprintf(STREAM, "bss %lu\n", NBYTES);

/* A C statement (sans semicolon) to output to the stdio stream
   STREAM the assembler definition of a local-common-label named NAME
   whose size is SIZE bytes.  The variable ROUNDED is the size
   rounded up to whatever alignment the caller wants. */
#define ASM_OUTPUT_LOCAL(STREAM, NAME, SIZE, ROUNDED) \
    ( fputs (".lcomm ", (STREAM)), \
    assemble_name ((STREAM), (NAME)), \
    fprintf ((STREAM), ",%u\n", (int)(ROUNDED)))

/* A C statement (sans semicolon) to output to the stdio stream
   STREAM the assembler definition of a common-label named NAME whose
   size is SIZE bytes.  The variable ROUNDED is the size rounded up
   to whatever alignment the caller wants. */
#define ASM_OUTPUT_COMMON(STREAM, NAME, SIZE, ROUNDED) \
    ( fputs (".comm ", (STREAM)), \
    assemble_name ((STREAM), (NAME)), \
    fprintf ((STREAM), ",%u\n", (int)(ROUNDED)))

/* A C statement to output to the stdio stream STREAM an assembler
   instruction to assemble a string constant containing the LEN bytes
   at PTR.  PTR will be a C expression of type `char *' and LEN a C
   expression of type `int'. */
#define ASM_OUTPUT_ASCII(STREAM, PTR, LEN) \
   tms9900_output_ascii(STREAM, PTR, LEN)

/*
EMW - Suppress link to "__main", This is a horrible thing to do
*/
#define INIT_SECTION_ASM_OP

/*
extern int debug_m6811;
extern int z_replacement_completed;
extern int current_function_interrupt;
extern int current_function_trap;
extern int current_function_far;

extern GTY(()) rtx m68hc11_compare_op0;
extern GTY(()) rtx m68hc11_compare_op1;
extern GTY(()) rtx m68hc11_soft_tmp_reg;
extern GTY(()) rtx ix_reg;
extern GTY(()) rtx iy_reg;
extern GTY(()) rtx d_reg;
*/

