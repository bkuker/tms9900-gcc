#include "insn-modes.h"



#include <stdio.h>
#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "rtl.h"
#include "tree.h"
#include "tm_p.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "real.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "recog.h"
#include "expr.h"
#include "libfuncs.h"
#include "toplev.h"
#include "basic-block.h"
#include "function.h"
#include "ggc.h"
#include "reload.h"
#include "target.h"
#include "target-def.h"
#include "df.h"


struct gcc_target targetm = TARGET_INITIALIZER;

/* Non-volatile registers to be saved across function calls */
static int nvolregs[]={
   HARD_R9_REGNUM,
   HARD_LR_REGNUM,
   HARD_LW_REGNUM,
   HARD_LP_REGNUM,
   HARD_LS_REGNUM, 0};

/* If defined, a C expression which determines whether, and in which direction,
   to pad out an argument with extra space.  The value should be of type
   `enum direction': either `upward' to pad above the argument,
   `downward' to pad below, or `none' to inhibit padding.

   Structures are stored left shifted in their argument slot.  */
int
tms9900_function_arg_padding (enum machine_mode mode, const_tree type)
{
  if (type != 0 && AGGREGATE_TYPE_P (type))
    return upward;

  /* Fall back to the default.  */
  return DEFAULT_FUNCTION_ARG_PADDING (mode, type);
}


/* Update the data in CUM to advance over an argument
   of mode MODE and data type TYPE.
   (TYPE is null for libcalls where that information may not be available.)  */
void
tms9900_function_arg_advance (CUMULATIVE_ARGS *cum, enum machine_mode mode,
                              tree type, int named ATTRIBUTE_UNUSED)
{
  int arg_bytes;
  if(mode == BLKmode)
  {
     arg_bytes = int_size_in_bytes (type);
  }
  else
  {
     arg_bytes = GET_MODE_SIZE (mode);
  }
  cum->nregs += ((arg_bytes + 1)/ UNITS_PER_WORD) * REGS_PER_WORD;
  return;
}


/* Initialize a variable CUM of type CUMULATIVE_ARGS
   for a call to a function whose data type is FNTYPE.
   For a library call, FNTYPE is NULL.  */
void
tms9900_init_cumulative_args (CUMULATIVE_ARGS *cum, tree fntype,
			  rtx libname  ATTRIBUTE_UNUSED,
			  tree fndecl ATTRIBUTE_UNUSED)
{
  /* Varargs vectors are treated the same as long long.
     named_count avoids having to change the way arm handles 'named' */
  cum->named_count = 0;
  cum->nregs = 0;
}


/* Determine where to put an argument to a function.
   Value is zero to push the argument on the stack,
   or a hard register in which to store the argument.

   MODE is the argument's machine mode.
   TYPE is the data type of the argument (as a tree).
    This is null for libcalls where that information may
    not be available.
   CUM is a variable of type CUMULATIVE_ARGS which gives info about
    the preceding args and about the function being called.
   NAMED is nonzero if this argument is a named parameter
    (otherwise it is an extra parameter matching an ellipsis).  */

rtx
tms9900_function_arg (CUMULATIVE_ARGS *cum, enum machine_mode mode,
		  tree type, int named)
{
  if (mode == VOIDmode)
    /* Pick an arbitrary value for operand 2 of the call insn.  */
    return const0_rtx;
  if (!named || cum->nregs >= TMS9900_ARG_REGS)
    return NULL_RTX;
  return gen_rtx_REG (mode, cum->nregs + HARD_R1_REGNUM);
}


void
print_operand_address (FILE *file, register rtx addr)
{
  register rtx breg;
  rtx offset;

  retry:

  switch (GET_CODE (addr))
    {
    case MEM:
      addr = XEXP (addr, 0);
      goto retry;

    case REG:
      fprintf (file, "*%s", reg_names[REGNO (addr)]);
      break;

    case POST_MODIFY:
    case POST_INC:
      fprintf (file, "*%s+", reg_names[REGNO (XEXP (addr, 0))]);
      break;

    case PLUS:
      breg = 0;
      offset = 0;
      if (CONSTANT_ADDRESS_P (XEXP (addr, 0))
	  || GET_CODE (XEXP (addr, 0)) == MEM)
	{
	  offset = XEXP (addr, 0);
	  addr = XEXP (addr, 1);
	}
      else if (CONSTANT_ADDRESS_P (XEXP (addr, 1))
	       || GET_CODE (XEXP (addr, 1)) == MEM)
	{
	  offset = XEXP (addr, 1);
	  addr = XEXP (addr, 0);
	}

      if (GET_CODE (addr) != PLUS)
	;
      else if (GET_CODE (XEXP (addr, 0)) == REG)
	{
	  breg = XEXP (addr, 0);
	  addr = XEXP (addr, 1);
	}
      else if (GET_CODE (XEXP (addr, 1)) == REG)
	{
	  breg = XEXP (addr, 1);
	  addr = XEXP (addr, 0);
	}
      if (GET_CODE (addr) == REG)
	{
          if(breg == 0)
            breg = addr;
	  addr = 0;
	}
      if (offset != 0)
	{
	  gcc_assert (addr == 0);
	  addr = offset;
	}

      if (addr != 0)
	output_address (addr);
      if (breg != 0)
	{
	  gcc_assert (GET_CODE (breg) == REG);
	  fprintf (file, "(%s)", reg_names[REGNO (breg)]);
	}
      break;

    default:
      fprintf(file, "@");
      output_addr_const (file, addr);
    }
}

static int 
tms9900_get_saved_reg_size()
{
   int idx = 0;
   int size = 0;
   while(nvolregs[idx] != 0)
   {      
      int regno = nvolregs[idx];
      if ((df_regs_ever_live_p (regno) && ! call_used_regs[regno]) ||
          (regno == HARD_LR_REGNUM && frame_pointer_needed) ||
          (regno == HARD_LR_REGNUM && !current_function_is_leaf))
      {
         size += 2;
      }
      idx++;
   }
   return(size);
}

/* Define the offset between two registers, one to be eliminated, and the
   other its replacement, at the start of a routine.  */
int
tms9900_initial_elimination_offset (int from, int to)
{
  if (from == ARG_POINTER_REGNUM && to == HARD_SP_REGNUM)
  {
    return(tms9900_get_saved_reg_size() +
           get_frame_size ());
  }
  return 0;
}


int
legitimate_address_p (enum machine_mode mode, rtx address)
{
/* #define REG_OK_STRICT */
    GO_IF_LEGITIMATE_ADDRESS(mode, address, win);
    
    return 0;
    
  win:
    return 1;

/* #undef REG_OK_STRICT */
}


int
simple_memory_operand(rtx op, enum machine_mode mode ATTRIBUTE_UNUSED)
{
    rtx addr;

    /* Eliminate non-memory operations */
    if (GET_CODE (op) != MEM)
	return FALSE;

#if 0
    /* dword operations really put out 2 instructions, so eliminate them.  */
    if (GET_MODE_SIZE (GET_MODE (op)) > (HAVE_64BIT_P () ? 8 : 4))
	return FALSE;
#endif

    /* Decode the address now.  */

  indirection:
    
    addr = XEXP (op, 0);

    switch (GET_CODE (addr))
    {
      case REG:
	/* *Rn - no extra cost */
	return 1;
	
      case POST_INC:
	/* *Rn+ - cheap! */
	return 0;
	
      case MEM:
	/* cheap - is encoded in addressing mode info! 

	   -- except for @(Rn), which has to be @0(Rn) !!! */

	if (GET_CODE (XEXP (addr, 0)) == REG)
	    return 0;
	
	op=addr;
	goto indirection;
	
      case CONST_INT:
      case LABEL_REF:	       
      case CONST:
      case SYMBOL_REF:
	/* @#address - extra cost */
	return 0;

      case PLUS:
	/* *X(Rn) - extra cost */
	return 0;

      default:
	break;
    }
    
    return FALSE;
}


const char *
output_branch (const char *pos, const char *neg, int length)
{
    static int x = 0;
    
    static char buf[1000];

    if(length == 1)
    {
	strcpy(buf, pos);
	strcat(buf, " %l0");
    }
    else if(length == 2)
    {
        if(*pos == 'L')
            sprintf(buf, "jeq %%l0\n"
                         "\tjlt %%l0\n");
        else if(*pos == 'G')
            sprintf(buf, "jeq %%l0\n"
                         "\tjgt %%l0\n");
        else
            gcc_unreachable();
    }
    else if(length == 3)
    {
	sprintf(buf, "%s JMP_%d\n"
                     "\tb @%%l0\n"
                     "JMP_%d", neg, x, x);	
	x++;
    }
    else if(length == 4)
    {
        if(*neg == 'L')
            sprintf(buf, "jeq JMP_%d\n"
                         "\tjlt JMP_%d\n"
                         "\tb @%%l0\n"
                         "JMP_%d", x, x, x);
        else if(*neg == 'G')
            sprintf(buf, "jeq JMP_%d\n"
                         "\tjgt JMP_%d\n"
                         "\tb @%%l0\n"
                         "JMP_%d", x, x, x);
        else
            gcc_unreachable();

	x++;
    }
    else
    {
	gcc_unreachable();
    }    
    return buf;
}


const char *
output_jump (int length)
{
    switch(length)    
    {
        case 1: return("jmp %l0");
        case 2: return("b @%l0");
        default: gcc_unreachable();
    }
}


/* Return a REG that occurs in ADDR with coefficient 1.
   ADDR can be effectively incremented by incrementing REG.  */

void
notice_update_cc_on_set(rtx exp, rtx insn ATTRIBUTE_UNUSED)
{
    if (GET_CODE (SET_DEST (exp)) == CC0)
    { 
	cc_status.flags = 0;					
	cc_status.value1 = SET_DEST (exp);			
	cc_status.value2 = SET_SRC (exp);			
    }							
    else if ((GET_CODE (SET_DEST (exp)) == REG		
	      || GET_CODE (SET_DEST (exp)) == MEM)		
	     && GET_CODE (SET_SRC (exp)) != PC		
	     && (GET_MODE (SET_DEST(exp)) == HImode		
		 || GET_MODE (SET_DEST(exp)) == QImode)	
		&& (GET_CODE (SET_SRC(exp)) == PLUS		
		    || GET_CODE (SET_SRC(exp)) == MINUS	
		    || GET_CODE (SET_SRC(exp)) == AND	
		    || GET_CODE (SET_SRC(exp)) == IOR	
		    || GET_CODE (SET_SRC(exp)) == XOR	
		    || GET_CODE (SET_SRC(exp)) == NOT	
		    || GET_CODE (SET_SRC(exp)) == NEG	
			|| GET_CODE (SET_SRC(exp)) == REG	
		    || GET_CODE (SET_SRC(exp)) == MEM))	
    { 
	cc_status.flags = 0;					
	cc_status.value1 = SET_SRC (exp);   			
	cc_status.value2 = SET_DEST (exp);			
	
	if (cc_status.value1 && GET_CODE (cc_status.value1) == REG	
	    && cc_status.value2					
	    && reg_overlap_mentioned_p (cc_status.value1, cc_status.value2))
    	    cc_status.value2 = 0;					
	if (cc_status.value1 && GET_CODE (cc_status.value1) == MEM	
	    && cc_status.value2					
	    && GET_CODE (cc_status.value2) == MEM)			
	    cc_status.value2 = 0; 					
    }							
    else if (GET_CODE (SET_SRC (exp)) == CALL)		
    { 
	CC_STATUS_INIT; 
    }
    else if (GET_CODE (SET_DEST (exp)) == REG)       		
	/* what's this ? */					
    { 
	if ((cc_status.value1					
	     && reg_overlap_mentioned_p (SET_DEST (exp), cc_status.value1)))
	    cc_status.value1 = 0;				
	if ((cc_status.value2					
	     && reg_overlap_mentioned_p (SET_DEST (exp), cc_status.value2)))
	    cc_status.value2 = 0;				
    }							
    else if (SET_DEST(exp) == pc_rtx)
    { 
	/* jump */
    }
    else /* if (GET_CODE (SET_DEST (exp)) == MEM)	*/	
    {  
	/* the last else is a bit paranoiac, but since nearly all instructions 
	   play with condition codes, it's reasonable! */

	CC_STATUS_INIT; /* paranoia*/ 
    }		        
}


rtx
tms9900_function_value (const_tree valtype, const_tree func ATTRIBUTE_UNUSED, 
                      bool outgoing)
{
  return gen_rtx_REG (TYPE_MODE (valtype), HARD_R1_REGNUM);
}


/* A C statement to output to the stdio stream STREAM an assembler
   instruction to assemble a string constant containing the LEN bytes
   at PTR.  PTR will be a C expression of type `char *' and LEN a C
   expression of type `int'. */
void tms9900_output_ascii(FILE* stream, char* ptr, int len)
{
   int i;
   int need_quote = 1;
   /* Start TEXT constant */
   fprintf(stream, "\ttext \"");
   for (i = 0; i < len; i++,ptr++)
   {
      int c = *ptr;
      if (ISPRINT(c))
         putc (c, stream);
      else
      {
         /* Handle non-printable characters by inlining BYTE constants*/
         fprintf (stream, "\"\n\tbyte %d\n", c);
         if (i < len - 1)
            /* We have more text to emit, start another TEXT constant */
            fprintf (stream, "\"\n\ttext \"");
         else
            /* No more text, since we've ended the last TEXT, we're done */
            need_quote = 0;
      }
   }
   if(need_quote)
      fprintf (stream, "\"\n");

   /* Make sure we end on an even address */
   if(len & 1)
      fprintf (stream, "\teven\n");
}


void
tms9900_expand_prologue ()
{
   /* Registers to save in this frame */
   int saveregs[5];
   int regcount = 0;
   int idx = 0;
   int frame_size = get_frame_size();

   /* Find non-volatile registers which need to be saved */
   while(nvolregs[idx] != 0)
   {      
      int regno = nvolregs[idx];
      saveregs[idx] = 0;
      if ((df_regs_ever_live_p (regno) && ! call_used_regs[regno]) ||
          (regno == HARD_LR_REGNUM && frame_pointer_needed) ||
          (regno == HARD_LR_REGNUM && !current_function_is_leaf))
      {
         /* Mark this register to be saved */
         saveregs[idx] = 1;
         regcount++;
      }
      idx++;
   }

   /* Actually save registers */
   if(regcount>2)
   {
      /*
      Form 1:
      ai sp, -regsize             14+0,4
      mov reg, *sp+               14+8,2
      ...
      ai sp, -regsize-framesize   14+0,4
      */

      /* Emit "ai sp, -regcount * 2" */
      emit_insn(gen_addhi3(stack_pointer_rtx, stack_pointer_rtx, 
                          GEN_INT(-regcount * 2)));
      idx = 0;
      while(nvolregs[idx] != 0)
      {
         if(saveregs[idx]!=0)
         {
            /* Emit "mov Rx, *SP+" */
            int regno = nvolregs[idx];
            emit_insn(gen_movhi(
               gen_rtx_MEM(HImode, 
                           gen_rtx_POST_INC(HImode, stack_pointer_rtx)),
               gen_rtx_REG(HImode, regno)));
         }
         idx++;
      }

      /* Emit "ai sp, -regcount*2-framesize" */
      emit_insn(gen_addhi3(stack_pointer_rtx, stack_pointer_rtx, 
                          GEN_INT(-regcount * 2 - frame_size)));
   }
   else if(regcount > 0)
   {
      /*
      Form 2:
      ai sp, -regsize-framesize  14+0,4
      mov reg, *X(sp)            14+8,4
      ...
      */
      int offset = 0;

      /* Emit "ai sp, -regcount*2-framesize" */
      emit_insn(gen_addhi3(stack_pointer_rtx, stack_pointer_rtx, 
                          GEN_INT(-regcount * 2 - frame_size)));
      idx = 0;
      while(nvolregs[idx] != 0)
      {
         if(saveregs[idx]!=0)
         {
            /* Emit "mov Rn, @X(sp)" */
            int regno = nvolregs[idx];
            emit_insn(gen_movhi(
               adjust_address(gen_rtx_MEM(HImode, stack_pointer_rtx), 
                              HImode, offset + frame_size),
               gen_rtx_REG(HImode, regno)));
            offset += 2;
         }
         idx++;
      }
   }
   else
   {
      /* No registers to save */
      if(frame_size > 0)
         printf("\t ai sp, -%d\n",frame_size);
   }

   /* Set frame pointer */
   if(frame_pointer_needed)
   {
      emit_insn(gen_movhi(gen_rtx_REG(HImode, FRAME_POINTER_REGNUM),
                          stack_pointer_rtx));
   }
}


void
tms9900_expand_epilogue ()
{
   /* Find registers to save in this frame */
   int idx=0;
   int frame_size = get_frame_size();

   /* Emit "ai sp, frame_size" */
   emit_insn(gen_addhi3(stack_pointer_rtx, stack_pointer_rtx, 
                        GEN_INT(frame_size)));

   while(nvolregs[idx] != 0)
   {      
      int regno = nvolregs[idx];
      if ((df_regs_ever_live_p (regno) && ! call_used_regs[regno]) ||
          (regno == HARD_LR_REGNUM && frame_pointer_needed) ||
          (regno == HARD_LR_REGNUM && !current_function_is_leaf))
      {
         /* Save this register */
         /* Emit "mov *SP+, Rx" */
         int regno = nvolregs[idx];
         emit_insn(gen_movhi(
            gen_rtx_REG(HImode, regno),
            gen_rtx_MEM(HImode, 
                        gen_rtx_POST_INC(HImode, stack_pointer_rtx))));
      }
      idx++;
   }

  /* Emit the return instruction "b *R11" */
  emit_insn(gen_movhi(gen_rtx_REG(HImode, HARD_PC_REGNUM),
                      gen_rtx_REG(HImode, HARD_LR_REGNUM)));
}

